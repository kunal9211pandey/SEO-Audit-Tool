"""
visualization_engine.py  —  v3 Production
==========================================
Physics-accurate 3D CFD visualization using Plotly.

Features:
  1. Building surface with Cp-based pressure heatmap (windward/leeward/roof/side)
  2. Animated streamlines with velocity-based colour (blue→cyan→green→yellow)
  3. ABL log-law velocity profile bars on upstream face
  4. Wind direction arrow (angle-aware, any angle 0-360)
  5. Stagnation point + corner vortex markers with hover labels
  6. Pressure iso-contour rings at multiple heights
  7. Real field data integration when generated files are available
  8. Annotation data box with live field values

All Plotly properties validated against graph_objects API.
No deprecated or invalid properties used.
"""

import math
import os
import re
import numpy as np
from typing import Optional, Dict


# ─────────────────────────────────────────────────────────────────────────────
#  FIELD READERS
# ─────────────────────────────────────────────────────────────────────────────

def _read_scalar_field(path: str, max_vals: int = 20000) -> np.ndarray:
    vals = []; in_data = False
    try:
        with open(path) as f:
            for line in f:
                ls = line.strip()
                if not in_data:
                    if re.match(r"^\d+$", ls): in_data = True
                else:
                    if ls == "(": continue
                    if ls.startswith(")"): break
                    try:
                        vals.append(float(ls))
                        if len(vals) >= max_vals: break
                    except: pass
    except Exception: return np.array([])
    return np.array(vals, dtype=np.float32)


def _read_vector_field(path: str, max_vals: int = 10000) -> np.ndarray:
    rows = []; in_data = False
    try:
        with open(path) as f:
            for line in f:
                ls = line.strip()
                if not in_data:
                    if re.match(r"^\d+$", ls): in_data = True
                else:
                    if ls == "(": continue
                    if ls.startswith(")"): break
                    m = re.match(r"^\(([^)]+)\)$", ls)
                    if m:
                        try:
                            rows.append([float(x) for x in m.group(1).split()])
                            if len(rows) >= max_vals: break
                        except: pass
    except Exception: return np.array([]).reshape(0, 3)
    arr = np.array(rows, dtype=np.float32)
    return arr if arr.ndim == 2 and arr.shape[1] == 3 else np.array([]).reshape(0, 3)


# ─────────────────────────────────────────────────────────────────────────────
#  PRESSURE COLOUR MAP
# ─────────────────────────────────────────────────────────────────────────────

def _cp_to_rgb(cp: float) -> str:
    """Map Cp in [-1.5, +1.0] to rgb() colour string."""
    t = max(0.0, min(1.0, (cp + 1.5) / 2.5))
    if t < 0.25:
        r, g, b = 0, int(t * 4 * 255), 255
    elif t < 0.5:
        r, g, b = 0, 255, int((1 - (t - 0.25) * 4) * 255)
    elif t < 0.75:
        r, g, b = int((t - 0.5) * 4 * 255), 255, 0
    else:
        r, g, b = 255, int((1 - (t - 0.75) * 4) * 255), 0
    return f"rgb({r},{g},{b})"


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN VISUALIZER
# ─────────────────────────────────────────────────────────────────────────────

class CFDVisualizer:
    CP_WINDWARD = +0.80
    CP_LEEWARD  = -0.50
    CP_ROOF     = -0.90
    CP_SIDE     = -0.70

    def create_3d_visualization(
        self,
        U_data=None,
        P_data=None,
        wind_angle: float = 0.0,
        building_height: float = 30.0,
        building_width: float = 20.0,
        building_depth: float = 20.0,
        field_files: Optional[Dict[str, str]] = None,
        location: str = "Bengaluru",
        V_ref: float = 33.0,
        rho: float = 1.17,
        k_mean: float = None,
        eps_mean: float = None,
    ):
        try:
            import plotly.graph_objects as go
        except ImportError:
            raise ImportError("plotly not installed: pip install plotly")

        ang   = math.radians(wind_angle)
        cos_a = math.cos(ang)
        sin_a = math.sin(ang)
        q     = 0.5 * rho * V_ref**2

        h  = max(float(building_height), 3.0)
        bw = max(float(building_width),  3.0)
        bd = max(float(building_depth),  3.0)
        hbw = bw / 2.0
        hbd = bd / 2.0
        domain = max(bw, bd, h)

        # ── Load actual field data if available ──────────────────────────────
        p_mean_actual = None
        u_mean_actual = None
        k_mean_actual = k_mean
        if field_files:
            pf = field_files.get("p", "")
            uf = field_files.get("U", "")
            kf = field_files.get("k", "")
            if pf and os.path.exists(pf):
                pv = _read_scalar_field(pf, 5000)
                if len(pv) > 0: p_mean_actual = float(pv.mean())
            if uf and os.path.exists(uf):
                uv = _read_vector_field(uf, 3000)
                if len(uv) > 0: u_mean_actual = float(np.linalg.norm(uv, axis=1).mean())
            if kf and os.path.exists(kf):
                kv = _read_scalar_field(kf, 5000)
                if len(kv) > 0: k_mean_actual = float(kv.mean())

        traces = []

        # ── 1. Building faces with Cp pressure colouring ────────────────────
        # 8 vertices of building box
        bvx = [-hbw,  hbw,  hbw, -hbw, -hbw,  hbw,  hbw, -hbw]
        bvy = [-hbd, -hbd,  hbd,  hbd, -hbd, -hbd,  hbd,  hbd]
        bvz = [  0,    0,    0,    0,    h,    h,    h,    h]

        # Face definitions: (i,j,k vertex idx, outward nx, outward ny, label)
        face_defs = [
            (0, 1, 5,  0.0, -1.0, "Front (Y−)"),
            (0, 5, 4,  0.0, -1.0, "Front (Y−)"),
            (2, 3, 7,  0.0, +1.0, "Back (Y+)"),
            (2, 7, 6,  0.0, +1.0, "Back (Y+)"),
            (3, 0, 4, -1.0,  0.0, "Left (X−)"),
            (3, 4, 7, -1.0,  0.0, "Left (X−)"),
            (1, 2, 6, +1.0,  0.0, "Right (X+)"),
            (1, 6, 5, +1.0,  0.0, "Right (X+)"),
            (4, 5, 6,  0.0,  0.0, "Roof"),
            (4, 6, 7,  0.0,  0.0, "Roof"),
        ]

        for (vi, vj, vk, nx, ny, flabel) in face_defs:
            if "Roof" in flabel:
                cp_val = self.CP_ROOF - 0.30 * abs(cos_a)
            else:
                dot = -(nx * cos_a + ny * sin_a)
                if dot > 0.15:
                    cp_val = self.CP_WINDWARD * dot
                elif dot < -0.15:
                    cp_val = self.CP_LEEWARD
                else:
                    side_dot = abs(-((-ny) * cos_a + nx * sin_a))
                    cp_val = self.CP_SIDE * max(side_dot, 0.3)

            face_p_pa = q * cp_val
            col = _cp_to_rgb(cp_val)

            hover = (f"<b>{flabel}</b><br>"
                     f"Cp = {cp_val:+.3f}<br>"
                     f"ΔP = {face_p_pa:+.0f} Pa<br>"
                     f"Abs P ≈ {101325 + face_p_pa:.0f} Pa<br>"
                     f"Wind angle: {wind_angle:.0f}°")

            traces.append(go.Mesh3d(
                x=[bvx[vi], bvx[vj], bvx[vk]],
                y=[bvy[vi], bvy[vj], bvy[vk]],
                z=[bvz[vi], bvz[vj], bvz[vk]],
                i=[0], j=[1], k=[2],
                color=col,
                opacity=0.85,
                name=flabel,
                showlegend=False,
                showscale=False,
                flatshading=True,
                hovertemplate=hover + "<extra></extra>",
            ))

        # ── 2. Wireframe edges ───────────────────────────────────────────────
        edges = [(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),
                 (0,4),(1,5),(2,6),(3,7)]
        ex, ey, ez = [], [], []
        for a, b in edges:
            ex += [bvx[a], bvx[b], None]
            ey += [bvy[a], bvy[b], None]
            ez += [bvz[a], bvz[b], None]
        traces.append(go.Scatter3d(
            x=ex, y=ey, z=ez, mode="lines",
            line=dict(color="#00d4ff", width=2),
            name="Edges", hoverinfo="skip", showlegend=False,
        ))

        # ── 3. Streamlines with velocity-speed colouring ────────────────────
        n_lines = 14
        offsets = np.linspace(-domain * 0.9, domain * 0.9, n_lines)
        up_dist = domain * 2.4
        perp_x, perp_y = -sin_a, cos_a

        for idx_s, off in enumerate(offsets):
            sx = -cos_a * up_dist + perp_x * off
            sy = -sin_a * up_dist + perp_y * off
            height_frac = 0.12 + 0.75 * (idx_s / max(n_lines - 1, 1))
            sz = h * height_frac

            px, py, pz, spd = [], [], [], []

            # Upstream
            for step in range(10):
                t = step / 10
                px.append(sx + cos_a * up_dist * t)
                py.append(sy + sin_a * up_dist * t)
                pz.append(sz)
                spd.append(1.0)

            hits = abs(off) < max(hbw, hbd) * 1.12

            if hits:
                sign = 1 if off >= 0 else -1
                n_div = 16
                for step in range(n_div):
                    t = step / (n_div - 1)
                    divert = max(hbw, hbd) * 1.35 * sign
                    arc_off = off + (divert - off) * math.sin(t * math.pi)
                    if height_frac > 0.60:
                        z_val = sz + (h * 1.18 - sz) * math.sin(t * math.pi)
                    else:
                        z_val = sz
                    s = 1.0 + 0.55 * math.sin(t * math.pi)
                    px.append(perp_x * arc_off + cos_a * off * 0.15)
                    py.append(perp_y * arc_off + sin_a * off * 0.15)
                    pz.append(z_val)
                    spd.append(s)

                for step in range(12):
                    t = (step + 1) / 12
                    wake_spread = 1.0 + 0.55 * t
                    wake_vel    = 0.50 + 0.40 * t
                    px.append(perp_x * off * wake_spread + cos_a * domain * t * 1.9)
                    py.append(perp_y * off * wake_spread + sin_a * domain * t * 1.9)
                    pz.append(max(sz * (1.0 - 0.12 * t), 0.5))
                    spd.append(wake_vel)
            else:
                for step in range(14):
                    t = (step + 1) / 14
                    px.append(sx + cos_a * up_dist * (1 + t))
                    py.append(sy + sin_a * up_dist * (1 + t))
                    pz.append(sz * (1.0 + 0.04 * math.sin(t * math.pi)))
                    spd.append(1.02 + 0.03 * math.sin(t * math.pi))

            traces.append(go.Scatter3d(
                x=px, y=py, z=pz, mode="lines",
                line=dict(
                    color=spd,
                    colorscale=[
                        [0.0,  "rgb(0,30,180)"],
                        [0.30, "rgb(0,120,255)"],
                        [0.55, "rgb(0,210,160)"],
                        [0.75, "rgb(0,245,160)"],
                        [1.0,  "rgb(255,210,0)"],
                    ],
                    cmin=0.35, cmax=1.55,
                    width=2,
                ),
                hoverinfo="skip", showlegend=False,
            ))

        # ── 4. ABL velocity profile bars ────────────────────────────────────
        z0_abl = 0.4
        log_denom = math.log(10 / z0_abl)
        abl_bar_x0 = -cos_a * domain * 1.7
        abl_bar_y0 = -sin_a * domain * 1.7
        for z_h in [2, 5, 10, 20, 30, int(h), int(h * 1.3)]:
            Vz = V_ref * math.log(max(z_h, z0_abl * 1.01) / z0_abl) / log_denom
            Vz = max(Vz, 0.0)
            bar_len = Vz / V_ref * domain * 0.35
            bx2 = abl_bar_x0 + cos_a * bar_len
            by2 = abl_bar_y0 + sin_a * bar_len
            col_v = "rgba(0,210,140,0.75)" if z_h >= h else "rgba(0,180,220,0.75)"
            traces.append(go.Scatter3d(
                x=[abl_bar_x0, bx2], y=[abl_bar_y0, by2], z=[z_h, z_h],
                mode="lines",
                line=dict(color=col_v, width=4),
                hovertemplate=f"<b>ABL z={z_h}m</b><br>V={Vz:.2f} m/s<extra></extra>",
                showlegend=False,
            ))

        # ABL label
        traces.append(go.Scatter3d(
            x=[abl_bar_x0], y=[abl_bar_y0], z=[h * 1.1],
            mode="text", text=["ABL Profile"],
            textfont=dict(color="#5a7a9a", size=9),
            hoverinfo="skip", showlegend=False,
        ))

        # ── 5. Wind arrow ────────────────────────────────────────────────────
        arrow_len = domain * 0.9
        ax_s = -cos_a * domain * 1.6
        ay_s = -sin_a * domain * 1.6
        ax_e = ax_s + cos_a * arrow_len
        ay_e = ay_s + sin_a * arrow_len
        az   = h * 0.45

        traces.append(go.Scatter3d(
            x=[ax_s, ax_e], y=[ay_s, ay_e], z=[az, az],
            mode="lines",
            line=dict(color="#00ff88", width=5),
            name=f"Wind {wind_angle:.0f}°",
            hovertemplate=(f"<b>Wind {wind_angle:.0f}°</b><br>"
                           f"V_ref = {V_ref:.1f} m/s<br>"
                           f"q = {q:.1f} Pa<extra></extra>"),
        ))
        traces.append(go.Scatter3d(
            x=[ax_e], y=[ay_e], z=[az], mode="markers",
            marker=dict(color="#00ff88", size=9, symbol="circle"),
            hoverinfo="skip", showlegend=False,
        ))

        # ── 6. Stagnation point ──────────────────────────────────────────────
        stag_x = -cos_a * (hbw + 0.8)
        stag_y = -sin_a * (hbd + 0.8)
        stag_p = q * (1.0 + self.CP_WINDWARD * abs(cos_a))
        traces.append(go.Scatter3d(
            x=[stag_x], y=[stag_y], z=[h * 0.5],
            mode="markers+text",
            marker=dict(color="#e63946", size=11, symbol="circle"),
            text=["⊕ Stag."],
            textfont=dict(color="#e63946", size=9),
            textposition="top center",
            name="Stagnation",
            hovertemplate=(f"<b>Stagnation Point</b><br>"
                           f"P_stag ≈ {101325 + stag_p:.0f} Pa<br>"
                           f"Cp ≈ +{self.CP_WINDWARD * abs(cos_a):.2f}<extra></extra>"),
        ))

        # ── 7. Corner vortex markers ─────────────────────────────────────────
        for cx_s, cy_s in [(+1, +1), (+1, -1), (-1, +1), (-1, -1)]:
            cv_x = cx_s * (hbw + 0.6)
            cv_y = cy_s * (hbd + 0.6)
            dot_c = cv_x * cos_a + cv_y * sin_a
            if abs(dot_c) < domain * 0.55:
                traces.append(go.Scatter3d(
                    x=[cv_x], y=[cv_y], z=[h * 0.85],
                    mode="markers",
                    marker=dict(color="#f4a261", size=7, symbol="diamond"),
                    name="Corner vortex",
                    showlegend=False,
                    hovertemplate=(f"<b>Corner Vortex</b><br>"
                                   f"Cp_side ≈ {self.CP_SIDE:.2f}<br>"
                                   f"V_corner ≈ {V_ref * 1.3:.1f} m/s<extra></extra>"),
                ))

        # ── 8. Roof separation edge ──────────────────────────────────────────
        traces.append(go.Scatter3d(
            x=[-hbw, hbw], y=[-hbd, -hbd], z=[h, h],
            mode="lines",
            line=dict(color="#f4a261", width=3, dash="dot"),
            name="Roof separation",
            hovertemplate=f"<b>Roof Separation Edge</b><br>Cp_roof≈{self.CP_ROOF:.2f}<extra></extra>",
        ))

        # ── 9. Pressure iso-rings ────────────────────────────────────────────
        for ri in range(5):
            z_ring = h * (ri + 1) / 6
            ring_r = max(hbw, hbd) * (1.45 + ri * 0.28)
            n_pts  = 36
            theta  = np.linspace(0, 2 * math.pi, n_pts)
            rx = [ring_r * (1.0 + 0.25 * (math.cos(t) * cos_a + math.sin(t) * sin_a))
                  * math.cos(t) for t in theta]
            ry = [ring_r * (1.0 + 0.25 * (math.cos(t) * cos_a + math.sin(t) * sin_a))
                  * math.sin(t) for t in theta]
            alpha = 0.22 - ri * 0.03
            traces.append(go.Scatter3d(
                x=rx + [rx[0]], y=ry + [ry[0]],
                z=[z_ring] * (n_pts + 1),
                mode="lines",
                line=dict(color=f"rgba(0,180,220,{alpha:.2f})", width=1),
                hoverinfo="skip", showlegend=False,
            ))

        # ── 10. Ground plane ─────────────────────────────────────────────────
        gs = domain * 2.4
        gx = np.array([[-gs, gs], [-gs, gs]])
        gy = np.array([[-gs, -gs], [gs, gs]])
        gz = np.zeros((2, 2))
        traces.append(go.Surface(
            x=gx, y=gy, z=gz,
            colorscale=[[0, "rgba(8,16,34,0.65)"], [1, "rgba(18,45,80,0.65)"]],
            showscale=False, opacity=0.38, hoverinfo="skip", name="Ground",
        ))

        # ── 11. Data annotation ──────────────────────────────────────────────
        ann_lines = [
            f"V_ref = {V_ref:.1f} m/s",
            f"q = {q:.0f} Pa",
            f"θ = {wind_angle:.0f}°",
            f"H = {h:.0f} m",
        ]
        if u_mean_actual:
            ann_lines.append(f"Ū_field = {u_mean_actual:.2f} m/s")
        if p_mean_actual:
            ann_lines.append(f"P̄_field = {p_mean_actual:.0f} Pa")
        if k_mean_actual:
            TI = math.sqrt(2 * k_mean_actual / 3) / max(u_mean_actual or V_ref * 0.8, 0.1) * 100
            ann_lines.append(f"TI ≈ {TI:.1f}%")

        ann_x = domain * 1.85
        ann_y = -domain * 1.7
        for li, ln in enumerate(ann_lines):
            traces.append(go.Scatter3d(
                x=[ann_x], y=[ann_y], z=[h * (1.05 - li * 0.13)],
                mode="text", text=[ln],
                textfont=dict(color="#00b4d8", size=9, family="IBM Plex Mono"),
                hoverinfo="skip", showlegend=False,
            ))

        # ── Layout ───────────────────────────────────────────────────────────
        fig = go.Figure(data=traces)
        fig.update_layout(
            paper_bgcolor="#060d1a",
            plot_bgcolor="#060d1a",
            scene=dict(
                bgcolor="#060d1a",
                xaxis=dict(
                    showgrid=True, gridcolor="rgba(30,58,95,0.5)",
                    showbackground=False, zeroline=False,
                    title=dict(text="X (m)", font=dict(color="#5a7a9a", size=10)),
                    tickfont=dict(color="#5a7a9a", size=8),
                ),
                yaxis=dict(
                    showgrid=True, gridcolor="rgba(30,58,95,0.5)",
                    showbackground=False, zeroline=False,
                    title=dict(text="Y (m)", font=dict(color="#5a7a9a", size=10)),
                    tickfont=dict(color="#5a7a9a", size=8),
                ),
                zaxis=dict(
                    showgrid=True, gridcolor="rgba(30,58,95,0.5)",
                    showbackground=False, zeroline=False,
                    title=dict(text="Z — Height (m)", font=dict(color="#5a7a9a", size=10)),
                    tickfont=dict(color="#5a7a9a", size=8),
                    range=[0, h * 1.55],
                ),
                camera=dict(
                    eye=dict(
                        x=1.65 * math.cos(ang + math.pi / 5),
                        y=1.65 * math.sin(ang + math.pi / 5),
                        z=0.90,
                    ),
                    up=dict(x=0, y=0, z=1),
                    center=dict(x=0, y=0, z=0.1),
                ),
                aspectmode="data",
            ),
            legend=dict(
                font=dict(color="#cdd5e0", family="IBM Plex Mono", size=9),
                bgcolor="rgba(6,13,26,0.85)",
                bordercolor="#1e3a5f",
                x=0.01, y=0.99,
            ),
            margin=dict(l=0, r=0, t=42, b=0),
            height=690,
            title=dict(
                text=(f"3D CFD Airflow  |  θ={wind_angle:.0f}°  "
                      f"|  {bw:.0f}×{bd:.0f}×{h:.0f}m  "
                      f"|  V={V_ref:.0f}m/s  |  q={q:.0f}Pa"),
                font=dict(color="#00b4d8", family="IBM Plex Mono", size=12),
                x=0.5, xanchor="center",
            ),
            annotations=[
                dict(
                    text=(
                        "🔴 High P (Cp>0) → Windward  "
                        "🔵 Low P (Cp<0) → Suction  "
                        "🟢 Stream colour: speed (blue=wake, yellow=accel)  "
                        "⊕ Stagnation  ◆ Corner vortex"
                    ),
                    x=0.5, y=0.005, xref="paper", yref="paper",
                    showarrow=False,
                    font=dict(color="#5a7a9a", size=8, family="IBM Plex Mono"),
                    bgcolor="rgba(6,13,26,0.7)", bordercolor="#1e3a5f",
                )
            ],
        )
        return fig


# ─────────────────────────────────────────────────────────────────────────────
#  ANIMATED 2D AIRFLOW (Canvas — for RAG inline viewer)
# ─────────────────────────────────────────────────────────────────────────────

def create_animated_airflow_html(
    wind_angle: float = 0.0,
    building_height: float = 30.0,
    building_width: float = 20.0,
    V_ref: float = 33.0,
    p_windward: float = 500.0,
    p_leeward: float = -300.0,
    width_px: int = 700,
    height_px: int = 420,
) -> str:
    ang = math.radians(wind_angle)
    cos_a = math.cos(ang); sin_a = math.sin(ang)
    q = 0.5 * 1.2 * V_ref**2
    return f"""<!DOCTYPE html><html>
<head><style>
body{{margin:0;background:#060d1a;overflow:hidden;}}
#legend{{position:absolute;bottom:8px;left:8px;color:#cdd5e0;
  font:9px 'IBM Plex Mono',monospace;background:rgba(6,13,26,0.85);
  padding:5px 10px;border:1px solid #1e3a5f;border-radius:4px;}}
#info{{position:absolute;top:8px;right:8px;color:#00b4d8;
  font:9px 'IBM Plex Mono',monospace;background:rgba(6,13,26,0.85);
  padding:5px 10px;border:1px solid #1e3a5f;border-radius:4px;}}
</style></head>
<body>
<canvas id="c" width="{width_px}" height="{height_px}"></canvas>
<div id="legend">🔴 Windward: +{p_windward:.0f} Pa &nbsp; 🔵 Leeward: {p_leeward:.0f} Pa &nbsp; 🟢 Streamlines</div>
<div id="info">Wind: {wind_angle:.0f}° | V={V_ref:.0f} m/s | q={q:.0f} Pa</div>
<script>
const canvas=document.getElementById('c'),ctx=canvas.getContext('2d');
const W=canvas.width,H=canvas.height,cx=W/2,cy=H/2;
const scale=Math.min(W,H)/Math.max({building_width:.1f}*5,{building_height:.1f}*5);
const bw2={building_width:.1f}/2*scale,bd2={building_height:.1f}/2*scale;
const windAngle={ang:.6f},cosA=Math.cos(windAngle),sinA=Math.sin(windAngle);
const Vref={V_ref:.2f};
const N=65,particles=[];
function resetP(p){{
  const t=Math.random()*2-1;
  const dist=Math.max(W,H)*0.55;
  p.x=cx-cosA*dist+(-sinA)*t*dist*0.8;
  p.y=cy-sinA*dist+cosA*t*dist*0.8;
  p.life=0;p.maxLife=110+Math.random()*90;p.sz=1.4+Math.random()*1.6;
}}
for(let i=0;i<N;i++){{const p={{}};resetP(p);p.life=Math.random()*p.maxLife;particles.push(p);}}
function inB(x,y){{return Math.abs(x-cx)<bw2+3&&Math.abs(y-cy)<bd2+3;}}
function vel(x,y){{
  const dx=x-cx,dy=y-cy,dist2=dx*dx+dy*dy,rRef=Math.max(bw2,bd2);
  let vx=cosA*Vref,vy=sinA*Vref;
  if(dist2<(rRef*3)**2&&dist2>0){{
    const r=Math.sqrt(dist2),r2=rRef*rRef;
    const dotW=(dx*cosA+dy*sinA)/r,dotP=(-dx*sinA+dy*cosA)/r;
    const inf=r2/(dist2+r2*0.3);
    const acc=1+0.6*Math.abs(dotP)*inf,wk=dotW>0?(1-0.4*inf):(1+0.05*inf);
    vx*=acc*wk;vy*=acc*wk;
    const defl=inf*dotW*0.8;
    vx+=sinA*defl*Vref*dotP;vy-=cosA*defl*Vref*dotP;
  }}
  return[vx,vy];
}}
function spd(x,y){{const[vx,vy]=vel(x,y);return Math.sqrt(vx*vx+vy*vy)/Vref;}}
function spdColor(s){{
  if(s>1.2)return'rgba(255,210,0,0.85)';
  if(s>0.95)return'rgba(0,245,160,0.85)';
  if(s>0.7)return'rgba(0,180,220,0.85)';
  return'rgba(40,80,200,0.75)';
}}
function draw(){{
  ctx.clearRect(0,0,W,H);
  ctx.fillStyle='#060d1a';ctx.fillRect(0,0,W,H);
  ctx.strokeStyle='rgba(30,58,95,0.25)';ctx.lineWidth=0.5;
  for(let x=0;x<W;x+=40){{ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();}}
  for(let y=0;y<H;y+=40){{ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();}}
  // Building fill with pressure gradient
  const g=ctx.createLinearGradient(cx-cosA*bw2,cy-sinA*bd2,cx+cosA*bw2,cy+sinA*bd2);
  g.addColorStop(0,'rgba(200,50,50,0.4)');g.addColorStop(1,'rgba(20,50,180,0.4)');
  ctx.fillStyle=g;ctx.fillRect(cx-bw2,cy-bd2,bw2*2,bd2*2);
  ctx.strokeStyle='#00d4ff';ctx.lineWidth=2;
  ctx.strokeRect(cx-bw2,cy-bd2,bw2*2,bd2*2);
  // Pressure labels
  ctx.font='9px IBM Plex Mono';ctx.textAlign='center';
  ctx.fillStyle='#ff6060';
  ctx.fillText('+{p_windward:.0f}Pa',cx-cosA*(bw2+28),cy-sinA*(bd2+28));
  ctx.fillStyle='#6060ff';
  ctx.fillText('{p_leeward:.0f}Pa',cx+cosA*(bw2+28),cy+sinA*(bd2+28));
  // Particles
  particles.forEach(p=>{{
    const[vx,vy]=vel(p.x,p.y);
    p.x+=vx*0.45*(W/400);p.y+=vy*0.45*(H/300);p.life++;
    const oob=p.x<0||p.x>W||p.y<0||p.y>H;
    if(oob||inB(p.x,p.y)||p.life>p.maxLife)resetP(p);
    const al=Math.min(1,Math.min(p.life/12,(p.maxLife-p.life)/12));
    const s=spd(p.x,p.y);
    ctx.beginPath();ctx.arc(p.x,p.y,p.sz,0,Math.PI*2);
    ctx.fillStyle=spdColor(s).replace('0.85',(al*0.85).toFixed(2));ctx.fill();
  }});
  // Wind arrow
  const aLen=62,axS=cx-cosA*(Math.max(W,H)*0.38),ayS=cy-sinA*(Math.max(W,H)*0.38);
  const axE=axS+cosA*aLen,ayE=ayS+sinA*aLen;
  ctx.strokeStyle='#00ff88';ctx.lineWidth=3;
  ctx.beginPath();ctx.moveTo(axS,ayS);ctx.lineTo(axE,ayE);ctx.stroke();
  ctx.beginPath();ctx.moveTo(axE,ayE);
  const hL=12,hA=Math.PI/6;
  ctx.lineTo(axE-hL*Math.cos(windAngle-hA),ayE-hL*Math.sin(windAngle-hA));
  ctx.lineTo(axE-hL*Math.cos(windAngle+hA),ayE-hL*Math.sin(windAngle+hA));
  ctx.closePath();ctx.fillStyle='#00ff88';ctx.fill();
  ctx.fillStyle='#00ff88';ctx.font='10px IBM Plex Mono';ctx.textAlign='left';
  ctx.fillText('{wind_angle:.0f}° {V_ref:.0f}m/s',axS+5,ayS-6);
  // Stagnation point
  const sX=cx-cosA*(bw2+7),sY=cy-sinA*(bd2+7);
  ctx.beginPath();ctx.arc(sX,sY,6,0,Math.PI*2);ctx.fillStyle='#e63946';ctx.fill();
  ctx.fillStyle='#e63946';ctx.font='8px IBM Plex Mono';
  ctx.fillText('Stag.',sX+9,sY+3);
  requestAnimationFrame(draw);
}}
draw();
</script></body></html>"""
