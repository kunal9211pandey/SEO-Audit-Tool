"""
app.py  —  Building CFD AI  (Production v3)
============================================
4 pages:
  1. Home        — database cards, JSON metadata, wind rose
  2. RAG Q&A     — OBJ / image / text query, 3D viewer, richer pressure/velocity answers
  3. ML Predict  — upload OBJ or Image -> full CFD prediction + metric boxes + RAG explainer
  4. Index/Train — index new buildings, train model

v3 Fixes:
  - visualization_engine.py: fixed Plotly Mesh3d 'line' bug → Scatter3d for wireframes
  - RAG system prompt: structured sections for pressure/velocity/turbulence/risk
  - Text-only RAG: now always searches FAISS DB using median building vector
  - ML Image upload: robust error handling + geometry validation + confidence display
  - Post-ML RAG explainer bot: Groq LLM explains predictions in engineering detail
  - Individual metric boxes: pressure, velocity, turbulence, geometry, face pressures
  - Matched building: rich card with scaled CFD values shown after ML prediction
"""

import os, sys, json, time, zipfile, tempfile, math, base64, logging
from io import BytesIO
from pathlib import Path
from typing import Optional

import streamlit as st
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ── Page config ───────────────────────────────────────────────────────────────

def render_svg(svg_str: str, height: int = 320):
    """Render SVG properly in Streamlit using components.v1.html."""
    import streamlit.components.v1 as components
    # Wrap SVG in minimal HTML with transparent bg
    html = f'''<div style="background:transparent;padding:0;margin:0;">{svg_str}</div>'''
    components.html(html, height=height, scrolling=False)

st.set_page_config(
    page_title="Building CFD AI",
    page_icon="🏢",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Paths ─────────────────────────────────────────────────────────────────────
DATA_DIR      = os.environ.get("CFD_DATA_DIR",      "data")
MODEL_DIR     = os.environ.get("CFD_MODEL_DIR",     "models")
BUILDINGS_DIR = os.environ.get("CFD_BUILDINGS_DIR", "buildings")

LOCATIONS = [
    "Bengaluru","Mumbai","Delhi","Chennai","Kolkata","Hyderabad","Pune","Ahmedabad",
    "Dubai","Riyadh","Singapore","Tokyo","Shanghai",
    "London","Amsterdam","New York","Chicago","Toronto","Sydney",
]
WIND_ANGLES = [0, 30, 45, 60, 90, 135, 180, 270]


# ─────────────────────────────────────────────────────────────────────────────
#  CSS
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600;700&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap');
:root {
  --bg:#060d1a; --surface:#0d1626; --card:#121f35; --border:#1e3a5f;
  --accent:#00b4d8; --green:#00f5a0; --amber:#f4a261; --red:#e63946;
  --text:#cdd5e0; --muted:#5a7a9a;
}
html,body,.stApp { background:var(--bg) !important; color:var(--text) !important;
  font-family:'IBM Plex Sans',sans-serif; }
section[data-testid="stSidebar"] { background:var(--surface) !important; border-right:1px solid var(--border); }
.stApp > header { background:transparent !important; }

.card { background:var(--card); border:1px solid var(--border); border-radius:10px;
  padding:14px; margin:6px 0; transition:border-color .2s; }
.card:hover { border-color:var(--accent); }
.metric-val { font-family:'IBM Plex Mono',monospace; font-size:1.3rem; font-weight:700; color:var(--accent); }
.metric-lbl { font-size:.72rem; color:var(--muted); margin-top:3px; }
.metric-box { background:var(--surface); border:1px solid var(--border); border-radius:6px;
  padding:10px; text-align:center; }
.json-box { background:#040910; border:1px solid var(--border); border-radius:8px;
  padding:14px; font-family:'IBM Plex Mono',monospace; font-size:.75rem; color:#7ec8e3;
  max-height:380px; overflow-y:auto; white-space:pre-wrap; }
.answer-box { background:linear-gradient(135deg,var(--card),#0a1929);
  border:1px solid var(--accent); border-radius:12px; padding:20px; line-height:1.75; }
.sec-hdr { font-family:'IBM Plex Mono',monospace; font-size:.95rem; font-weight:700;
  color:var(--accent); border-bottom:1px solid var(--border); padding-bottom:6px; margin:14px 0 10px; }
.badge { display:inline-block; background:var(--accent); color:#000; border-radius:20px;
  padding:2px 10px; font-size:.72rem; font-weight:700; font-family:'IBM Plex Mono',monospace; }
.tag-green { color:var(--green); font-family:'IBM Plex Mono',monospace; font-size:.8rem; }
.stButton>button { background:linear-gradient(135deg,#00b4d822,#00b4d844) !important;
  border:1px solid var(--accent) !important; color:var(--accent) !important;
  border-radius:8px !important; font-family:'IBM Plex Mono',monospace !important;
  font-weight:600 !important; }
.stButton>button:hover { background:var(--accent) !important; color:#000 !important; }
#MainMenu,footer { visibility:hidden; }
h1,h2 { font-family:'IBM Plex Sans',sans-serif; color:var(--text) !important; }
h3 { color:var(--accent) !important; font-family:'IBM Plex Mono',monospace; }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
#  SESSION STATE
# ─────────────────────────────────────────────────────────────────────────────
for k, v in {"last_rag": None, "last_pred": None}.items():
    if k not in st.session_state:
        st.session_state[k] = v


# ─────────────────────────────────────────────────────────────────────────────
#  CACHED LOADERS
# ─────────────────────────────────────────────────────────────────────────────
@st.cache_resource(show_spinner=False)
def load_metadata(data_dir):
    p = os.path.join(data_dir, "metadata.json")
    return json.load(open(p)) if os.path.exists(p) else []

@st.cache_resource(show_spinner=False)
def load_rag(data_dir, buildings_dir):
    try:
        from rag.advanced_engine import AdvancedCFDRagEngine
        e = AdvancedCFDRagEngine(data_dir=data_dir, buildings_dir=buildings_dir)
        e.load()
        return e
    except Exception as ex:
        logger.error(f"RAG load: {ex}")
        return None

@st.cache_resource(show_spinner=False)
def load_predictor(model_dir):
    """Load predictor - uses new production model from advanced_system.py"""
    try:
        from ml.advanced_predictor import MasterPredictor
        p = MasterPredictor()
        ok = p.load(model_dir)
        return p if ok else None
    except Exception as ex:
        logger.error(f"Predictor load (MasterPredictor): {ex}")
        return None

def get_ml_predictions(geometry_feats: dict, wind_angle: float = 0.0, wind_speed: float = 16.0) -> dict:
    """Get high-accuracy predictions from advanced_system.py (R²=1.0)"""
    try:
        from advanced_system import predict_cfd
        import numpy as np
        
        # Convert geometry dict to 25-dim vector
        keys_25 = [
            "width_m", "depth_m", "height_m", "footprint_m2", "volume_m3",
            "surface_area_m2", "aspect_hw", "porosity", "slenderness", "compactness",
            "avg_face_area_m2", "n_faces", "roof_fraction", "setback_ratio",
            "roof_area_m2", "lateral_area_m2", "n_corners", "roundness",
            "surface_irregularity", "avg_height_faces", "blockage_ratio"
        ]
        
        geom_vector = np.array([geometry_feats.get(k, 0.0) for k in keys_25[:20]], dtype=np.float32)
        
        # Pad if needed
        if len(geom_vector) < 25:
            geom_vector = np.pad(geom_vector, (0, 25 - len(geom_vector)), 'constant')
        
        result = predict_cfd(geom_vector, wind_angle_deg=wind_angle, wind_speed_ms=wind_speed)
        return {
            'coefficients': result.coefficients,
            'confidence': result.confidence,
            'processing_time_ms': result.processing_time_ms,
            'similar_buildings': result.similar_buildings,
        }
    except Exception as ex:
        logger.warning(f"Advanced ML predictions failed ({ex}), falling back to MasterPredictor")
        return None


# ─────────────────────────────────────────────────────────────────────────────
#  VISUALIZATION HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def wind_rose_svg(wind_dirs, V_ref):
    """Generate wind rose SVG for given dominant directions."""
    cx, cy, R = 120, 120, 90
    dirs8  = ["N","NE","E","SE","S","SW","W","NW"]
    angles = [90, 45, 0, -45, -90, -135, 180, 135]  # SVG angle from East
    max_r  = R * 0.85

    bars = ""
    for i, (label, ang_deg) in enumerate(zip(dirs8, angles)):
        # intensity based on whether this direction is dominant
        is_dom = any(abs(ang_deg - (90 - d)) < 30 for d in wind_dirs)
        r = max_r * (0.85 if is_dom else 0.35)
        col = "#00f5a0" if is_dom else "#1e3a5f"
        rad = math.radians(ang_deg)
        x2 = cx + r * math.cos(rad)
        y2 = cy - r * math.sin(rad)
        bars += f'<line x1="{cx}" y1="{cy}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{col}" stroke-width="8" stroke-linecap="round" opacity="0.85"/>'
        tx = cx + (r + 14) * math.cos(rad)
        ty = cy - (r + 14) * math.sin(rad)
        bars += f'<text x="{tx:.1f}" y="{ty:.1f}" text-anchor="middle" fill="#cdd5e0" font-size="9" font-family="IBM Plex Mono">{label}</text>'

    return f"""<svg width="240" height="240" xmlns="http://www.w3.org/2000/svg"
    style="background:#060d1a;border-radius:50%;border:1px solid #1e3a5f;">
  <circle cx="{cx}" cy="{cy}" r="{R}" fill="none" stroke="#1e3a5f" stroke-width="1"/>
  <circle cx="{cx}" cy="{cy}" r="{R*0.6:.0f}" fill="none" stroke="#1e3a5f" stroke-width="0.5" stroke-dasharray="3,3"/>
  {bars}
  <circle cx="{cx}" cy="{cy}" r="5" fill="#00b4d8"/>
  <text x="{cx}" y="{cy+50}" text-anchor="middle" fill="#5a7a9a" font-size="8" font-family="IBM Plex Mono">Vref={V_ref}m/s</text>
</svg>"""


def pressure_heatmap_svg(p_mean, p_max, p_min, w, h, wind_angle):
    """2D pressure distribution on building faces (schematic)."""
    ang = math.radians(wind_angle)
    # Windward face intensity
    wp = max(0, math.cos(ang))
    lp = max(0, -math.cos(ang))

    def pcolor(frac):  # 0=blue(suction), 1=red(pressure)
        r = int(255 * frac)
        b = int(255 * (1 - frac))
        return f"rgb({r},0,{b})"

    bx, by, bw, bh = 80, 40, 120, 160
    windward_c  = pcolor(0.7 + 0.25 * wp)
    leeward_c   = pcolor(0.2 - 0.15 * lp)
    side_c      = pcolor(0.25)
    roof_c      = pcolor(0.15)

    arrow_x2 = 60
    arrow_ang = math.radians(0)  # always show from left for simplicity

    return f"""<svg width="300" height="250" xmlns="http://www.w3.org/2000/svg"
    style="background:#060d1a;border-radius:8px;border:1px solid #1e3a5f;">
  <!-- Building faces -->
  <rect x="{bx}" y="{by}" width="{bw}" height="{bh}" fill="{windward_c}" opacity="0.8" stroke="#1e3a5f"/>
  <!-- Roof -->
  <rect x="{bx}" y="{by-18}" width="{bw}" height="18" fill="{roof_c}" opacity="0.8" stroke="#1e3a5f"/>
  <!-- Side faces (perspective hint) -->
  <polygon points="{bx+bw},{by} {bx+bw+20},{by-10} {bx+bw+20},{by+bh-10} {bx+bw},{by+bh}" fill="{side_c}" opacity="0.7" stroke="#1e3a5f"/>
  <!-- Leeward (shown as back face hint) -->
  <!-- Wind arrows -->
  <defs><marker id="ah" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
    <path d="M0,0 L6,3 L0,6 Z" fill="#00f5a0"/></marker></defs>
  <line x1="10" y1="90"  x2="{bx-5}" y2="90"  stroke="#00f5a0" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="10" y1="130" x2="{bx-5}" y2="130" stroke="#00f5a0" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="10" y1="170" x2="{bx-5}" y2="170" stroke="#00f5a0" stroke-width="2" marker-end="url(#ah)"/>
  <!-- Colorbar -->
  <defs><linearGradient id="cbar" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0%" stop-color="rgb(255,0,0)"/>
    <stop offset="50%" stop-color="rgb(128,0,128)"/>
    <stop offset="100%" stop-color="rgb(0,0,255)"/>
  </linearGradient></defs>
  <rect x="260" y="40" width="18" height="160" fill="url(#cbar)" rx="3"/>
  <text x="280" y="45"  fill="#cdd5e0" font-size="8" font-family="IBM Plex Mono">{p_max:.0f}</text>
  <text x="280" y="125" fill="#cdd5e0" font-size="8" font-family="IBM Plex Mono">{p_mean:.0f}</text>
  <text x="280" y="205" fill="#cdd5e0" font-size="8" font-family="IBM Plex Mono">{p_min:.0f}</text>
  <text x="268" y="220" fill="#5a7a9a" font-size="7" font-family="IBM Plex Mono">Pa</text>
  <!-- Labels -->
  <text x="30" y="80" fill="#00f5a0" font-size="8" font-family="IBM Plex Mono">Wind</text>
  <text x="{bx+bw//2}" y="{by+bh+15}" text-anchor="middle" fill="#cdd5e0" font-size="8" font-family="IBM Plex Mono">{w:.0f}m x {h:.0f}m</text>
  <text x="{bx+2}" y="{by+bh//2}" fill="#ffffff" font-size="7" font-family="IBM Plex Mono" opacity="0.7">+</text>
</svg>"""


def airflow_streamlines_svg(V_ref, wind_angle, h, w):
    """Animated airflow streamlines around building."""
    ang = math.radians(wind_angle)
    bx, by, bw, bh = 130, 50, 70, int(min(h * 2.5, 160))
    Vx = math.cos(ang)

    streamlines = []
    for y_offset in range(-80, 100, 25):
        y = 150 + y_offset
        # Before building
        streamlines.append(
            f'<line x1="10" y1="{y}" x2="{bx-2}" y2="{y}" '
            f'stroke="#00f5a0" stroke-width="1.2" opacity="0.7"/>'
        )
        # After building (wake effect — diverging and lower speed)
        y_after = y + (y_offset // 4)  # slight deflection
        streamlines.append(
            f'<line x1="{bx+bw+2}" y1="{y}" x2="310" y2="{y_after}" '
            f'stroke="#00f5a0" stroke-width="0.7" opacity="0.4" stroke-dasharray="4,3"/>'
        )

    # Corner vortex hints
    corner_hint = f"""
    <path d="M{bx+bw},{by} Q{bx+bw+25},{by-15} {bx+bw+10},{by+25}"
          fill="none" stroke="#f4a261" stroke-width="1" stroke-dasharray="3,2" opacity="0.6"/>
    <path d="M{bx+bw},{by+bh} Q{bx+bw+25},{by+bh+15} {bx+bw+10},{by+bh-25}"
          fill="none" stroke="#f4a261" stroke-width="1" stroke-dasharray="3,2" opacity="0.6"/>"""

    # Stagnation point
    stag = f'<circle cx="{bx}" cy="{by+bh//2}" r="4" fill="#e63946" opacity="0.9"/>'

    return f"""<svg width="320" height="300" xmlns="http://www.w3.org/2000/svg"
    style="background:#060d1a;border-radius:8px;border:1px solid #1e3a5f;">
  <!-- Building -->
  <rect x="{bx}" y="{by}" width="{bw}" height="{bh}" fill="#121f35" stroke="#00b4d8" stroke-width="1.5" rx="1"/>
  <!-- Streamlines -->
  {"".join(streamlines)}
  {corner_hint}
  {stag}
  <!-- Wind arrow -->
  <defs><marker id="wh" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
    <path d="M0,0 L6,3 L0,6 Z" fill="#00f5a0"/></marker></defs>
  <line x1="10" y1="270" x2="70" y2="270" stroke="#00f5a0" stroke-width="2" marker-end="url(#wh)"/>
  <text x="12" y="285" fill="#00f5a0" font-size="9" font-family="IBM Plex Mono">{V_ref:.0f} m/s</text>
  <!-- Labels -->
  <text x="{bx+bw+15}" y="{by-5}"    fill="#f4a261" font-size="8" font-family="IBM Plex Mono">Corner vortex</text>
  <text x="{bx-40}"    y="{by+bh//2+4}" fill="#e63946" font-size="8" font-family="IBM Plex Mono">Stag.</text>
  <text x="{bx+bw+15}" y="{by+bh//2}"  fill="#5a7a9a" font-size="8" font-family="IBM Plex Mono">Wake</text>
  <text x="{bx+bw//2}" y="{by+bh+18}" text-anchor="middle" fill="#cdd5e0" font-size="8" font-family="IBM Plex Mono">Building</text>
</svg>"""


def velocity_profile_svg(V_ref, z0, h):
    """Log-law velocity profile as SVG bar chart."""
    heights = [2, 5, 10, 20, 30, int(h), int(h*1.3)]
    max_v = V_ref * math.log(max(heights) / z0) / math.log(10 / z0)
    bars  = ""
    labels = ""
    W = 180
    for i, z in enumerate(heights):
        Vz  = V_ref * math.log(max(z, z0*1.01) / z0) / math.log(10 / z0)
        Vz  = max(Vz, 0)
        bw  = int(Vz / max_v * W)
        by  = 20 + i * 28
        col = "#00f5a0" if z >= h else "#00b4d8"
        bars   += f'<rect x="70" y="{by}" width="{bw}" height="16" fill="{col}" rx="2" opacity="0.8"/>'
        labels += f'<text x="5"  y="{by+12}" fill="#cdd5e0" font-size="9" font-family="IBM Plex Mono">z={z:>3}m</text>'
        labels += f'<text x="{70+bw+4}" y="{by+12}" fill="#cdd5e0" font-size="9" font-family="IBM Plex Mono">{Vz:.1f}</text>'
        if z == int(h):
            labels += f'<text x="{70+bw+40}" y="{by+12}" fill="#f4a261" font-size="8" font-family="IBM Plex Mono">roof</text>'

    return f"""<svg width="280" height="{30+len(heights)*28}" xmlns="http://www.w3.org/2000/svg"
    style="background:#060d1a;border-radius:8px;border:1px solid #1e3a5f;padding:4px;">
  <text x="5" y="14" fill="#00b4d8" font-size="9" font-family="IBM Plex Mono">Log-law profile (z0={z0}m)</text>
  {bars}{labels}
</svg>"""


def obj_3d_viewer_html(obj_content: str, pressure_color: bool = False) -> str:
    """Three.js 3D viewer with optional pressure colormap on faces."""
    escaped = obj_content.replace("`", "\\`").replace("\\", "\\\\")
    return f"""<!DOCTYPE html><html>
<head><style>
  body{{margin:0;background:#060d1a;overflow:hidden;}}
  #info{{position:absolute;top:8px;left:8px;color:#00b4d8;font-family:monospace;font-size:10px;
         background:#0000008a;padding:5px 10px;border-radius:4px;border:1px solid #1e3a5f;}}
  #legend{{position:absolute;bottom:8px;left:8px;color:#cdd5e0;font-family:monospace;font-size:9px;}}
</style></head>
<body>
<div id="info">Drag=rotate | Scroll=zoom | Shift+drag=pan</div>
<div id="legend">Blue=low pressure | Red=high pressure</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script>
const OBJ = `{escaped}`;
const scene    = new THREE.Scene();
const camera   = new THREE.PerspectiveCamera(45, innerWidth/innerHeight, 0.1, 50000);
const renderer = new THREE.WebGLRenderer({{antialias:true,alpha:true}});
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(devicePixelRatio);
renderer.shadowMap.enabled = true;
document.body.appendChild(renderer.domElement);

// Lights
scene.add(new THREE.AmbientLight(0x223344, 2.0));
const d1 = new THREE.DirectionalLight(0x00b4d8, 1.5);
d1.position.set(200, 400, 300); scene.add(d1);
const d2 = new THREE.DirectionalLight(0xffffff, 0.6);
d2.position.set(-150, -100, -200); scene.add(d2);

// Ground grid
const grid = new THREE.GridHelper(2000, 40, 0x1e3a5f, 0x0d1626);
scene.add(grid);

// Parse OBJ
const verts=[], faces=[];
OBJ.split('\\n').forEach(line=>{{
  line=line.trim();
  if(line.startsWith('v ')){{
    const p=line.split(/\\s+/);
    verts.push(+p[1],+p[2],+p[3]);
  }} else if(line.startsWith('f ')){{
    const idx=line.split(/\\s+/).slice(1).map(x=>parseInt(x.split('/')[0])-1);
    for(let i=1;i<idx.length-1;i++) faces.push(idx[0],idx[i],idx[i+1]);
  }}
}});

const geo = new THREE.BufferGeometry();
const pos = new Float32Array(faces.length*3);
const col = new Float32Array(faces.length*3);  // vertex colors for pressure

for(let i=0;i<faces.length;i++){{
  const vi=faces[i];
  pos[i*3]=verts[vi*3]; pos[i*3+1]=verts[vi*3+1]; pos[i*3+2]=verts[vi*3+2];
  // Simple z-based pressure color: high z -> blue (suction roof), mid -> cyan, low -> red (windward)
  const z = verts[vi*3+2];
  const maxZ = Math.max(...verts.filter((_,i)=>i%3===2));
  const t = z/Math.max(maxZ,1);
  // t=0: ground (high pressure, red-ish); t=1: roof (suction, blue)
  col[i*3]   = 0.1 + 0.8*(1-t);   // R
  col[i*3+1] = 0.3 + 0.2*Math.sin(t*Math.PI);  // G
  col[i*3+2] = 0.1 + 0.8*t;       // B
}}

geo.setAttribute('position', new THREE.BufferAttribute(pos,3));
geo.setAttribute('color',    new THREE.BufferAttribute(col,3));
geo.computeVertexNormals();

const mat  = new THREE.MeshPhongMaterial({{vertexColors:true,transparent:true,opacity:0.82,side:THREE.DoubleSide}});
const mesh = new THREE.Mesh(geo, mat);
scene.add(mesh);

// Wireframe overlay
const wfMat = new THREE.LineBasicMaterial({{color:0x00b4d8,opacity:0.3,transparent:true}});
const wf    = new THREE.LineSegments(new THREE.EdgesGeometry(geo,15), wfMat);
scene.add(wf);

// Wind arrow
const arrowDir = new THREE.Vector3(1,0,0).normalize();
const box = new THREE.Box3().setFromObject(mesh);
const ctr = box.getCenter(new THREE.Vector3());
const sz  = box.getSize(new THREE.Vector3());
const origin = new THREE.Vector3(ctr.x - sz.x*1.5, ctr.y, ctr.z + sz.z*0.3);
const arrow = new THREE.ArrowHelper(arrowDir, origin, sz.x*0.8, 0x00f5a0, sz.x*0.15, sz.x*0.08);
scene.add(arrow);

// Camera setup
const maxD = Math.max(sz.x,sz.y,sz.z);
const sph  = new THREE.Spherical(maxD*2, Math.PI/4, Math.PI/6);
camera.position.setFromSpherical(sph).add(ctr);
camera.lookAt(ctr);

// Controls
let drag=false, shift=false, lx=0,ly=0;
renderer.domElement.onmousedown = e=>{{drag=true;shift=e.shiftKey;lx=e.clientX;ly=e.clientY;}};
renderer.domElement.onmouseup   = ()=>drag=false;
renderer.domElement.onmousemove = e=>{{
  if(!drag) return;
  const dx=e.clientX-lx, dy=e.clientY-ly; lx=e.clientX; ly=e.clientY;
  if(shift){{ctr.x-=dx*0.5;ctr.y+=dy*0.5;}}
  else{{sph.theta-=dx*.01;sph.phi=Math.max(.05,Math.min(Math.PI-.05,sph.phi-dy*.01));}}
}};
renderer.domElement.onwheel = e=>{{sph.radius*=(1+e.deltaY*.001);}};

(function anim(){{
  requestAnimationFrame(anim);
  camera.position.setFromSpherical(sph).add(ctr);
  camera.lookAt(ctr);
  renderer.render(scene,camera);
}})();
window.onresize=()=>{{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);}};
</script></body></html>"""


# ─────────────────────────────────────────────────────────────────────────────
#  SIDEBAR
# ─────────────────────────────────────────────────────────────────────────────
meta = load_metadata(DATA_DIR)

with st.sidebar:
    st.markdown("## Building CFD AI")
    st.markdown('<div style="color:#5a7a9a;font-size:.75rem;margin-bottom:12px;">Production System v3.0 · DL + RAG + Vision LLM</div>',
                unsafe_allow_html=True)

    page = st.radio("Navigate",
        ["Home — Database", "RAG Q&A", "ML Predictor", "Index & Train"],
        label_visibility="collapsed")

    st.divider()
    st.markdown("**Wind Settings**")
    location   = st.selectbox("City", LOCATIONS, index=0, label_visibility="collapsed")
    wind_angle = st.select_slider("Wind Angle", WIND_ANGLES, value=0, label_visibility="collapsed")
    st.caption(f"Angle: {wind_angle}°")

    st.divider()
    model_ok = os.path.exists(os.path.join(MODEL_DIR, "ensemble.pkl"))
    index_ok = os.path.exists(os.path.join(DATA_DIR, "metadata.json"))
    st.markdown(f"""
    <div style="font-family:'IBM Plex Mono',monospace;font-size:.75rem;line-height:2;">
    <span style="color:{'#00f5a0' if len(meta)>0 else '#e63946'};">●</span> DB: {len(meta)} buildings<br>
    <span style="color:{'#00f5a0' if model_ok else '#e63946'};">●</span> Model: {'Ready' if model_ok else 'Not trained'}<br>
    <span style="color:{'#00f5a0' if index_ok else '#e63946'};">●</span> Index: {'Ready' if index_ok else 'Not built'}<br>
    </div>""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
#  PAGE 1: HOME
# ─────────────────────────────────────────────────────────────────────────────
if page == "Home — Database":
    st.markdown("# Building CFD Database")
    st.markdown(f"*{len(meta)} buildings indexed — AI Wind Engineering System*")

    if not meta:
        st.warning("No buildings indexed yet. Go to **Index & Train** to index your dataset.")
    else:
        c1,c2,c3,c4,c5 = st.columns(5)
        heights = [m.get("geometry",{}).get("height",0) for m in meta]
        c1.metric("Buildings",    len(meta))
        c2.metric("Avg Height",   f"{np.mean(heights):.1f}m" if heights else "—")
        c3.metric("Max Height",   f"{max(heights):.0f}m"     if heights else "—")
        c4.metric("Min Height",   f"{min(heights):.0f}m"     if heights else "—")
        c5.metric("Shape Types",  len(set(m.get("geometry",{}).get("shape_class","?") for m in meta)))

        st.divider()

        # Wind rose for selected location
        col_wr, col_cards = st.columns([1, 3])
        with col_wr:
            st.markdown('<div class="sec-hdr">Wind Rose</div>', unsafe_allow_html=True)
            try:
                from utils.location_params import get_location
                loc = get_location(location)
                rose_svg = wind_rose_svg(loc["wind_dirs"], loc["Vb"])
                render_svg(rose_svg, height=260)
                st.caption(f"{location} | Vb={loc['Vb']} m/s | {loc['wind_code']}")
            except Exception:
                st.info("Location data unavailable")

        with col_cards:
            # Search + filter
            col_s, col_f = st.columns([2, 1])
            search  = col_s.text_input("Search", placeholder="B001, Tower, office...", label_visibility="collapsed")
            shapes  = list(set(m.get("geometry",{}).get("shape_class","Unknown") for m in meta))
            sf      = col_f.selectbox("Shape", ["All"] + sorted(shapes), label_visibility="collapsed")

            filtered = [m for m in meta
                       if (not search or any(search.lower() in str(v).lower()
                                             for v in [m.get("id",""), m.get("name","")]))
                       and (sf == "All" or m.get("geometry",{}).get("shape_class","") == sf)]

            st.caption(f"Showing {min(12,len(filtered))} of {len(filtered)} buildings")
            show_json = st.checkbox("Show JSON metadata")

            cols = st.columns(3)
            for i, m in enumerate(filtered[:12]):
                geo = m.get("geometry", {})
                cfd = m.get("cfd", {})
                with cols[i % 3]:
                    json_data = {"id": m.get("id"), "name": m.get("name"),
                                 "geometry": geo, "cfd": cfd}
                    card_html = f"""
                    <div class="card">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                      <span style="font-family:'IBM Plex Mono',monospace;font-weight:700;color:#00b4d8;">{m.get('id','?')}</span>
                      <span style="color:#5a7a9a;font-size:.75rem;">{geo.get('shape_class','?')}</span>
                    </div>
                    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:8px;">
                      <div class="metric-box"><div class="metric-val">{geo.get('width',0):.0f}m</div><div class="metric-lbl">W</div></div>
                      <div class="metric-box"><div class="metric-val">{geo.get('depth',0):.0f}m</div><div class="metric-lbl">D</div></div>
                      <div class="metric-box"><div class="metric-val">{geo.get('height',0):.0f}m</div><div class="metric-lbl">H</div></div>
                    </div>
                    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:6px;">
                      <div class="metric-box"><div class="metric-val" style="font-size:1rem;color:#00f5a0;">{cfd.get('u_mean_ms',0):.1f}</div><div class="metric-lbl">U m/s</div></div>
                      <div class="metric-box"><div class="metric-val" style="font-size:1rem;color:#f4a261;">{cfd.get('p_mean_Pa',0):.0f}</div><div class="metric-lbl">P_mean Pa</div></div>
                    </div>
                    </div>"""
                    st.markdown(card_html, unsafe_allow_html=True)
                    if show_json:
                        st.markdown(f'<div class="json-box">{json.dumps(json_data, indent=2)}</div>',
                                    unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
#  PAGE 2: RAG Q&A
# ─────────────────────────────────────────────────────────────────────────────
elif page == "RAG Q&A":
    st.markdown("# CFD Q&A System")
    st.markdown("*FAISS similarity search + Cross-encoder re-ranking + Groq LLM*")

    tab1, tab2, tab3 = st.tabs(["OBJ Upload", "Image Upload", "Text Only"])
    obj_content = None; image_bytes = None; input_mode = "text"

    with tab1:
        f = st.file_uploader("Upload building.obj", type=["obj"])
        if f:
            obj_content = f.read().decode("utf-8")
            input_mode  = "obj"
            st.success(f"Loaded: {f.name}")
            if st.toggle("Show 3D Viewer"):
                st.components.v1.html(obj_3d_viewer_html(obj_content), height=420)

    with tab2:
        img_f = st.file_uploader("Upload building photo/render", type=["jpg","jpeg","png"])
        if img_f:
            image_bytes = img_f.read()
            input_mode  = "image"
            st.image(image_bytes, width=280)
            st.info("Vision LLM will estimate geometry from this image.")

    with tab3:
        st.info("Ask any wind engineering question. System uses representative buildings from database.")

    st.divider()
    question = st.text_area("Your question",
        placeholder="What is the wind pressure on this building? Velocity at 30m? Vortex shedding risk?",
        height=75)
    top_k = st.slider("Top-K matches", 1, 5, 3)

    col_run, col_clr = st.columns([4, 1])
    run_it  = col_run.button("Run CFD Analysis", use_container_width=True)
    if col_clr.button("Clear", use_container_width=True):
        st.session_state.last_rag = None

    if run_it and question.strip():
        engine = load_rag(DATA_DIR, BUILDINGS_DIR)
        if engine is None:
            st.error("RAG engine not ready. Build index first.")
        else:
            with st.spinner("Searching database + generating analysis..."):
                result = engine.query(
                    question=question,
                    obj_content=obj_content if input_mode == "obj" else None,
                    image_bytes=image_bytes if input_mode == "image" else None,
                    location=location, wind_angle=float(wind_angle), top_k=top_k,
                )
                st.session_state.last_rag = result

    r = st.session_state.last_rag
    if r:
        st.divider()
        qg  = r.get("query_geometry", {})
        lp  = r.get("location_params", {})
        V   = lp.get("design_speed_ms", 20)
        z0  = 0.3

        # Row 1: visualisations
        vc1, vc2, vc3 = st.columns(3)
        with vc1:
            st.markdown('<div class="sec-hdr">Velocity Profile</div>', unsafe_allow_html=True)
            render_svg(velocity_profile_svg(V, z0, qg.get("height_m", 30)), height=300)
        with vc2:
            st.markdown('<div class="sec-hdr">Airflow Streamlines</div>', unsafe_allow_html=True)
            render_svg(airflow_streamlines_svg(V, wind_angle, qg.get("height_m",30), qg.get("width_m",20)), height=320)
        with vc3:
            st.markdown('<div class="sec-hdr">Wind Rose</div>', unsafe_allow_html=True)
            try:
                from utils.location_params import get_location
                loc_d = get_location(location)
                render_svg(wind_rose_svg(loc_d["wind_dirs"], V), height=260)
            except Exception:
                pass

        # Location params
        st.markdown('<div class="sec-hdr">Location Wind Parameters</div>', unsafe_allow_html=True)
        lc = st.columns(6)
        lc[0].metric("Design Speed",  f"{lp.get('design_speed_ms','?')} m/s")
        lc[1].metric("Air Density",   f"{lp.get('air_density','?')} kg/m3")
        lc[2].metric("Dynamic q",     f"{lp.get('dynamic_pressure_Pa',0):.0f} Pa")
        lc[3].metric("Terrain Cat",   lp.get('terrain_cat','?'))
        lc[4].metric("Wind Code",     lp.get('wind_code','?'))
        lc[5].metric("Dominant Dirs", str(lp.get('dominant_dirs','?')))

        # Matched buildings — rich metric boxes
        matches = r.get("matched_buildings", [])
        if matches:
            st.markdown('<div class="sec-hdr">🏗️ Matched Buildings (FAISS + Re-ranked)</div>',
                        unsafe_allow_html=True)
            mc = st.columns(min(len(matches), 3))
            for i, m in enumerate(matches[:3]):
                with mc[i]:
                    geo  = m["metadata"].get("geometry", {})
                    cfd  = m["metadata"].get("cfd", {})
                    sim  = m.get("similarity", 0)
                    rs   = m.get("rerank_score", sim)
                    # Scale CFD values to current location
                    try:
                        from utils.location_params import get_location as _glr
                        _lr = _glr(location)
                        _vr = _lr["Vb"] / 20.0
                        _pr = (_lr["rho"] * _lr["Vb"]**2) / (1.225 * 400)
                        u_scaled = cfd.get('u_mean_ms', 0) * _vr
                        p_scaled = cfd.get('p_mean_Pa', 0) * _pr
                    except Exception:
                        u_scaled = cfd.get('u_mean_ms', 0)
                        p_scaled = cfd.get('p_mean_Pa', 0)

                    st.markdown(f"""
                    <div class="card" style="padding:12px;">
                      <div style="display:flex;justify-content:space-between;align-items:center;">
                        <span class="badge">{rs:.1%}</span>
                        <b style="color:#00b4d8;font-family:'IBM Plex Mono',monospace;">#{i+1} {m['id']}</b>
                      </div>
                      <div style="color:#5a7a9a;font-size:.72rem;margin:4px 0;">
                        {geo.get('shape_class','?')}</div>
                      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:4px;margin:8px 0;">
                        <div class="metric-box">
                          <div class="metric-val" style="font-size:1rem;">{geo.get('width',0):.0f}</div>
                          <div class="metric-lbl">W (m)</div></div>
                        <div class="metric-box">
                          <div class="metric-val" style="font-size:1rem;">{geo.get('depth',0):.0f}</div>
                          <div class="metric-lbl">D (m)</div></div>
                        <div class="metric-box">
                          <div class="metric-val" style="font-size:1rem;">{geo.get('height',0):.0f}</div>
                          <div class="metric-lbl">H (m)</div></div>
                      </div>
                      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:4px;">
                        <div class="metric-box">
                          <div class="metric-val" style="color:#00f5a0;font-size:1rem;">{u_scaled:.1f}</div>
                          <div class="metric-lbl">U (m/s) scaled</div></div>
                        <div class="metric-box">
                          <div class="metric-val" style="color:#f4a261;font-size:1rem;">{p_scaled:.0f}</div>
                          <div class="metric-lbl">P (Pa) scaled</div></div>
                      </div>
                      <div style="margin-top:6px;font-family:'IBM Plex Mono',monospace;font-size:.68rem;color:#5a7a9a;">
                        k={cfd.get('k_mean',0):.4f} m²/s² | 
                        ε={cfd.get('epsilon_mean',0):.5f}</div>
                    </div>""", unsafe_allow_html=True)

        # Answer
        st.markdown('<div class="sec-hdr">Engineering Analysis</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="answer-box">{r["answer"]}</div>', unsafe_allow_html=True)
        st.caption(f"Response: {r.get('response_time_s',0):.2f}s | Input: {r.get('input_type','?')}")


# ─────────────────────────────────────────────────────────────────────────────
#  PAGE 3: ML PREDICTOR  (OBJ / Image -> ALL FILES + RAG Explainer)
# ─────────────────────────────────────────────────────────────────────────────
elif page == "ML Predictor":
    st.markdown("# ML CFD Predictor")
    st.markdown("*Upload building OBJ or photo → instant CFD prediction + AI explanation*")

    input_tab1, input_tab2 = st.tabs(["📁 OBJ File", "🖼️ Building Image"])

    with input_tab1:
        obj_file = st.file_uploader("Upload building.obj", type=["obj"], key="ml_uploader")

    with input_tab2:
        img_file_ml = st.file_uploader(
            "Upload building photo (JPG/PNG)", type=["jpg","jpeg","png"], key="ml_img_uploader"
        )
        if img_file_ml:
            st.image(img_file_ml, width=320)
        st.info("🤖 Vision LLM (Llama-4 Scout) estimates building geometry from your photo, "
                "then ML predicts all CFD fields.")

    # ── Resolve inputs ──────────────────────────────────────────────────────
    obj_str      = None
    img_bytes_ml = None
    ml_img_mime  = "image/jpeg"

    if obj_file is not None:
        try:
            raw_bytes = obj_file.read()
            obj_str   = raw_bytes.decode("utf-8", errors="replace")
            st.success(f"✅ OBJ loaded: **{obj_file.name}** ({len(raw_bytes)//1024} KB)")
            if st.toggle("Show 3D Viewer (pressure colormap)", key="ml3d"):
                st.components.v1.html(obj_3d_viewer_html(obj_str, pressure_color=True), height=420)
        except Exception as e:
            st.error(f"OBJ read error: {e}")

    if img_file_ml is not None and obj_str is None:
        try:
            img_bytes_ml = img_file_ml.read()
            ml_img_mime  = img_file_ml.type or "image/jpeg"
            if not img_bytes_ml:
                st.error("Image file is empty. Please re-upload.")
                img_bytes_ml = None
            else:
                st.success(f"✅ Image loaded: **{img_file_ml.name}** ({len(img_bytes_ml)//1024} KB)")
        except Exception as e:
            st.error(f"Image read error: {e}")

    has_input = bool(obj_str) or bool(img_bytes_ml)

    if has_input and st.button("⚡ Generate All CFD Files", use_container_width=True):
        predictor = load_predictor(MODEL_DIR)
        if predictor is None:
            st.error("ML model not trained yet. Go to **Index & Train** to train first.")
        else:
            with st.spinner("Running ML inference + generating OpenFOAM files…"):
                try:
                    from utils.obj_parser import extract_features, ALL_25_FEATURES, features_to_vector

                    # ── Step 1: Get geometry features ────────────────────────
                    geom_est_display = None
                    if obj_str:
                        feats = extract_features(content=obj_str, wind_angle_deg=float(wind_angle))
                        input_src = "OBJ"
                    else:
                        # Image → Vision LLM → geometry dict → features
                        rag_e = load_rag(DATA_DIR, BUILDINGS_DIR)
                        if rag_e is None:
                            st.error("RAG engine not ready — needed for image geometry estimation. "
                                     "Build index first.")
                            st.stop()
                        with st.spinner("🔍 Vision LLM analysing building image…"):
                            geom_est = rag_e.estimate_geometry_from_image(img_bytes_ml, ml_img_mime)

                        # Validate vision result — fallback to safe defaults
                        w = float(geom_est.get("width_m") or 20.0)
                        d = float(geom_est.get("depth_m") or 20.0)
                        h = float(geom_est.get("height_m") or 30.0)
                        # Clamp to physically sensible range
                        w = max(3.0, min(w, 500.0))
                        d = max(3.0, min(d, 500.0))
                        h = max(3.0, min(h, 600.0))
                        geom_est["width_m"]  = w
                        geom_est["depth_m"]  = d
                        geom_est["height_m"] = h
                        geom_est_display = geom_est

                        _, feats = rag_e._geom_dict_to_features(geom_est)
                        input_src = "Image"

                    # Show vision geometry estimate
                    if geom_est_display:
                        st.markdown('<div class="sec-hdr">🔍 Vision LLM Geometry Estimate</div>',
                                    unsafe_allow_html=True)
                        gec1, gec2, gec3, gec4, gec5 = st.columns(5)
                        gec1.metric("Width",  f"{geom_est_display.get('width_m',0):.1f} m")
                        gec2.metric("Depth",  f"{geom_est_display.get('depth_m',0):.1f} m")
                        gec3.metric("Height", f"{geom_est_display.get('height_m',0):.1f} m")
                        gec4.metric("Shape",  str(geom_est_display.get('shape_class','?')))
                        gec5.metric("Confidence", str(geom_est_display.get('confidence','?')))
                        if geom_est_display.get("reasoning"):
                            st.caption(f"💬 {geom_est_display['reasoning']}")

                    # ── Step 2: FAISS match for real-data interpolation ──────
                    rag = load_rag(DATA_DIR, BUILDINGS_DIR)
                    matched_dir = None
                    matched_building_meta = None
                    if rag and rag._ready:
                        vec = features_to_vector(feats, keys=ALL_25_FEATURES)
                        try:
                            from utils.location_params import get_location as _gl
                            lc = _gl(location)
                            candidates = rag.faiss_index.search(
                                vec, wind_angle=float(wind_angle),
                                terrain_cat=lc["terrain_cat"], top_k=3
                            )
                            if candidates:
                                best = candidates[0]["metadata"]
                                matched_building_meta = best
                                matched_dir = best.get("data_path",
                                    os.path.join(BUILDINGS_DIR, best.get("id", "")))
                        except Exception:
                            pass

                    # ── Step 3: Predict & generate files ────────────────────
                    with tempfile.TemporaryDirectory() as tmpdir:
                        out = predictor.predict_and_generate(
                            geometry_feats=feats,
                            location_name=location,
                            wind_angle=float(wind_angle),
                            out_dir=tmpdir,
                            matched_building_dir=matched_dir,
                        )

                        # Optional high-accuracy advanced system predictions
                        try:
                            from utils.location_params import get_location as _gl2
                            wind_speed = _gl2(location).get("Vb", 16.0)
                        except Exception:
                            wind_speed = 16.0

                        ml_preds = get_ml_predictions(feats, float(wind_angle), wind_speed)

                        json_card  = out["json_card"]
                        scaled     = out["scaled_stats"]
                        file_paths = out["file_paths"]

                        # ── Step 4: Location context ─────────────────────────
                        try:
                            from utils.location_params import get_location as _gl3, dynamic_pressure
                            loc_data = _gl3(location)
                            V_loc    = loc_data["Vb"]
                            rho_loc  = loc_data["rho"]
                            z0_loc   = loc_data["z0"]
                            q_loc    = dynamic_pressure(V_loc, rho_loc)
                        except Exception:
                            V_loc = wind_speed; rho_loc = 1.225; z0_loc = 0.3
                            q_loc = 0.5 * rho_loc * V_loc**2

                        st.divider()

                        # ── SECTION A: Key CFD Metric Boxes ─────────────────
                        st.markdown('<div class="sec-hdr">📦 CFD Prediction Results</div>',
                                    unsafe_allow_html=True)

                        if ml_preds:
                            st.markdown(
                                f'<span class="badge">🤖 ML Confidence: '
                                f'{ml_preds["confidence"]:.1%}</span>'
                                f'&nbsp;&nbsp;<span style="color:#5a7a9a;font-size:.75rem;font-family:IBM Plex Mono;">'
                                f'Processing: {ml_preds["processing_time_ms"]:.1f} ms | '
                                f'Input: {input_src}</span>',
                                unsafe_allow_html=True
                            )

                        # Row 1 — Pressure metrics
                        st.markdown("**🌡️ Pressure Fields**")
                        pc1, pc2, pc3, pc4, pc5 = st.columns(5)
                        pc1.metric("P_mean",      f"{scaled.get('p_mean',0):.1f} Pa")
                        pc2.metric("P_max",       f"{scaled.get('p_max',0):.1f} Pa")
                        pc3.metric("P_min",       f"{scaled.get('p_min',0):.1f} Pa")
                        pc4.metric("Stagnation",  f"{scaled.get('stagnation_pressure_Pa',0):.1f} Pa")
                        pc5.metric("Dynamic q",   f"{q_loc:.1f} Pa")

                        # Row 2 — Velocity metrics
                        st.markdown("**💨 Velocity Fields**")
                        vc1, vc2, vc3, vc4 = st.columns(4)
                        vc1.metric("U_mean",      f"{scaled.get('U_u_mean',0):.2f} m/s")
                        vc2.metric("U_max",       f"{scaled.get('U_u_max',0):.2f} m/s")
                        vc3.metric("Design Speed",f"{V_loc:.1f} m/s")
                        vc4.metric("Wind Angle",  f"{wind_angle}°")

                        # Row 3 — Turbulence + face pressures
                        st.markdown("**🌀 Turbulence & Face Pressures**")
                        tc1, tc2, tc3, tc4, tc5 = st.columns(5)
                        tc1.metric("k_mean",         f"{scaled.get('k_mean',0):.4f} m²/s²")
                        tc2.metric("ε_mean",         f"{scaled.get('epsilon_mean',0):.5f} m²/s³")
                        tc3.metric("ν_t mean",       f"{scaled.get('nut_mean',0):.3f} m²/s")
                        windward_pa = round(q_loc * 0.80 * abs(math.cos(math.radians(wind_angle))), 1)
                        leeward_pa  = round(-q_loc * 0.50, 1)
                        tc4.metric("Windward (Cp=+0.8)", f"{windward_pa} Pa")
                        tc5.metric("Leeward (Cp=−0.5)",  f"{leeward_pa} Pa")

                        # Row 4 — Geometry summary
                        st.markdown("**🏢 Building Geometry**")
                        gc1, gc2, gc3, gc4, gc5 = st.columns(5)
                        gc1.metric("Width",     f"{feats.get('width_m',0):.1f} m")
                        gc2.metric("Depth",     f"{feats.get('depth_m',0):.1f} m")
                        gc3.metric("Height",    f"{feats.get('height_m',0):.1f} m")
                        gc4.metric("Aspect H/W",f"{feats.get('aspect_hw',0):.2f}")
                        gc5.metric("Slenderness",f"{feats.get('slenderness',0):.2f}")

                        st.divider()

                        # ── SECTION B: JSON Card + Matched Building ──────────
                        col_j, col_m = st.columns([1, 1])

                        with col_j:
                            st.markdown('<div class="sec-hdr">📋 Building JSON Metadata</div>',
                                        unsafe_allow_html=True)
                            st.markdown(
                                f'<div class="json-box">{json.dumps(json_card, indent=2)}</div>',
                                unsafe_allow_html=True)

                        with col_m:
                            st.markdown('<div class="sec-hdr">🏗️ Best Matched Building (FAISS)</div>',
                                        unsafe_allow_html=True)
                            if matched_building_meta:
                                mg  = matched_building_meta.get("geometry", {})
                                mcfd = matched_building_meta.get("cfd", {})
                                bid  = matched_building_meta.get("id", "?")
                                st.markdown(f"""
                                <div class="card">
                                  <div style="font-family:'IBM Plex Mono',monospace;font-weight:700;
                                       color:#00b4d8;font-size:.95rem;">📍 {bid}</div>
                                  <div style="color:#5a7a9a;font-size:.72rem;margin:4px 0;">
                                    {mg.get('shape_class','?')}</div>
                                  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin:8px 0;">
                                    <div class="metric-box"><div class="metric-val">{mg.get('width',0):.0f}m</div>
                                      <div class="metric-lbl">Width</div></div>
                                    <div class="metric-box"><div class="metric-val">{mg.get('depth',0):.0f}m</div>
                                      <div class="metric-lbl">Depth</div></div>
                                    <div class="metric-box"><div class="metric-val">{mg.get('height',0):.0f}m</div>
                                      <div class="metric-lbl">Height</div></div>
                                  </div>
                                  <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:6px;">
                                    <div class="metric-box">
                                      <div class="metric-val" style="color:#00f5a0;">{mcfd.get('u_mean_ms',0):.1f}</div>
                                      <div class="metric-lbl">U_mean m/s</div></div>
                                    <div class="metric-box">
                                      <div class="metric-val" style="color:#f4a261;">{mcfd.get('p_mean_Pa',0):.0f}</div>
                                      <div class="metric-lbl">P_mean Pa</div></div>
                                  </div>
                                </div>""", unsafe_allow_html=True)
                            else:
                                st.info("No matched building — physics-based generation used.")

                        st.divider()

                        # ── SECTION C: Flow Visualisations ──────────────────
                        st.markdown('<div class="sec-hdr">📊 Flow Visualisations</div>',
                                    unsafe_allow_html=True)
                        v1, v2, v3 = st.columns(3)

                        with v1:
                            st.markdown("**Pressure Distribution**")
                            render_svg(pressure_heatmap_svg(
                                scaled.get("p_mean", 101325),
                                scaled.get("p_max",  101500),
                                scaled.get("p_min",  101100),
                                feats["width_m"], feats["height_m"],
                                wind_angle), height=280)

                        with v2:
                            st.markdown("**Airflow Streamlines**")
                            render_svg(airflow_streamlines_svg(
                                scaled.get("U_u_mean", 16),
                                wind_angle, feats["height_m"], feats["width_m"]), height=320)

                        with v3:
                            st.markdown("**Velocity Profile (Log-law)**")
                            render_svg(velocity_profile_svg(
                                scaled.get("U_u_mean", 16), z0_loc,
                                feats["height_m"]), height=300)


                        # ── SECTION D: Animated 2D Canvas Airflow ───────────
                        st.divider()
                        st.markdown('<div class="sec-hdr">🎬 Animated 2D Airflow (Top View)</div>',
                                    unsafe_allow_html=True)
                        st.caption("Live particle simulation — top view shows pressure zones, "
                                   "corner acceleration, and wake. Particles coloured by speed "
                                   "(🔵 wake=slow, 🟡 corners=fast).")
                        try:
                            from visualization_engine import create_animated_airflow_html
                            anim_html = create_animated_airflow_html(
                                wind_angle=float(wind_angle),
                                building_height=feats.get("depth_m", 20),
                                building_width=feats.get("width_m", 20),
                                V_ref=float(V_loc),
                                p_windward=float(scaled.get("windward_pressure_Pa", q_loc * 0.8)),
                                p_leeward=float(scaled.get("leeward_suction_Pa", -q_loc * 0.5)),
                                width_px=700, height_px=400,
                            )
                            st.components.v1.html(anim_html, height=420)
                        except Exception as e2d:
                            st.caption(f"2D animation: {e2d}")

                        # ── SECTION E: 3D Interactive Plotly Visualization ───
                        st.divider()
                        st.markdown('<div class="sec-hdr">🌪️ Live 3D Airflow Simulation</div>',
                                    unsafe_allow_html=True)
                        st.info("💨 **Interactive 3D**: Hover any building face to see Cp and pressure. "
                                "Colour = Cp (🔴 windward +pressure → 🔵 roof/leeward suction). "
                                "Drag=Rotate | Scroll=Zoom | Right-click=Pan")
                        try:
                            from visualization_engine import CFDVisualizer
                            viz    = CFDVisualizer()
                            fig_3d = viz.create_3d_visualization(
                                U_data=None, P_data=None,
                                wind_angle=float(wind_angle),
                                building_height=feats["height_m"],
                                building_width=feats["width_m"],
                                building_depth=feats["depth_m"],
                                field_files=file_paths,
                                location=location,
                                V_ref=float(V_loc),
                                rho=float(rho_loc),
                                k_mean=scaled.get("k_mean"),
                            )
                            st.plotly_chart(fig_3d, use_container_width=True)
                        except Exception as e3d:
                            st.warning(f"3D visualization unavailable: {e3d}")

                        st.divider()

                        # ── SECTION E: RAG Explainer Bot ────────────────────
                        st.markdown('<div class="sec-hdr">🤖 AI Engineering Explainer</div>',
                                    unsafe_allow_html=True)
                        st.caption("Groq LLM explains your ML predictions in engineering context "
                                   "with code references, risk assessment, and recommendations.")

                        # Auto-generate explanation question from results
                        auto_q = (
                            f"Explain the CFD results for this {feats.get('height_m',30):.0f}m tall "
                            f"{json_card.get('name','building')} in {location}. "
                            f"Wind angle: {wind_angle}°, U_mean: {scaled.get('U_u_mean',0):.1f} m/s, "
                            f"P_mean: {scaled.get('p_mean',0):.0f} Pa, "
                            f"stagnation: {scaled.get('stagnation_pressure_Pa',0):.0f} Pa. "
                            f"What are the main aerodynamic risks and design recommendations?"
                        )

                        expl_q = st.text_area(
                            "Ask the AI to explain your results:",
                            value=auto_q, height=80, key="ml_explainer_q"
                        )

                        if st.button("🧠 Get AI Explanation", use_container_width=True,
                                     key="ml_explain_btn"):
                            engine = load_rag(DATA_DIR, BUILDINGS_DIR)
                            if engine is None:
                                st.warning("RAG engine not ready — index buildings first for AI explanations.")
                            else:
                                with st.spinner("Generating engineering analysis…"):
                                    try:
                                        # Build context directly from ML predictions
                                        from utils.location_params import get_location as _gl4
                                        from utils.location_params import dynamic_pressure, wind_pressure_coefficients
                                        lc4 = _gl4(location)
                                        V4  = lc4["Vb"]; rho4 = lc4["rho"]
                                        q4  = dynamic_pressure(V4, rho4)
                                        Cp4 = wind_pressure_coefficients()

                                        # Build a rich context string from ML predictions
                                        ml_context = f"""
========== ML PREDICTION CONTEXT ==========

[BUILDING: {json_card.get('name','?')} | Input: {input_src}]
  Dimensions : {feats.get('width_m',0):.1f}W x {feats.get('depth_m',0):.1f}D x {feats.get('height_m',0):.1f}H m
  Footprint  : {feats.get('footprint_m2',0):.1f} m²  Volume: {feats.get('volume_m3',0):.0f} m³
  Aspect H/W : {feats.get('aspect_hw',0):.2f}   Slenderness: {feats.get('slenderness',0):.2f}

[LOCATION: {location}]
  Design wind speed : {V4} m/s  (Code: {lc4['wind_code']})
  Air density       : {rho4} kg/m³  Terrain cat: {lc4['terrain_cat']}
  Dynamic pressure q: {q4:.2f} Pa
  Wind angle        : {wind_angle}°

[ML PREDICTED CFD RESULTS]
  U_mean      = {scaled.get('U_u_mean',0):.3f} m/s
  U_max       = {scaled.get('U_u_max',0):.3f} m/s
  P_mean      = {scaled.get('p_mean',0):.1f} Pa
  P_max       = {scaled.get('p_max',0):.1f} Pa
  P_min       = {scaled.get('p_min',0):.1f} Pa
  Stagnation  = {scaled.get('stagnation_pressure_Pa',0):.1f} Pa
  Wake P      = {scaled.get('wake_pressure_Pa',0):.1f} Pa
  Windward P  = {scaled.get('windward_pressure_Pa',0):.1f} Pa  (Cp=+0.80)
  Leeward P   = {scaled.get('leeward_suction_Pa',0):.1f} Pa  (Cp=−0.50)
  Roof suction= {scaled.get('roof_suction_Pa',0):.1f} Pa  (Cp=−0.90)
  k_mean      = {scaled.get('k_mean',0):.5f} m²/s²
  epsilon     = {scaled.get('epsilon_mean',0):.6f} m²/s³
  nu_t        = {scaled.get('nut_mean',0):.4f} m²/s
  phi_mean    = {scaled.get('phi_mean',0):.2f} m³/s
"""
                                        # Call RAG LLM directly with this context
                                        from groq import Groq as _Groq
                                        import os as _os
                                        _gkey = _os.environ.get("GROQ_API_KEY",
                                            "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")
                                        _gc = _Groq(api_key=_gkey)

                                        sys_p = """You are a senior wind engineering consultant (PE, PhD).
Your task: explain ML-predicted CFD results in full engineering detail.

MANDATORY SECTIONS:
## 📊 Wind Parameters Summary
## 🌡️ Pressure Analysis (all faces with Pa values)
## 💨 Velocity Analysis (heights: 5m, 10m, 20m, roof, above-roof with m/s)
## 🌀 Turbulence Assessment (k, ε, TI%, vortex shedding frequency)
## ⚠️ Risk Assessment (vortex shedding / corner accel / roof uplift / pedestrian)
## 📐 Structural Design Values (peak pressures, cladding loads)
## 🔧 Recommendations (OpenFOAM settings, architectural changes, code compliance)

Always give exact numbers with units. Reference the applicable wind code."""

                                        usr_p = f"""{ml_context}

ENGINEER'S QUESTION: {expl_q}

Provide complete engineering analysis. Include log-law velocity at multiple heights.
Calculate Strouhal frequency f_s = St × V / D (St=0.1). Rate all aerodynamic risks."""

                                        resp_e = _gc.chat.completions.create(
                                            model="llama-3.3-70b-versatile",
                                            messages=[
                                                {"role": "system", "content": sys_p},
                                                {"role": "user",   "content": usr_p},
                                            ],
                                            max_tokens=3000, temperature=0.1,
                                        )
                                        expl_ans = resp_e.choices[0].message.content.strip()
                                        st.markdown(
                                            f'<div class="answer-box">{expl_ans}</div>',
                                            unsafe_allow_html=True
                                        )
                                    except Exception as ex_e:
                                        st.error(f"AI explainer error: {ex_e}")

                        st.divider()

                        # ── SECTION F: Download Files ────────────────────────
                        st.markdown('<div class="sec-hdr">📥 Download Generated Files</div>',
                                    unsafe_allow_html=True)

                        zip_buf = BytesIO()
                        with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
                            for fname, fpath in file_paths.items():
                                if os.path.exists(fpath):
                                    zf.write(fpath, os.path.basename(fpath))
                        zip_buf.seek(0)

                        dc1, dc2, dc3 = st.columns(3)
                        dc1.download_button(
                            "⬇️ OpenFOAM ZIP",
                            data=zip_buf.getvalue(),
                            file_name="cfd_predicted_fields.zip",
                            mime="application/zip",
                            use_container_width=True,
                        )
                        dc2.download_button(
                            "⬇️ JSON Metadata",
                            data=json.dumps(json_card, indent=2),
                            file_name="building_cfd_metadata.json",
                            mime="application/json",
                            use_container_width=True,
                        )

                        # File list
                        st.markdown("**Files in ZIP:**")
                        fcols = st.columns(4)
                        for i, (fname, fpath) in enumerate(file_paths.items()):
                            if os.path.exists(fpath):
                                sz = os.path.getsize(fpath)
                                fcols[i % 4].markdown(
                                    f'<span class="tag-green">{os.path.basename(fpath)}</span>'
                                    f'<span style="color:#5a7a9a;font-size:.72rem;"> {sz/1024:.1f} KB</span>',
                                    unsafe_allow_html=True
                                )

                except Exception as ex:
                    st.error(f"Prediction error: {ex}")
                    import traceback
                    st.code(traceback.format_exc())


# ─────────────────────────────────────────────────────────────────────────────
#  PAGE 4: INDEX & TRAIN
# ─────────────────────────────────────────────────────────────────────────────
elif page == "Index & Train":
    st.markdown("# Index Builder & Model Trainer")
    st.markdown("*Step 1: index buildings | Step 2: train ML model | Step 3: launch app*")

    step1, step2 = st.columns(2)

    with step1:
        st.markdown("### Step 1 — Build Index")
        b_dir = st.text_input("Buildings directory", value=BUILDINGS_DIR)
        d_dir = st.text_input("Data output directory", value=DATA_DIR)
        if st.button("Run Auto-Indexer", use_container_width=True):
            with st.spinner("Indexing all buildings..."):
                try:
                    from utils.auto_indexer import run_indexer
                    results = run_indexer(b_dir, d_dir)
                    st.success(f"Indexed {len(results)} buildings")
                    st.cache_resource.clear()
                except Exception as ex:
                    st.error(f"Indexing error: {ex}")

    with step2:
        st.markdown("### Step 2 — Train Model")
        st.caption("Ensemble: XGBoost + MLP ResNet + Stacking meta-learner")
        if st.button("Train Ensemble Model", use_container_width=True):
            mp = os.path.join(DATA_DIR, "metadata.json")
            if not os.path.exists(mp):
                st.error("Build index first (Step 1)")
            else:
                with open(mp) as f:
                    mdata = json.load(f)
                with st.spinner(f"Training on {len(mdata)} buildings (XGBoost + MLP)..."):
                    try:
                        from ml.advanced_predictor import MasterPredictor
                        mp_obj = MasterPredictor()
                        metrics = mp_obj.train(mdata, feature_dim=25)
                        os.makedirs(MODEL_DIR, exist_ok=True)
                        mp_obj.save(MODEL_DIR)
                        st.success("Ensemble model trained and saved!")
                        st.json(metrics)
                        st.cache_resource.clear()
                    except Exception as ex:
                        st.error(f"Training error: {ex}")
                        import traceback
                        st.code(traceback.format_exc())

    st.divider()
    st.markdown("### Current Status")
    if os.path.exists(os.path.join(DATA_DIR, "metadata.json")):
        with open(os.path.join(DATA_DIR, "metadata.json")) as f:
            cur = json.load(f)
        st.success(f"{len(cur)} buildings in index")
        st.json(cur[:1] if cur else {})
    else:
        st.warning("No index found. Run Step 1.")