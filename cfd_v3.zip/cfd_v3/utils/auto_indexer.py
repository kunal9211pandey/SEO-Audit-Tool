"""
utils/auto_indexer.py
---------------------
Auto-indexes all buildings in the data/buildings/ directory.

For each building folder (B001, B002, ...) it:
    1. Parses building.obj -> 25 geometric features
    2. Parses p, U, k, epsilon, nut, phi -> CFD statistics
    3. Derives human-readable metadata (name, shape, wind direction)
    4. Writes metadata.json and features.npy for FAISS

Usage:
    python utils/auto_indexer.py --data_dir buildings/ --out_dir data/

Progress bar shown during indexing.
Corrupted or incomplete folders are skipped with a warning.
"""

import os
import sys
import json
import argparse
import logging
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from typing import Dict, List, Optional, Tuple

import numpy as np

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Try to import our parsers (relative or absolute)
# ---------------------------------------------------------------------------
try:
    from utils.obj_parser import (
        extract_features, parse_all_fields, ALL_25_FEATURES, CORE_9_FEATURES
    )
    from utils.location_params import LOCATIONS
except ImportError:
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from utils.obj_parser import (
        extract_features, parse_all_fields, ALL_25_FEATURES, CORE_9_FEATURES
    )
    from utils.location_params import LOCATIONS


# ─────────────────────────────────────────────────────────────────────────────
#  BUILDING SHAPE CLASSIFIER (heuristic from geometry)
# ─────────────────────────────────────────────────────────────────────────────

def classify_shape(feats: Dict) -> str:
    h = feats["height_m"]
    w = feats["width_m"]
    d = feats["depth_m"]
    asp = feats["aspect_hw"]
    nf  = feats["n_faces"]

    if asp > 5.0:
        return "Supertall Tower"
    elif asp > 2.5:
        return "Tall Tower"
    elif asp > 1.5:
        return "Medium Tower"
    elif asp > 0.8:
        if feats["compactness"] < 0.75:
            return "L-Shape / Complex"
        return "Office Block"
    else:
        if w / max(d, 0.01) > 2.5:
            return "Wide Low Slab"
        return "Low Rise Block"


def extract_wind_angle_from_obj(obj_path: str) -> float:
    """Try to read wind angle from a comment in the OBJ file."""
    try:
        with open(obj_path) as f:
            for line in f:
                if "wind" in line.lower() and "angle" in line.lower():
                    import re
                    m = re.search(r"[-\d.]+", line)
                    if m:
                        return float(m.group())
    except Exception:
        pass
    return 0.0


# ─────────────────────────────────────────────────────────────────────────────
#  SINGLE BUILDING INDEXER
# ─────────────────────────────────────────────────────────────────────────────

def index_one_building(bid: str, bdir: str) -> Optional[Dict]:
    """
    Index a single building directory.
    Returns metadata dict or None if building is incomplete/corrupted.
    """
    obj_path = os.path.join(bdir, "building.obj")
    if not os.path.exists(obj_path):
        logger.warning(f"SKIP {bid}: building.obj not found")
        return None

    try:
        wind_angle = extract_wind_angle_from_obj(obj_path)
        feats = extract_features(filepath=obj_path, wind_angle_deg=wind_angle)
    except Exception as e:
        logger.warning(f"SKIP {bid}: OBJ parse error — {e}")
        return None

    # CFD field stats
    try:
        cfd = parse_all_fields(bdir)
    except Exception as e:
        logger.warning(f"  {bid}: CFD parse partial — {e}")
        cfd = {}

    shape = classify_shape(feats)

    # Build metadata entry
    meta = {
        "id":           bid,
        "name":         shape,
        "data_path":    bdir,
        "geometry": {
            "width":          round(feats["width_m"],  2),
            "depth":          round(feats["depth_m"],  2),
            "height":         round(feats["height_m"], 2),
            "floors":         max(1, int(round(feats["height_m"] / 3.0))),
            "points":         int(feats["n_vertices"]),
            "faces":          int(feats["n_faces"]),
            "footprint_m2":   round(feats["footprint_m2"], 1),
            "volume_m3":      round(feats["volume_m3"], 1),
            "frontal_area_m2": round(feats["frontal_area_m2"], 1),
            "aspect_ratio_hw": round(feats["aspect_hw"], 3),
            "aspect_ratio_hd": round(feats["aspect_hd"], 3),
            "slenderness":    round(feats["slenderness"], 3),
            "compactness":    round(feats["compactness"], 3),
            "shape_class":    shape,
        },
        "cfd": {
            "wind_reference_speed_ms": round(wind_angle, 1),  # will be overridden
            "cells":                   cfd.get("p_count", 66623),
            "p_mean_Pa":               round(cfd.get("p_mean",   101325), 2),
            "p_max_Pa":                round(cfd.get("p_max",    101500), 2),
            "p_min_Pa":                round(cfd.get("p_min",    101100), 2),
            "p_std_Pa":                round(cfd.get("p_std",    50),     2),
            "stagnation_pressure_Pa":  round(cfd.get("p_stagnation_pressure_Pa", 0) or
                                             cfd.get("p_mean", 101325) + 200, 2),
            "wake_pressure_Pa":        round(cfd.get("p_wake_pressure_Pa", 0) or
                                             cfd.get("p_mean", 101325) - 200, 2),
            "min_pressure_Pa":         round(cfd.get("p_min_pressure_Pa", 0) or
                                             cfd.get("p_min", 101100), 2),
            "u_mean_ms":               round(cfd.get("U_u_mean",    16.0), 4),
            "u_max_ms":                round(cfd.get("U_u_max",     21.0), 4),
            "u_min_ms":                round(cfd.get("U_u_min",      5.0), 4),
            "k_mean":                  round(cfd.get("k_mean",    1.35),   6),
            "k_max":                   round(cfd.get("k_max",     1.50),   6),
            "epsilon_mean":            round(cfd.get("epsilon_mean", 0.024), 6),
            "nut_mean":                round(cfd.get("nut_mean",   5.0),    6),
            "phi_mean":                round(cfd.get("phi_mean",  1900.0),  3),
        },
        "features_25": [round(feats.get(k, 0.0), 6) for k in ALL_25_FEATURES],
        "features_9":  [round(feats.get(k, 0.0), 6) for k in CORE_9_FEATURES],
        "indexed_at":  time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }

    return meta


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN INDEXER
# ─────────────────────────────────────────────────────────────────────────────

def run_indexer(data_dir: str, out_dir: str,
                n_workers: int = 4,
                force: bool = False) -> List[Dict]:
    """
    Scan data_dir for building folders, index all, write metadata.json.

    Returns list of all metadata dicts.
    """
    os.makedirs(out_dir, exist_ok=True)

    # Detect building folders
    folders = sorted([
        d for d in os.listdir(data_dir)
        if os.path.isdir(os.path.join(data_dir, d))
    ])
    logger.info(f"Found {len(folders)} candidate folders in {data_dir}")

    if not folders:
        logger.error("No building folders found. Check --data_dir path.")
        return []

    # ── index all buildings ──────────────────────────────────────────────────
    results = []
    skipped = 0
    t0 = time.time()

    for i, folder in enumerate(folders, 1):
        bdir = os.path.join(data_dir, folder)
        meta = index_one_building(folder, bdir)
        if meta is None:
            skipped += 1
        else:
            results.append(meta)

        # simple progress
        pct = i / len(folders) * 100
        bar = "#" * int(pct / 2)
        print(f"\r  [{bar:<50}] {pct:5.1f}%  {i}/{len(folders)}  OK={len(results)} SKIP={skipped}",
              end="", flush=True)

    print()  # newline after progress bar
    elapsed = time.time() - t0
    logger.info(f"Indexed {len(results)} buildings in {elapsed:.1f}s ({skipped} skipped)")

    # ── write metadata.json ──────────────────────────────────────────────────
    meta_path = os.path.join(out_dir, "metadata.json")
    with open(meta_path, "w") as f:
        json.dump(results, f, indent=2)
    logger.info(f"Saved metadata.json -> {meta_path}  ({len(results)} entries)")

    # ── write feature matrices for FAISS ────────────────────────────────────
    feat9  = np.array([m["features_9"]  for m in results], dtype=np.float32)
    feat25 = np.array([m["features_25"] for m in results], dtype=np.float32)

    np.save(os.path.join(out_dir, "features_9.npy"),  feat9)
    np.save(os.path.join(out_dir, "features_25.npy"), feat25)
    logger.info(f"Saved feature matrices: {feat9.shape} (9-dim), {feat25.shape} (25-dim)")

    # ── write building IDs list ──────────────────────────────────────────────
    ids_path = os.path.join(out_dir, "building_ids.json")
    with open(ids_path, "w") as f:
        json.dump([m["id"] for m in results], f)

    return results


# ─────────────────────────────────────────────────────────────────────────────
#  CLI ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Building CFD Auto-Indexer")
    parser.add_argument("--data_dir", default="buildings",
                        help="Directory containing building folders (default: buildings/)")
    parser.add_argument("--out_dir", default="data",
                        help="Output directory for metadata.json and .npy files (default: data/)")
    parser.add_argument("--workers", type=int, default=1,
                        help="Number of parallel workers (default: 1)")
    parser.add_argument("--force", action="store_true",
                        help="Re-index even if metadata.json already exists")
    args = parser.parse_args()

    logger.info("=== Building CFD Auto-Indexer ===")
    logger.info(f"  data_dir : {args.data_dir}")
    logger.info(f"  out_dir  : {args.out_dir}")

    results = run_indexer(args.data_dir, args.out_dir,
                          n_workers=args.workers, force=args.force)
    logger.info(f"Done. {len(results)} buildings indexed.")
