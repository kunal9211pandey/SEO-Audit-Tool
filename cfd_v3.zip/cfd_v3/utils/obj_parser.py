"""
utils/obj_parser.py
-------------------
Production-grade Wavefront OBJ parser for building CFD feature extraction.

Extracts 25 geometric features from a building .obj file:
    Bounding box: width, depth, height
    Areas: footprint, volume, surface areas (windward/leeward/roof/lateral)
    Ratios: aspect_hw, aspect_hd, slenderness, compactness
    Mesh: n_vertices, n_faces, avg_face_area, surface_irregularity
    Wind: frontal_area (by direction), blockage ratio
    Advanced: convex_hull_ratio, moment_of_inertia_x, moment_of_inertia_y

All features are dimensionless or in SI units (metres, m2, m3).
"""

import numpy as np
import re
from typing import Dict, List, Tuple, Optional


# ─────────────────────────────────────────────────────────────────────────────
#  LOW-LEVEL PARSERS
# ─────────────────────────────────────────────────────────────────────────────

def parse_obj_file(filepath: str) -> Tuple[np.ndarray, List[List[int]]]:
    """
    Parse a Wavefront .obj file.

    Returns
    -------
    vertices : np.ndarray  shape (N, 3)  — x, y, z coordinates
    faces    : list of lists of int     — 0-indexed vertex indices
    """
    vertices: List[List[float]] = []
    faces:    List[List[int]]   = []

    with open(filepath, "r") as fh:
        for line in fh:
            line = line.strip()
            if line.startswith("v "):
                parts = line.split()
                vertices.append([float(parts[1]), float(parts[2]), float(parts[3])])
            elif line.startswith("f "):
                # handles: f 1 2 3   f 1/1 2/2 3/3   f 1//1 2//2 3//3
                raw = line.split()[1:]
                idx = [int(r.split("/")[0]) - 1 for r in raw]  # 0-indexed
                faces.append(idx)

    # Clamp out-of-bounds face indices (some OBJ exporters wrap top-ring verts)
    n = len(vertices)
    if n > 0:
        faces = [[i % n for i in face] for face in faces]

    return np.array(vertices, dtype=np.float64), faces


def parse_obj_string(content: str) -> Tuple[np.ndarray, List[List[int]]]:
    """Same as parse_obj_file but from an in-memory string."""
    vertices: List[List[float]] = []
    faces:    List[List[int]]   = []

    for line in content.splitlines():
        line = line.strip()
        if line.startswith("v "):
            parts = line.split()
            vertices.append([float(parts[1]), float(parts[2]), float(parts[3])])
        elif line.startswith("f "):
            raw = line.split()[1:]
            idx = [int(r.split("/")[0]) - 1 for r in raw]
            faces.append(idx)

    n = len(vertices)
    if n > 0:
        faces = [[i % n for i in face] for face in faces]

    return np.array(vertices, dtype=np.float64), faces


# ─────────────────────────────────────────────────────────────────────────────
#  GEOMETRIC HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _face_area(verts: np.ndarray, face: List[int]) -> float:
    """Area of a planar polygon using cross-product (fan triangulation)."""
    if len(face) < 3:
        return 0.0
    total = 0.0
    v0 = verts[face[0]]
    for i in range(1, len(face) - 1):
        v1 = verts[face[i]]
        v2 = verts[face[i + 1]]
        edge1 = v1 - v0
        edge2 = v2 - v0
        total += np.linalg.norm(np.cross(edge1, edge2))
    return total * 0.5


def _face_normal(verts: np.ndarray, face: List[int]) -> np.ndarray:
    """Outward normal of a polygon face (not normalised)."""
    if len(face) < 3:
        return np.zeros(3)
    v0, v1, v2 = verts[face[0]], verts[face[1]], verts[face[2]]
    return np.cross(v1 - v0, v2 - v0)


def _face_centroid(verts: np.ndarray, face: List[int]) -> np.ndarray:
    return verts[face].mean(axis=0)


def _convex_hull_2d_area(points_xy: np.ndarray) -> float:
    """Shoelace formula on a convex hull (scipy not required — Graham scan)."""
    from scipy.spatial import ConvexHull  # type: ignore
    try:
        hull = ConvexHull(points_xy)
        return hull.volume  # in 2D, .volume = area
    except Exception:
        # degenerate case
        return float(np.prod(points_xy.max(axis=0) - points_xy.min(axis=0)))


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN FEATURE EXTRACTOR
# ─────────────────────────────────────────────────────────────────────────────

def extract_features(filepath: Optional[str] = None,
                     content:  Optional[str]  = None,
                     wind_angle_deg: float    = 0.0) -> Dict[str, float]:
    """
    Extract 25 aerodynamic features from a building .obj.

    Parameters
    ----------
    filepath        : path to .obj file (use this OR content)
    content         : raw .obj file content as string
    wind_angle_deg  : reference wind angle for frontal-area calculation (degrees)

    Returns
    -------
    dict of feature_name -> float value
    """
    if filepath is not None:
        verts, faces = parse_obj_file(filepath)
    elif content is not None:
        verts, content_str = parse_obj_string(content), None  # re-assign below
        verts, faces = parse_obj_string(content)
    else:
        raise ValueError("Provide either filepath or content.")

    if len(verts) == 0:
        raise ValueError("No vertices found in OBJ file.")

    # ── bounding box ─────────────────────────────────────────────────────────
    x_min, x_max = verts[:, 0].min(), verts[:, 0].max()
    y_min, y_max = verts[:, 1].min(), verts[:, 1].max()
    z_min, z_max = verts[:, 2].min(), verts[:, 2].max()

    width  = float(x_max - x_min)   # East-West (x)
    depth  = float(y_max - y_min)   # North-South (y)
    height = float(z_max - z_min)   # Vertical (z)

    width  = max(width,  0.01)
    depth  = max(depth,  0.01)
    height = max(height, 0.01)

    footprint = width * depth
    volume    = footprint * height

    # ── ratios ───────────────────────────────────────────────────────────────
    aspect_hw  = height / width
    aspect_hd  = height / depth
    slenderness = height / max(np.sqrt(footprint), 0.01)

    # ── surface areas per orientation ────────────────────────────────────────
    windward_area = leeward_area = roof_area = lateral_area = total_surface = 0.0

    ang_rad  = np.radians(wind_angle_deg)
    wind_vec = np.array([np.cos(ang_rad), np.sin(ang_rad), 0.0])

    face_areas_all = []
    for face in faces:
        if len(face) < 3:
            continue
        area   = _face_area(verts, face)
        normal = _face_normal(verts, face)
        norm_n = np.linalg.norm(normal)
        face_areas_all.append(area)
        total_surface += area

        if norm_n < 1e-9:
            continue
        unit_n = normal / norm_n

        # classify by dominant component
        dot_wind = float(np.dot(unit_n, wind_vec))
        dot_z    = float(unit_n[2])

        if abs(dot_z) > 0.7:
            if dot_z > 0:
                roof_area += area
        elif dot_wind > 0.5:
            windward_area += area * dot_wind
        elif dot_wind < -0.5:
            leeward_area  += area * abs(dot_wind)
        else:
            lateral_area  += area

    # ── frontal area (projected onto wind direction plane) ───────────────────
    frontal_area = max(depth * height * abs(np.cos(ang_rad)) +
                       width * height * abs(np.sin(ang_rad)), 0.01)

    # ── compactness: actual footprint vs convex hull footprint ───────────────
    try:
        hull_area = _convex_hull_2d_area(verts[:, :2])
        compactness = min(footprint / max(hull_area, 0.01), 1.0)
    except Exception:
        compactness = 1.0

    # ── surface irregularity: std of face areas / mean ───────────────────────
    if len(face_areas_all) > 1:
        fa = np.array(face_areas_all)
        surface_irregularity = float(fa.std() / (fa.mean() + 1e-9))
    else:
        surface_irregularity = 0.0

    avg_face_area = float(total_surface / max(len(faces), 1))

    # ── moment of inertia (mass normalised, 2D footprint projection) ─────────
    cx = float(verts[:, 0].mean())
    cy = float(verts[:, 1].mean())
    moment_x = float(((verts[:, 1] - cy) ** 2).mean())
    moment_y = float(((verts[:, 0] - cx) ** 2).mean())

    # ── blockage ratio (building frontal / domain cross section) ─────────────
    domain_w = width  * 10.0
    domain_h = height * 4.0
    blockage_ratio = frontal_area / max(domain_w * domain_h, 0.01)

    n_verts = len(verts)
    n_faces = len(faces)

    features = {
        # bounding box
        "width_m":         width,
        "depth_m":         depth,
        "height_m":        height,
        # area / volume
        "footprint_m2":    footprint,
        "volume_m3":       volume,
        "total_surface_m2": total_surface,
        "frontal_area_m2": frontal_area,
        # orientation areas
        "windward_area_m2": windward_area,
        "leeward_area_m2":  leeward_area,
        "roof_area_m2":     roof_area,
        "lateral_area_m2":  lateral_area,
        # ratios
        "aspect_hw":        aspect_hw,
        "aspect_hd":        aspect_hd,
        "slenderness":      slenderness,
        "compactness":      compactness,
        "blockage_ratio":   blockage_ratio,
        # mesh
        "n_vertices":       float(n_verts),
        "n_faces":          float(n_faces),
        "avg_face_area_m2": avg_face_area,
        "surface_irregularity": surface_irregularity,
        # moments
        "moment_x":        moment_x,
        "moment_y":        moment_y,
        # derived
        "perimeter_m":     2 * (width + depth),
        "plan_aspect":     width / max(depth, 0.01),
        "wall_to_floor":   total_surface / max(footprint, 0.01),
    }

    return features


def features_to_vector(feats: Dict[str, float],
                        keys: Optional[List[str]] = None) -> np.ndarray:
    """
    Convert feature dict → fixed-length numpy vector for FAISS.

    Default 9-dim vector for backward compatibility.
    Pass keys=ALL_FEATURE_KEYS for 25-dim.
    """
    if keys is None:
        keys = CORE_9_FEATURES
    return np.array([feats.get(k, 0.0) for k in keys], dtype=np.float32)


# Feature key lists
CORE_9_FEATURES = [
    "width_m", "depth_m", "height_m",
    "footprint_m2", "volume_m3",
    "aspect_hw", "aspect_hd",
    "slenderness", "n_vertices",
]

ALL_25_FEATURES = [
    "width_m", "depth_m", "height_m",
    "footprint_m2", "volume_m3", "total_surface_m2", "frontal_area_m2",
    "windward_area_m2", "leeward_area_m2", "roof_area_m2", "lateral_area_m2",
    "aspect_hw", "aspect_hd", "slenderness", "compactness", "blockage_ratio",
    "n_vertices", "n_faces", "avg_face_area_m2", "surface_irregularity",
    "moment_x", "moment_y",
    "perimeter_m", "plan_aspect", "wall_to_floor",
]


# ─────────────────────────────────────────────────────────────────────────────
#  OPENFOAM FIELD PARSER
# ─────────────────────────────────────────────────────────────────────────────

def parse_foam_scalar_field(filepath: str) -> Dict[str, float]:
    """
    Parse OpenFOAM scalar field file (p, k, epsilon, nut, phi).
    Returns mean, max, min, std of internalField values.
    Also extracts stagnation_pressure, wake_pressure, min_pressure comments if present.
    """
    values: List[float] = []
    extras: Dict[str, float] = {}

    inside_list = False
    count_remaining = 0

    with open(filepath, "r") as fh:
        for line in fh:
            line_s = line.strip()

            # extract comment annotations (p file specific)
            if line_s.startswith("// stagnation_pressure"):
                m = re.search(r"[-\d.]+$", line_s)
                if m:
                    extras["stagnation_pressure_Pa"] = float(m.group())
            elif line_s.startswith("// wake_pressure"):
                m = re.search(r"[-\d.]+$", line_s)
                if m:
                    extras["wake_pressure_Pa"] = float(m.group())
            elif line_s.startswith("// min_pressure"):
                m = re.search(r"[-\d.]+$", line_s)
                if m:
                    extras["min_pressure_Pa"] = float(m.group())

            # detect list start
            if not inside_list:
                m = re.match(r"^(\d+)$", line_s)
                if m:
                    count_remaining = int(m.group(1))
                    inside_list = True
                    continue
            else:
                if line_s == "(":
                    continue
                if line_s.startswith(")"):
                    inside_list = False
                    continue
                try:
                    values.append(float(line_s))
                    count_remaining -= 1
                except ValueError:
                    pass

    if not values:
        return {"mean": 0, "max": 0, "min": 0, "std": 0, "count": 0, **extras}

    arr = np.array(values)
    result = {
        "mean":  float(arr.mean()),
        "max":   float(arr.max()),
        "min":   float(arr.min()),
        "std":   float(arr.std()),
        "count": int(len(arr)),
    }
    result.update(extras)
    return result


def parse_foam_vector_field(filepath: str) -> Dict[str, float]:
    """
    Parse OpenFOAM vector field file (U).
    Returns magnitude mean/max, component means, and turbulence stats.
    """
    ux_list: List[float] = []
    uy_list: List[float] = []
    uz_list: List[float] = []

    inside_list = False

    with open(filepath, "r") as fh:
        for line in fh:
            line_s = line.strip()
            if not inside_list:
                m = re.match(r"^(\d+)$", line_s)
                if m:
                    inside_list = True
                    continue
            else:
                if line_s == "(":
                    continue
                if line_s.startswith(")"):
                    inside_list = False
                    continue
                m = re.match(r"^\(([^\)]+)\)$", line_s)
                if m:
                    parts = m.group(1).split()
                    if len(parts) == 3:
                        try:
                            ux_list.append(float(parts[0]))
                            uy_list.append(float(parts[1]))
                            uz_list.append(float(parts[2]))
                        except ValueError:
                            pass

    if not ux_list:
        return {"u_mean": 0, "u_max": 0, "u_min": 0,
                "ux_mean": 0, "uy_mean": 0, "uz_mean": 0, "count": 0}

    ux = np.array(ux_list)
    uy = np.array(uy_list)
    uz = np.array(uz_list)
    mag = np.sqrt(ux**2 + uy**2 + uz**2)

    return {
        "u_mean":  float(mag.mean()),
        "u_max":   float(mag.max()),
        "u_min":   float(mag.min()),
        "u_std":   float(mag.std()),
        "ux_mean": float(ux.mean()),
        "uy_mean": float(uy.mean()),
        "uz_mean": float(uz.mean()),
        "count":   int(len(mag)),
    }


def parse_all_fields(building_dir: str) -> Dict:
    """
    Parse all CFD fields from a building directory.
    Returns complete CFD stats dict.
    """
    import os
    result = {}

    field_map = {
        "p":       ("scalar", "p"),
        "k":       ("scalar", "k"),
        "epsilon": ("scalar", "epsilon"),
        "nut":     ("scalar", "nut"),
        "phi":     ("scalar", "phi"),
        "U":       ("vector", "U"),
    }

    for fname, (ftype, key) in field_map.items():
        fpath = os.path.join(building_dir, fname)
        if not os.path.exists(fpath):
            continue
        try:
            if ftype == "scalar":
                stats = parse_foam_scalar_field(fpath)
                for k, v in stats.items():
                    result[f"{key}_{k}"] = v
            else:
                stats = parse_foam_vector_field(fpath)
                for k, v in stats.items():
                    result[f"{key}_{k}"] = v
        except Exception as e:
            result[f"{key}_error"] = str(e)

    return result
