"""
utils/location_params.py
------------------------
Wind engineering location database for 20+ cities.

Covers IS 875 (India), ASCE 7 (USA), Eurocode 1 (Europe),
AIJ (Japan), AS 1170 (Australia), GB 50009 (China), NBCC (Canada).

Each location has:
    Vb          : basic wind speed (m/s) — 3-sec gust at 10m, open terrain
    rho         : air density (kg/m3) at mean elevation and temperature
    z0          : terrain roughness length (m)
    terrain_cat : terrain category (1-4)
    wind_dirs   : dominant wind directions as list (degrees)
    wind_code   : applicable wind standard
    lat, lon    : GPS coordinates
    elevation_m : mean elevation above sea level
    heat_island : urban heat island delta T (C)

Physics functions:
    dynamic_pressure(V, rho) -> Pa
    log_law_velocity(V_ref, z, z_ref, z0) -> m/s
    wind_pressure_coefficients() -> dict of Cp values
    scale_cfd_to_location(cfd_stats, location, V_ref_cfd) -> scaled dict
"""

from typing import Dict, List
import math

# ─────────────────────────────────────────────────────────────────────────────
#  LOCATION DATABASE
# ─────────────────────────────────────────────────────────────────────────────

LOCATIONS: Dict[str, Dict] = {

    # ── India (IS 875 Part 3: 2015) ──────────────────────────────────────────
    "Mumbai": {
        "Vb": 44.0, "rho": 1.20, "z0": 0.5, "terrain_cat": 3,
        "wind_dirs": [225, 270, 315],  # SW monsoon dominant
        "wind_code": "IS 875-3:2015", "zone": "VB (Cyclone)",
        "lat": 19.076, "lon": 72.877, "elevation_m": 11, "heat_island": 3.5,
        "notes": "Coastal. Highest cyclone risk in India.",
    },
    "Delhi": {
        "Vb": 47.0, "rho": 1.18, "z0": 0.7, "terrain_cat": 4,
        "wind_dirs": [270, 315, 45],  # NW in winter, W in summer
        "wind_code": "IS 875-3:2015", "zone": "VB",
        "lat": 28.704, "lon": 77.102, "elevation_m": 216, "heat_island": 4.0,
        "notes": "Dense urban. Dust storms from NW.",
    },
    "Bengaluru": {
        "Vb": 33.0, "rho": 1.17, "z0": 0.4, "terrain_cat": 3,
        "wind_dirs": [0, 45, 90],  # N-NE dominant
        "wind_code": "IS 875-3:2015", "zone": "III",
        "lat": 12.972, "lon": 77.594, "elevation_m": 900, "heat_island": 2.5,
        "notes": "High elevation. Moderate winds.",
    },
    "Chennai": {
        "Vb": 50.0, "rho": 1.20, "z0": 0.3, "terrain_cat": 2,
        "wind_dirs": [0, 45, 90, 135],  # NE monsoon and SW monsoon
        "wind_code": "IS 875-3:2015", "zone": "VB (Cyclone)",
        "lat": 13.083, "lon": 80.270, "elevation_m": 6, "heat_island": 3.0,
        "notes": "High cyclone risk. Both monsoon seasons.",
    },
    "Kolkata": {
        "Vb": 50.0, "rho": 1.20, "z0": 0.5, "terrain_cat": 3,
        "wind_dirs": [180, 225, 270],  # Bay of Bengal cyclones
        "wind_code": "IS 875-3:2015", "zone": "VB (Cyclone)",
        "lat": 22.573, "lon": 88.364, "elevation_m": 9, "heat_island": 3.5,
        "notes": "Cyclone prone. River delta location.",
    },
    "Hyderabad": {
        "Vb": 39.0, "rho": 1.16, "z0": 0.5, "terrain_cat": 3,
        "wind_dirs": [270, 315],  # W-NW dominant
        "wind_code": "IS 875-3:2015", "zone": "IV",
        "lat": 17.385, "lon": 78.486, "elevation_m": 542, "heat_island": 3.0,
        "notes": "Deccan plateau. Moderate risk.",
    },
    "Pune": {
        "Vb": 39.0, "rho": 1.17, "z0": 0.4, "terrain_cat": 3,
        "wind_dirs": [270, 315, 225],  # W dominant
        "wind_code": "IS 875-3:2015", "zone": "IV",
        "lat": 18.520, "lon": 73.857, "elevation_m": 559, "heat_island": 2.5,
        "notes": "Leeward of Western Ghats.",
    },
    "Ahmedabad": {
        "Vb": 39.0, "rho": 1.17, "z0": 0.5, "terrain_cat": 3,
        "wind_dirs": [270, 315, 225],
        "wind_code": "IS 875-3:2015", "zone": "IV",
        "lat": 23.023, "lon": 72.572, "elevation_m": 53, "heat_island": 3.0,
        "notes": "Gujarat semi-arid zone.",
    },

    # ── Middle East ───────────────────────────────────────────────────────────
    "Dubai": {
        "Vb": 36.0, "rho": 1.16, "z0": 0.05, "terrain_cat": 1,
        "wind_dirs": [315, 0, 45],  # N-NW Shamal dominant
        "wind_code": "ASCE 7-22 (adapted)", "zone": "Gulf coast",
        "lat": 25.204, "lon": 55.270, "elevation_m": 5, "heat_island": 5.0,
        "notes": "Hot desert. Shamal sand winds. Open terrain.",
    },
    "Riyadh": {
        "Vb": 33.0, "rho": 1.15, "z0": 0.05, "terrain_cat": 1,
        "wind_dirs": [315, 0, 270],  # NW Shamal
        "wind_code": "Saudi Building Code SBC 301", "zone": "Inland desert",
        "lat": 24.688, "lon": 46.722, "elevation_m": 612, "heat_island": 4.5,
        "notes": "Extreme heat. Low density. Dust storms.",
    },

    # ── East Asia ─────────────────────────────────────────────────────────────
    "Singapore": {
        "Vb": 28.0, "rho": 1.20, "z0": 0.3, "terrain_cat": 3,
        "wind_dirs": [0, 180, 270],  # Variable, NE/SW monsoons
        "wind_code": "SS CP3 (SS 580)", "zone": "Equatorial",
        "lat":  1.352, "lon": 103.820, "elevation_m": 15, "heat_island": 4.0,
        "notes": "No cyclones. Convective storms. Hot humid.",
    },
    "Tokyo": {
        "Vb": 36.0, "rho": 1.21, "z0": 0.7, "terrain_cat": 4,
        "wind_dirs": [270, 315, 0],  # W-NW winter, typhoons from SE
        "wind_code": "AIJ-RLB-2015", "zone": "Typhoon coast",
        "lat": 35.689, "lon": 139.692, "elevation_m": 40, "heat_island": 4.0,
        "notes": "Dense urban canyon. Typhoon risk.",
    },
    "Shanghai": {
        "Vb": 32.5, "rho": 1.20, "z0": 0.5, "terrain_cat": 4,
        "wind_dirs": [270, 315, 180],  # W winter, typhoons from SE
        "wind_code": "GB 50009-2012", "zone": "B",
        "lat": 31.230, "lon": 121.474, "elevation_m": 4, "heat_island": 3.5,
        "notes": "Typhoon risk. River delta. Dense urban.",
    },

    # ── Europe ────────────────────────────────────────────────────────────────
    "London": {
        "Vb": 23.0, "rho": 1.24, "z0": 0.6, "terrain_cat": 4,
        "wind_dirs": [225, 270, 315],  # SW Atlantic dominant
        "wind_code": "EN 1991-1-4:2005 (Eurocode 1)", "zone": "Zone 2",
        "lat": 51.507, "lon":  -0.128, "elevation_m": 11, "heat_island": 3.0,
        "notes": "Mild winds. SW Atlantic storms. Dense city.",
    },
    "Amsterdam": {
        "Vb": 27.0, "rho": 1.24, "z0": 0.1, "terrain_cat": 2,
        "wind_dirs": [225, 270, 315],
        "wind_code": "EN 1991-1-4:2005", "zone": "Zone 3",
        "lat": 52.370, "lon": 4.895, "elevation_m": -2, "heat_island": 2.5,
        "notes": "North Sea coastal. High wind exposure.",
    },

    # ── Americas ──────────────────────────────────────────────────────────────
    "New York": {
        "Vb": 49.0, "rho": 1.22, "z0": 0.7, "terrain_cat": 4,
        "wind_dirs": [270, 315, 0],  # W-NW dominant, hurricane season SE
        "wind_code": "ASCE 7-22", "zone": "Exposure B/C",
        "lat": 40.713, "lon": -74.006, "elevation_m": 10, "heat_island": 4.5,
        "notes": "Hurricane risk. Dense Manhattan canyon effect.",
    },
    "Chicago": {
        "Vb": 49.0, "rho": 1.22, "z0": 0.5, "terrain_cat": 3,
        "wind_dirs": [270, 315, 225],  # Lake Michigan westerlies
        "wind_code": "ASCE 7-22", "zone": "Exposure B",
        "lat": 41.878, "lon": -87.630, "elevation_m": 176, "heat_island": 4.0,
        "notes": "Windy City. Lake effect. Tornado risk.",
    },
    "Toronto": {
        "Vb": 40.0, "rho": 1.22, "z0": 0.5, "terrain_cat": 3,
        "wind_dirs": [270, 315, 225],
        "wind_code": "NBCC 2020", "zone": "q=0.59 kPa",
        "lat": 43.651, "lon": -79.347, "elevation_m": 76, "heat_island": 3.5,
        "notes": "Lake Ontario effect. Ice storm risk.",
    },

    # ── Australia ─────────────────────────────────────────────────────────────
    "Sydney": {
        "Vb": 45.0, "rho": 1.20, "z0": 0.1, "terrain_cat": 2,
        "wind_dirs": [315, 270, 0],  # SW sea breeze + N-NW hot winds
        "wind_code": "AS/NZS 1170.2:2021", "zone": "B1",
        "lat": -33.868, "lon": 151.209, "elevation_m": 39, "heat_island": 3.5,
        "notes": "Easterly sea breeze. Bushfire winds from W.",
    },
}


# ─────────────────────────────────────────────────────────────────────────────
#  PHYSICS FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def dynamic_pressure(V: float, rho: float) -> float:
    """q = 0.5 * rho * V^2  (Pa)"""
    return 0.5 * rho * V * V


def log_law_velocity(V_ref: float, z: float, z_ref: float = 10.0,
                     z0: float = 0.03) -> float:
    """
    Logarithmic wind profile.
    V(z) = V_ref * ln(z/z0) / ln(z_ref/z0)
    """
    if z <= z0:
        z = z0 * 1.01
    return V_ref * math.log(z / z0) / math.log(z_ref / z0)


def power_law_velocity(V_ref: float, z: float, z_ref: float = 10.0,
                       alpha: float = 0.25) -> float:
    """
    Power law wind profile.
    V(z) = V_ref * (z/z_ref)^alpha
    alpha: 0.10 open sea, 0.14 open, 0.22 suburban, 0.33 city
    """
    return V_ref * (z / z_ref) ** alpha


def wind_pressure_coefficients() -> Dict[str, float]:
    """
    Standard external pressure coefficients (Cp) per face orientation.
    Based on IS 875-3, ASCE 7, Eurocode 1 for rectangular buildings.
    h/d ratio assumed 1-4 (typical office tower).
    """
    return {
        "Cp_windward":   +0.80,   # positive pressure
        "Cp_leeward":    -0.50,   # suction
        "Cp_side_wall":  -0.70,   # suction (parallel flow)
        "Cp_roof_flat":  -0.90,   # suction (flat roof)
        "Cp_roof_10deg": -0.50,   # suction (10 deg pitched)
        "Cp_overhang":   -1.30,   # high local suction
    }


def terrain_factor(terrain_cat: int) -> Dict[str, float]:
    """
    Terrain factor parameters by category.
    Cat 1: Open sea / flat open
    Cat 2: Open with scattered obstructions
    Cat 3: Suburban, forests
    Cat 4: Dense city centre
    """
    params = {
        1: {"z0": 0.01, "z_min": 1.0,  "alpha": 0.10, "description": "Open sea / flat"},
        2: {"z0": 0.05, "z_min": 2.0,  "alpha": 0.14, "description": "Open with obstacles"},
        3: {"z0": 0.30, "z_min": 5.0,  "alpha": 0.22, "description": "Suburban / forests"},
        4: {"z0": 0.70, "z_min": 10.0, "alpha": 0.33, "description": "Dense urban"},
    }
    return params.get(terrain_cat, params[2])


def velocity_profile_at_heights(V_ref: float, heights: List[float],
                                 z0: float = 0.3) -> List[float]:
    """Return wind speed at each height in the heights list."""
    return [log_law_velocity(V_ref, z, z0=z0) for z in heights]


# ─────────────────────────────────────────────────────────────────────────────
#  CFD SCALING TO LOCATION
# ─────────────────────────────────────────────────────────────────────────────

def scale_cfd_to_location(cfd_stats: Dict,
                           location_name: str,
                           V_ref_cfd: float = 20.0,
                           rho_cfd: float = 1.225) -> Dict:
    """
    Scale CFD statistics (from synthetic training data) to a real location.

    Scaling laws:
        velocity  ∝ V_loc / V_cfd
        pressure  ∝ (rho_loc * V_loc^2) / (rho_cfd * V_cfd^2)
        k         ∝ (V_loc/V_cfd)^2
        epsilon   ∝ (V_loc/V_cfd)^3 / L_scale
        nut       ∝ (V_loc/V_cfd)^2 / (k^0.75 / epsilon) — approx same
    """
    loc = LOCATIONS.get(location_name)
    if loc is None:
        loc = LOCATIONS["Bengaluru"]  # fallback

    V_loc  = loc["Vb"]
    rho_loc = loc["rho"]

    vel_ratio = V_loc / max(V_ref_cfd, 0.01)
    pres_ratio = (rho_loc * V_loc**2) / (rho_cfd * V_ref_cfd**2)

    Cp    = wind_pressure_coefficients()
    q_loc = dynamic_pressure(V_loc, rho_loc)

    scaled = {}

    # velocity fields
    for key in ["U_u_mean", "U_u_max", "U_u_min",
                "U_ux_mean", "U_uy_mean", "U_uz_mean"]:
        if key in cfd_stats:
            scaled[key] = cfd_stats[key] * vel_ratio

    # pressure fields
    for key in ["p_mean", "p_max", "p_min",
                "p_stagnation_pressure_Pa", "p_wake_pressure_Pa", "p_min_pressure_Pa"]:
        if key in cfd_stats:
            scaled[key] = cfd_stats[key] * pres_ratio

    # turbulence
    for key in ["k_mean", "k_max", "k_min"]:
        if key in cfd_stats:
            scaled[key] = cfd_stats[key] * vel_ratio**2

    for key in ["epsilon_mean", "epsilon_max", "epsilon_min"]:
        if key in cfd_stats:
            scaled[key] = cfd_stats[key] * vel_ratio**3

    for key in ["nut_mean", "nut_max", "nut_min"]:
        if key in cfd_stats:
            scaled[key] = cfd_stats[key] * vel_ratio  # approx

    for key in ["phi_mean", "phi_max", "phi_min"]:
        if key in cfd_stats:
            scaled[key] = cfd_stats[key] * vel_ratio

    # add derived quantities
    scaled["location"]              = location_name
    scaled["design_wind_speed_ms"]  = V_loc
    scaled["air_density_kgm3"]      = rho_loc
    scaled["dynamic_pressure_Pa"]   = q_loc
    scaled["windward_pressure_Pa"]  = q_loc * Cp["Cp_windward"]
    scaled["leeward_suction_Pa"]    = q_loc * Cp["Cp_leeward"]
    scaled["roof_suction_Pa"]       = q_loc * Cp["Cp_roof_flat"]
    scaled["side_suction_Pa"]       = q_loc * Cp["Cp_side_wall"]
    scaled["wind_code"]             = loc["wind_code"]
    scaled["terrain_category"]      = loc["terrain_cat"]
    scaled["dominant_directions"]   = loc["wind_dirs"]

    return scaled


def get_location(name: str) -> Dict:
    """Get location parameters dict. Returns Bengaluru as fallback."""
    return LOCATIONS.get(name, LOCATIONS["Bengaluru"])


def list_locations() -> List[str]:
    return sorted(LOCATIONS.keys())
