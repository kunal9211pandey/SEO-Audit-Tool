# Building CFD AI — Complete API Reference
# React Developer ke liye — Har endpoint, har field explained

## Setup

```bash
pip install fastapi uvicorn python-multipart
uvicorn api.main:app --host 0.0.0.0 --port 8000 --reload
```

Base URL: `http://localhost:8000`
Live Docs: `http://localhost:8000/docs`  (Swagger UI — try karo wahan se)

---

## CORS
Sab origins allowed hain (`*`). React dev server (3000 / 5173) direct call kar sakta hai.

---

## Endpoints — Complete List

---

### 1. HEALTH

#### `GET /`
Server running check.
```json
{ "status": "ok", "version": "2.0.0", "endpoints": "/docs" }
```

#### `GET /health`
Detailed system status.
```json
{
  "database":    { "status": "ok", "count": 100 },
  "ml_model":    { "status": "ok" },
  "faiss_index": { "status": "ok" },
  "groq_key":    { "status": "set" }
}
```

---

### 2. DATABASE

#### `GET /buildings`
Sab buildings list karo, pagination + filter support.

Query params:
| Param | Type | Default | Description |
|---|---|---|---|
| `skip` | int | 0 | Pagination offset |
| `limit` | int | 20 | Page size (max 100) |
| `search` | string | "" | Filter by ID/name |
| `shape` | string | "" | Filter by shape_class |

```js
// React example
const res = await fetch('/buildings?skip=0&limit=20&search=B042');
const { total, buildings } = await res.json();
```

Response:
```json
{
  "total": 100,
  "skip": 0,
  "limit": 20,
  "buildings": [
    {
      "id": "B001",
      "name": "Tall Tower",
      "data_path": "buildings/B001",
      "geometry": {
        "width": 10.0, "depth": 10.0, "height": 60.0,
        "floors": 20, "points": 84, "faces": 86,
        "footprint_m2": 100.0, "volume_m3": 6000.0,
        "frontal_area_m2": 600.0, "aspect_ratio_hw": 6.0,
        "shape_class": "Supertall Tower"
      },
      "cfd": {
        "cells": 66623,
        "p_mean_Pa": 101361.46, "p_max_Pa": 101484.25, "p_min_Pa": 101239.25,
        "u_mean_ms": 19.0579,   "u_max_ms": 20.9853,
        "k_mean": 1.3671, "epsilon_mean": 0.0236,
        "nut_mean": 5.1484, "phi_mean": 1902.96,
        "stagnation_pressure_Pa": 101415.65,
        "wake_pressure_Pa": 101289.62
      },
      "features_25": [10.0, 10.0, 60.0, ...],
      "features_9":  [10.0, 10.0, 60.0, ...],
      "indexed_at": "2025-03-19T10:30:00Z"
    }
  ]
}
```

---

#### `GET /buildings/{building_id}`
Ek building ka full data.

```js
const res = await fetch('/buildings/B001');
const building = await res.json();
```

---

#### `GET /buildings/stats/summary`
Home page ke stat cards ke liye.

```json
{
  "total": 100,
  "height_avg_m": 52.4,
  "height_max_m": 165.0,
  "height_min_m": 9.0,
  "u_mean_avg_ms": 16.2,
  "shape_distribution": {
    "Supertall Tower": 8,
    "Tall Tower": 15,
    "Medium Office Tower": 22,
    "Complex / L-Shape": 12
  }
}
```

---

#### `GET /buildings/shapes/list`
Shape filter dropdown ke liye.

```json
{ "shapes": ["Complex / L-Shape", "Compact Block", "Supertall Tower", ...] }
```

---

#### `GET /search/similar/{building_id}`
Database mein kisi existing building ke similar buildings dhundho.

Query params: `top_k`, `location`, `wind_angle`

```js
const res = await fetch('/search/similar/B042?top_k=5&location=Mumbai');
```

---

### 3. LOCATIONS

#### `GET /locations`
Saare cities list — dropdown ke liye.

```js
const { locations } = await fetch('/locations').then(r => r.json());
// locations[0] = { city, Vb, rho, z0, terrain_cat, wind_code, wind_dirs, dynamic_pressure, lat, lon }
```

Full response per city:
```json
{
  "city": "Mumbai",
  "Vb": 44.0,
  "rho": 1.20,
  "z0": 0.5,
  "terrain_cat": 3,
  "wind_code": "IS 875-3:2015",
  "wind_dirs": [225, 270, 315],
  "dynamic_pressure": 1161.6,
  "lat": 19.076,
  "lon": 72.877,
  "notes": "Coastal. Highest cyclone risk in India."
}
```

---

#### `GET /locations/{city}`
Ek city ka complete wind engineering data.

```js
const data = await fetch('/locations/Mumbai').then(r => r.json());
```

Response:
```json
{
  "city": "Mumbai",
  "Vb": 44.0,
  "rho": 1.20,
  "z0": 0.5,
  "terrain_cat": 3,
  "wind_code": "IS 875-3:2015",
  "wind_dirs": [225, 270, 315],
  "lat": 19.076,
  "lon": 72.877,
  "notes": "Coastal. Cyclone risk.",
  "dynamic_pressure_Pa": 1161.6,
  "windward_pressure_Pa": 929.28,
  "leeward_suction_Pa": -580.8,
  "roof_suction_Pa": -1045.44,
  "side_suction_Pa": -813.12,
  "velocity_profile": [
    { "height_m": 3.0,  "velocity_ms": 25.4 },
    { "height_m": 5.0,  "velocity_ms": 28.1 },
    { "height_m": 10.0, "velocity_ms": 32.0 },
    { "height_m": 20.0, "velocity_ms": 37.2 },
    { "height_m": 50.0, "velocity_ms": 44.1 }
  ]
}
```

---

#### `GET /locations/{city}/wind-rose`
Wind rose chart data — D3.js / Chart.js polar chart ke liye.

```js
const { rose } = await fetch('/locations/Mumbai/wind-rose').then(r => r.json());
// rose[i] = { direction, angle_deg, dominant, intensity, speed_ms, pressure_Pa }
```

```json
{
  "city": "Mumbai",
  "Vb": 44.0,
  "wind_dirs": [225, 270, 315],
  "rose": [
    { "direction": "N",  "angle_deg": 0,   "dominant": false, "intensity": 0.30, "speed_ms": 13.2, "pressure_Pa": 104.5 },
    { "direction": "SW", "angle_deg": 225, "dominant": true,  "intensity": 0.85, "speed_ms": 37.4, "pressure_Pa": 837.4 },
    { "direction": "W",  "angle_deg": 270, "dominant": true,  "intensity": 0.85, "speed_ms": 37.4, "pressure_Pa": 837.4 },
    { "direction": "NW", "angle_deg": 315, "dominant": true,  "intensity": 0.85, "speed_ms": 37.4, "pressure_Pa": 837.4 }
  ]
}
```

---

### 4. OBJ PARSER

#### `POST /parse/obj`
OBJ file se 25 geometric features extract karo (without ML prediction).

```js
const form = new FormData();
form.append('file', objFile);          // .obj file
form.append('wind_angle', '45');       // degrees

const { features } = await fetch('/parse/obj', {
  method: 'POST', body: form
}).then(r => r.json());
```

Response:
```json
{
  "filename": "building.obj",
  "wind_angle": 45.0,
  "n_features": 25,
  "features": {
    "width_m": 10.0,
    "depth_m": 10.0,
    "height_m": 60.0,
    "footprint_m2": 100.0,
    "volume_m3": 6000.0,
    "total_surface_m2": 2500.0,
    "frontal_area_m2": 848.5,
    "windward_area_m2": 600.0,
    "leeward_area_m2": 600.0,
    "roof_area_m2": 100.0,
    "lateral_area_m2": 1200.0,
    "aspect_hw": 6.0,
    "aspect_hd": 6.0,
    "slenderness": 6.0,
    "compactness": 1.0,
    "blockage_ratio": 0.015,
    "n_vertices": 84.0,
    "n_faces": 82.0,
    "avg_face_area_m2": 30.5,
    "surface_irregularity": 0.0,
    "moment_x": 8.33,
    "moment_y": 8.33,
    "perimeter_m": 40.0,
    "plan_aspect": 1.0,
    "wall_to_floor": 25.0
  }
}
```

---

#### `POST /parse/image`
Building ki photo se geometry estimate karo (Groq Vision LLM).

```js
const form = new FormData();
form.append('file', imageFile);   // JPG / PNG

const data = await fetch('/parse/image', {
  method: 'POST', body: form
}).then(r => r.json());
```

Response:
```json
{
  "filename": "building.jpg",
  "confidence": "Medium",
  "vision_estimate": {
    "width_m": 20,
    "depth_m": 20,
    "height_m": 30,
    "n_floors": 10,
    "shape_class": "Rectangular",
    "terrain": "Urban",
    "wind_exposure": "Medium",
    "reasoning": "Building appears to be ~10 storeys..."
  },
  "features": {
    "width_m": 20.0,
    "height_m": 30.0,
    ...
  }
}
```

---

### 5. SIMILARITY SEARCH

#### `POST /search/similarity`
OBJ file upload karo, database mein similar buildings dhundho.

```js
const form = new FormData();
form.append('file', objFile);
form.append('location', 'Mumbai');
form.append('wind_angle', '90');
form.append('top_k', '5');

const data = await fetch('/search/similarity', {
  method: 'POST', body: form
}).then(r => r.json());
```

Response:
```json
{
  "query_geometry": { "width_m": 10.0, "height_m": 60.0, ... },
  "location": "Mumbai",
  "wind_angle": 90.0,
  "total_searched": 20,
  "results": [
    {
      "id": "B007",
      "similarity": 0.9823,
      "rerank_score": 0.9541,
      "geometry": { "height": 55.0, "shape_class": "Tall Tower", ... },
      "cfd": { "u_mean_ms": 18.5, "p_mean_Pa": 101380.0, ... }
    },
    {
      "id": "B042",
      "similarity": 0.8741,
      "rerank_score": 0.8612,
      "geometry": { ... },
      "cfd": { ... }
    }
  ]
}
```

---

### 6. RAG Q&A (main AI endpoint)

#### `POST /rag/query`
Main AI endpoint — OBJ / image / text input, full engineering analysis milta hai.

```js
// Mode 1: OBJ file
const form = new FormData();
form.append('question', 'What is the expected wind pressure?');
form.append('location', 'Mumbai');
form.append('wind_angle', '0');
form.append('top_k', '3');
form.append('obj_file', objFile);

// Mode 2: Image
form.append('image_file', photoFile);  // instead of obj_file

// Mode 3: Text only (no file)
// just question + location, no file

const data = await fetch('/rag/query', {
  method: 'POST', body: form
}).then(r => r.json());
```

Response:
```json
{
  "answer": "Based on the CFD analysis of similar buildings in our database...\n\n**Pressure Analysis (Mumbai, IS 875-3:2015)**\n- Design wind speed: 44 m/s\n- Dynamic pressure q = 1161.6 Pa\n- Windward pressure: +929.3 Pa (Cp = +0.80)\n...",

  "matched_buildings": [
    {
      "id": "B007",
      "similarity": 0.9823,
      "rerank_score": 0.9541,
      "metadata": {
        "geometry": { "height": 55.0, "width": 10.0, "shape_class": "Tall Tower" },
        "cfd": { "u_mean_ms": 18.5, "p_mean_Pa": 101380.0, "k_mean": 1.35 }
      }
    }
  ],

  "query_geometry": {
    "width_m": 10.0, "height_m": 60.0, "aspect_hw": 6.0, ...
  },

  "location_params": {
    "city": "Mumbai",
    "design_speed_ms": 44.0,
    "air_density": 1.20,
    "terrain_cat": 3,
    "wind_code": "IS 875-3:2015",
    "dynamic_pressure_Pa": 1161.6,
    "dominant_dirs": [225, 270, 315]
  },

  "response_time_s": 3.42,
  "input_type": "obj"
}
```

---

#### `POST /rag/query/stream`
SSE streaming version — answer word-by-word receive karo.

```js
// React with fetch streaming
const form = new FormData();
form.append('question', 'What is the wind pressure?');
form.append('location', 'Mumbai');
form.append('obj_file', objFile);

const res  = await fetch('/rag/query/stream', { method: 'POST', body: form });
const reader = res.body.getReader();
const decoder = new TextDecoder();

while (true) {
  const { done, value } = await reader.read();
  if (done) break;
  const lines = decoder.decode(value).split('\n\n');
  for (const line of lines) {
    if (!line.startsWith('data:')) continue;
    const event = JSON.parse(line.replace('data:', '').trim());

    if (event.type === 'matches') {
      // Show matched buildings immediately
      setMatches(event.data);
    } else if (event.type === 'chunk') {
      // Append to answer text
      setAnswer(prev => prev + event.data);
    } else if (event.type === 'done') {
      // Streaming complete
      setLoading(false);
    }
  }
}
```

---

### 7. ML PREDICTOR

#### `POST /predict/cfd`
OBJ upload → CFD statistics predict karo (JSON response — no file download).

```js
const form = new FormData();
form.append('file', objFile);
form.append('location', 'Mumbai');
form.append('wind_angle', '0');

const data = await fetch('/predict/cfd', {
  method: 'POST', body: form
}).then(r => r.json());
```

Response:
```json
{
  "json_card": {
    "id": "NEW_BUILDING",
    "name": "Supertall Tower",
    "width": 10.0,
    "depth": 10.0,
    "height": 60.0,
    "wind_dir": 0.0,
    "aspect_ratio_hw": 6.0,
    "aspect_ratio_hd": 6.0,
    "footprint_area": 100.0,
    "volume": 6000.0,
    "p_mean": 481432.49,
    "p_max": 482387.22,
    "p_min": 480508.67,
    "u_mean": 41.9274,
    "u_max": 46.1677,
    "k_mean": 6.616700,
    "epsilon_mean": 0.251200,
    "cells": 66623,
    "location": "Mumbai",
    "wind_speed_ms": 44.0,
    "air_density": 1.2,
    "dynamic_pressure_Pa": 1161.6,
    "stagnation_pressure_Pa": 481452.9,
    "wake_pressure_Pa": 480236.8,
    "windward_pressure_Pa": 929.28,
    "leeward_suction_Pa": -580.8,
    "roof_suction_Pa": -1045.44,
    "wind_code": "IS 875-3:2015",
    "terrain_category": 3
  },
  "scaled_stats": {
    "p_mean": 481432.49,
    "p_max": 482387.22,
    "p_min": 480508.67,
    "U_u_mean": 41.9274,
    "U_u_max": 46.1677,
    "k_mean": 6.6167,
    "epsilon_mean": 0.2512,
    "nut_mean": 11.3265,
    "phi_mean": 4186.52,
    "stagnation_pressure_Pa": 481452.9,
    "wake_pressure_Pa": 480236.8,
    "dynamic_pressure_Pa": 1161.6,
    "design_wind_speed_ms": 44.0,
    "air_density_kgm3": 1.2
  },
  "predicted_stats": {
    "p_mean": 101432.0, "p_max": 101650.0, ...
  },
  "geometry": {
    "width_m": 10.0, "height_m": 60.0, ...
  }
}
```

---

#### `POST /predict/files`
OBJ upload → ALL 6 OpenFOAM files ZIP download.

```js
const form = new FormData();
form.append('file', objFile);
form.append('location', 'Mumbai');
form.append('wind_angle', '0');

const res  = await fetch('/predict/files', { method: 'POST', body: form });
const blob = await res.blob();

// Trigger download
const url = URL.createObjectURL(blob);
const a   = document.createElement('a');
a.href     = url;
a.download = 'cfd_predicted.zip';
a.click();
URL.revokeObjectURL(url);
```

ZIP contains:
```
p               (911 KB)  volScalarField  — pressure, 66623 values
U               (2 MB)    volVectorField  — velocity (Ux,Uy,Uz), 66623 vectors
k               (626 KB)  volScalarField  — turbulent KE
epsilon         (586 KB)  volScalarField  — dissipation rate
nut             (621 KB)  volScalarField  — turbulent viscosity
phi             (2.3 MB)  surfaceScalarField — face flux, 198934 values
summary.json    (1 KB)    — all stats + geometry
building_metadata.json    — your required JSON card format
```

---

#### `POST /predict/field/{field_name}`
Ek specific field file download karo.

field_name: `p` | `U` | `k` | `epsilon` | `nut` | `phi`

```js
const form = new FormData();
form.append('file', objFile);
form.append('location', 'Mumbai');

// Download just pressure file
const res  = await fetch('/predict/field/p', { method: 'POST', body: form });
const text = await res.text();
// text = "FoamFile\n{\n    version 2.0;\n    ..."
```

---

### 8. PHYSICS (standalone calculations)

#### `GET /physics/velocity-profile`
Log-law velocity profile — line chart ke liye.

```js
const data = await fetch(
  '/physics/velocity-profile?location=Mumbai&building_h=60&n_points=30'
).then(r => r.json());

// data.profile = [{ height_m: 5, velocity_ms: 28.1 }, ...]
// Use in Recharts LineChart or Chart.js
```

Response:
```json
{
  "location": "Mumbai",
  "Vb": 44.0,
  "building_h": 60.0,
  "roof_velocity": 58.3,
  "profile": [
    { "height_m": 0.5,  "velocity_ms": 14.2 },
    { "height_m": 3.0,  "velocity_ms": 25.4 },
    { "height_m": 10.0, "velocity_ms": 32.0 },
    { "height_m": 30.0, "velocity_ms": 42.1 },
    { "height_m": 60.0, "velocity_ms": 58.3 }
  ]
}
```

---

#### `GET /physics/pressure-coefficients`
Standard Cp values + actual pressures for a location.

```js
const data = await fetch('/physics/pressure-coefficients?location=Mumbai').then(r => r.json());
```

```json
{
  "location": "Mumbai",
  "Vb": 44.0,
  "q_Pa": 1161.6,
  "Cp": {
    "Cp_windward": 0.80,
    "Cp_leeward": -0.50,
    "Cp_side_wall": -0.70,
    "Cp_roof_flat": -0.90,
    "Cp_roof_10deg": -0.50,
    "Cp_overhang": -1.30
  },
  "pressures_Pa": {
    "windward":  929.28,
    "leeward":   -580.8,
    "roof_flat": -1045.44,
    "side_wall": -813.12,
    "overhang":  -1509.08
  }
}
```

---

### 9. ADMIN (backend admin page)

#### `POST /admin/index`
Indexer run karo — naye buildings add karne ke baad.

```js
const form = new FormData();
form.append('data_dir', 'buildings');
form.append('out_dir', 'data');

const data = await fetch('/admin/index', { method: 'POST', body: form }).then(r => r.json());
// { status: "success", indexed: 100, skipped: 0, time_s: 45.2 }
```

---

#### `POST /admin/train`
ML model train karo.

```js
const form = new FormData();
form.append('n_estimators', '300');
form.append('mlp_epochs', '300');
form.append('feature_dim', '25');

const data = await fetch('/admin/train', { method: 'POST', body: form }).then(r => r.json());
// { status: "success", n_buildings: 100, training_time_s: 45, metrics: { r2_mean: 0.97 } }
```

---

#### `GET /admin/model/info`
Current model status.

```js
const info = await fetch('/admin/model/info').then(r => r.json());
// { status: "trained", size_mb: 12.4, metrics: { r2_mean: 0.97, ... } }
```

---

## Error Codes

| Code | Meaning | Fix |
|---|---|---|
| 400 | Bad request (wrong file type, missing param) | Check form fields |
| 404 | Building/city not found | Use exact ID from /buildings |
| 422 | OBJ parse failed | Check .obj file format |
| 503 | Engine not ready | Run auto_indexer + train model |
| 500 | Internal error | Check server logs |

---

## React Quick Start (TypeScript types)

```typescript
interface Building {
  id: string;
  name: string;
  geometry: {
    width: number; depth: number; height: number; floors: number;
    footprint_m2: number; volume_m3: number; shape_class: string;
    aspect_ratio_hw: number;
  };
  cfd: {
    p_mean_Pa: number; p_max_Pa: number; p_min_Pa: number;
    u_mean_ms: number; u_max_ms: number;
    k_mean: number; epsilon_mean: number;
    stagnation_pressure_Pa: number; wake_pressure_Pa: number;
  };
}

interface CFDPrediction {
  json_card: {
    id: string; name: string;
    width: number; depth: number; height: number;
    p_mean: number; p_max: number; p_min: number;
    u_mean: number; u_max: number;
    k_mean: number; epsilon_mean: number;
    stagnation_pressure_Pa: number; dynamic_pressure_Pa: number;
    wind_code: string; location: string;
  };
  scaled_stats: Record<string, number>;
  geometry: Record<string, number>;
}

interface RAGResponse {
  answer: string;
  matched_buildings: Array<{
    id: string; similarity: number; rerank_score: number;
    metadata: { geometry: object; cfd: object };
  }>;
  query_geometry: Record<string, number>;
  location_params: {
    city: string; design_speed_ms: number; air_density: number;
    terrain_cat: number; wind_code: string; dynamic_pressure_Pa: number;
  };
  response_time_s: number;
  input_type: 'obj' | 'image' | 'text';
}
```

---

## Total endpoints: 18

| Category | Count | Endpoints |
|---|---|---|
| Health | 2 | GET / , GET /health |
| Database | 5 | GET /buildings, /buildings/{id}, /buildings/stats/summary, /buildings/shapes/list, /search/similar/{id} |
| Locations | 3 | GET /locations, /locations/{city}, /locations/{city}/wind-rose |
| Parser | 2 | POST /parse/obj, /parse/image |
| Search | 1 | POST /search/similarity |
| RAG Q&A | 2 | POST /rag/query, /rag/query/stream |
| Predictor | 3 | POST /predict/cfd, /predict/files, /predict/field/{name} |
| Physics | 2 | GET /physics/velocity-profile, /physics/pressure-coefficients |
| Admin | 3 | POST /admin/index, /admin/train, GET /admin/model/info |
