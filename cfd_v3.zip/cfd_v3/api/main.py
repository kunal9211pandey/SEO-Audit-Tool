"""
api/main.py
===========
Production FastAPI backend for Building CFD AI System.

Base URL: http://localhost:8000
Docs:     http://localhost:8000/docs   (Swagger UI — auto-generated)
ReDoc:    http://localhost:8000/redoc

Run:
    uvicorn api.main:app --host 0.0.0.0 --port 8000 --reload

All endpoints return JSON. File download endpoints return ZIP/binary.

CORS is open for React dev server (localhost:3000 / 5173 / any origin).
"""

import os
import sys
import json
import time
import zipfile
import tempfile
import logging
import base64
from io import BytesIO
from typing import Optional, List

from fastapi import (
    FastAPI, File, Form, UploadFile, HTTPException, BackgroundTasks, Query
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

# ── path setup ────────────────────────────────────────────────────────────────
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ── env ───────────────────────────────────────────────────────────────────────
DATA_DIR      = os.environ.get("CFD_DATA_DIR",      "data")
MODEL_DIR     = os.environ.get("CFD_MODEL_DIR",     "models")
BUILDINGS_DIR = os.environ.get("CFD_BUILDINGS_DIR", "buildings")
GROQ_API_KEY  = os.environ.get(
    "GROQ_API_KEY",
    "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"
)

# ── FastAPI app ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="Building CFD AI API",
    description="Wind engineering CFD prediction, RAG Q&A, and OpenFOAM file generation",
    version="2.0.0",
    contact={"name": "Kunal", "email": "kunal@company.com"},
)

# ── CORS — allow React frontend ───────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],           # tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Lazy singletons (loaded once, reused) ────────────────────────────────────
_rag_engine    = None
_predictor     = None
_metadata      = None


def get_metadata():
    global _metadata
    if _metadata is None:
        p = os.path.join(DATA_DIR, "metadata.json")
        _metadata = json.load(open(p)) if os.path.exists(p) else []
    return _metadata


def get_engine():
    global _rag_engine
    if _rag_engine is None:
        try:
            from rag.advanced_engine import AdvancedCFDRagEngine
            _rag_engine = AdvancedCFDRagEngine(
                data_dir=DATA_DIR, buildings_dir=BUILDINGS_DIR
            )
            _rag_engine.load()
            logger.info("RAG engine loaded")
        except Exception as e:
            logger.error(f"RAG engine load error: {e}")
    return _rag_engine


def get_predictor():
    global _predictor
    if _predictor is None:
        try:
            from ml.advanced_predictor import MasterPredictor
            _predictor = MasterPredictor()
            _predictor.load(MODEL_DIR)
            logger.info("Predictor loaded")
        except Exception as e:
            logger.error(f"Predictor load error: {e}")
    return _predictor


# ─────────────────────────────────────────────────────────────────────────────
#  PYDANTIC SCHEMAS  (request / response shapes for React dev)
# ─────────────────────────────────────────────────────────────────────────────

class GeometryFeatures(BaseModel):
    width_m:             float
    depth_m:             float
    height_m:            float
    footprint_m2:        float
    volume_m3:           float
    frontal_area_m2:     float
    aspect_hw:           float
    aspect_hd:           float
    slenderness:         float
    compactness:         float
    n_vertices:          float
    n_faces:             float
    surface_irregularity: float
    blockage_ratio:      float


class CFDPrediction(BaseModel):
    p_mean:           float
    p_max:            float
    p_min:            float
    u_mean:           float
    u_max:            float
    k_mean:           float
    epsilon_mean:     float
    nut_mean:         float
    phi_mean:         float
    stagnation_pressure_Pa: float
    wake_pressure_Pa:       float
    dynamic_pressure_Pa:    float
    design_wind_speed_ms:   float
    air_density_kgm3:       float
    windward_pressure_Pa:   float
    leeward_suction_Pa:     float
    roof_suction_Pa:        float
    wind_code:              str
    terrain_category:       int
    location:               str
    wind_dir:               float


class BuildingCard(BaseModel):
    id:               str
    name:             str
    width:            float
    depth:            float
    height:           float
    wind_dir:         float
    aspect_ratio_hw:  float
    aspect_ratio_hd:  float
    footprint_area:   float
    volume:           float
    p_mean:           float
    p_max:            float
    p_min:            float
    u_mean:           float
    u_max:            float
    k_mean:           float
    epsilon_mean:     float
    cells:            int
    location:         str
    wind_speed_ms:    float
    air_density:      float
    dynamic_pressure_Pa:    float
    stagnation_pressure_Pa: float
    wake_pressure_Pa:       float
    windward_pressure_Pa:   float
    leeward_suction_Pa:     float
    roof_suction_Pa:        float
    wind_code:              str
    terrain_category:       int


class MatchedBuilding(BaseModel):
    id:            str
    similarity:    float
    rerank_score:  float
    geometry:      dict
    cfd:           dict


class RAGResponse(BaseModel):
    answer:             str
    matched_buildings:  List[MatchedBuilding]
    query_geometry:     dict
    location_params:    dict
    response_time_s:    float
    input_type:         str


class VelocityProfilePoint(BaseModel):
    height_m: float
    velocity_ms: float


class LocationInfo(BaseModel):
    city:             str
    Vb:               float
    rho:              float
    z0:               float
    terrain_cat:      int
    wind_code:        str
    wind_dirs:        List[int]
    dynamic_pressure: float
    notes:            str
    lat:              float
    lon:              float


class IndexingStatus(BaseModel):
    status:     str
    total:      int
    indexed:    int
    skipped:    int
    time_s:     float


# ─────────────────────────────────────────────────────────────────────────────
#  ROOT
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/", tags=["health"])
def root():
    """Health check — confirm API is running."""
    return {
        "status": "ok",
        "version": "2.0.0",
        "endpoints": "/docs",
        "data_dir": DATA_DIR,
        "model_dir": MODEL_DIR,
        "buildings_dir": BUILDINGS_DIR,
    }


@app.get("/health", tags=["health"])
def health():
    """
    Detailed system health.

    Returns status of each subsystem:
    - database (metadata.json)
    - ml_model (ensemble.pkl)
    - faiss_index
    """
    meta = get_metadata()
    model_ok = os.path.exists(os.path.join(MODEL_DIR, "ensemble.pkl"))
    faiss_ok = os.path.exists(
        os.path.join(DATA_DIR, "hybrid_faiss_index", "hybrid_faiss.index")
    ) or os.path.exists(
        os.path.join(DATA_DIR, "faiss_index", "faiss.index")
    )
    return {
        "database":   {"status": "ok" if meta else "empty", "count": len(meta)},
        "ml_model":   {"status": "ok" if model_ok else "not_trained"},
        "faiss_index":{"status": "ok" if faiss_ok else "not_built"},
        "groq_key":   {"status": "set" if GROQ_API_KEY else "missing"},
    }


# ─────────────────────────────────────────────────────────────────────────────
#  1. DATABASE — list, get, search buildings
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/buildings", tags=["database"])
def list_buildings(
    skip:   int = Query(0,  description="Pagination offset"),
    limit:  int = Query(20, description="Page size (max 100)"),
    search: str = Query("", description="Filter by building ID or name"),
    shape:  str = Query("", description="Filter by shape_class"),
):
    """
    List all buildings in the database with pagination and optional filtering.

    React usage:
        GET /buildings?skip=0&limit=20
        GET /buildings?search=B042
        GET /buildings?shape=Tall+Tower&limit=50
    """
    meta = get_metadata()
    filtered = meta

    if search:
        s = search.lower()
        filtered = [
            m for m in filtered
            if s in m.get("id", "").lower()
            or s in m.get("name", "").lower()
            or s in m.get("geometry", {}).get("shape_class", "").lower()
        ]

    if shape:
        filtered = [
            m for m in filtered
            if m.get("geometry", {}).get("shape_class", "") == shape
        ]

    total = len(filtered)
    page  = filtered[skip: skip + min(limit, 100)]

    return {
        "total":     total,
        "skip":      skip,
        "limit":     limit,
        "buildings": page,
    }


@app.get("/buildings/{building_id}", tags=["database"])
def get_building(building_id: str):
    """
    Get full metadata for a single building by ID.

    React usage:
        GET /buildings/B001
        GET /buildings/B042
    """
    meta = get_metadata()
    match = next((m for m in meta if m.get("id") == building_id), None)
    if not match:
        raise HTTPException(404, f"Building {building_id} not found")
    return match


@app.get("/buildings/stats/summary", tags=["database"])
def database_stats():
    """
    Database-level statistics: count, height range, shape distribution.

    React usage: call on Home page load to fill stat cards.
    """
    meta = get_metadata()
    if not meta:
        return {"total": 0}

    heights  = [m.get("geometry", {}).get("height", 0) for m in meta]
    u_means  = [m.get("cfd", {}).get("u_mean_ms", 0) for m in meta]
    shapes   = {}
    for m in meta:
        s = m.get("geometry", {}).get("shape_class", "Unknown")
        shapes[s] = shapes.get(s, 0) + 1

    return {
        "total":         len(meta),
        "height_avg_m":  round(sum(heights) / len(heights), 1) if heights else 0,
        "height_max_m":  round(max(heights), 1) if heights else 0,
        "height_min_m":  round(min(heights), 1) if heights else 0,
        "u_mean_avg_ms": round(sum(u_means) / len(u_means), 2) if u_means else 0,
        "shape_distribution": shapes,
    }


@app.get("/buildings/shapes/list", tags=["database"])
def list_shapes():
    """
    Get all unique shape classes in the database.

    React usage: populate shape filter dropdown.
    """
    meta   = get_metadata()
    shapes = sorted(set(
        m.get("geometry", {}).get("shape_class", "Unknown") for m in meta
    ))
    return {"shapes": shapes}


# ─────────────────────────────────────────────────────────────────────────────
#  2. LOCATION / WIND PARAMETERS
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/locations", tags=["locations"])
def list_locations():
    """
    List all supported cities with their wind engineering parameters.

    React usage: populate city selector dropdown.
    """
    from utils.location_params import LOCATIONS, dynamic_pressure
    result = []
    for city, loc in LOCATIONS.items():
        result.append({
            "city":             city,
            "Vb":               loc["Vb"],
            "rho":              loc["rho"],
            "z0":               loc["z0"],
            "terrain_cat":      loc["terrain_cat"],
            "wind_code":        loc["wind_code"],
            "wind_dirs":        loc["wind_dirs"],
            "dynamic_pressure": round(dynamic_pressure(loc["Vb"], loc["rho"]), 2),
            "lat":              loc["lat"],
            "lon":              loc["lon"],
            "notes":            loc.get("notes", ""),
        })
    return {"count": len(result), "locations": result}


@app.get("/locations/{city}", tags=["locations"])
def get_location(city: str):
    """
    Get complete wind parameters for one city.

    React usage:
        GET /locations/Mumbai
        GET /locations/New%20York

    Returns: Vb, rho, z0, terrain_cat, Cp values, dynamic pressure,
             velocity profile at standard heights, wind code reference.
    """
    from utils.location_params import LOCATIONS, dynamic_pressure, wind_pressure_coefficients, log_law_velocity

    loc = LOCATIONS.get(city)
    if not loc:
        raise HTTPException(404, f"City '{city}' not found. Use GET /locations for full list.")

    Cp  = wind_pressure_coefficients()
    q   = dynamic_pressure(loc["Vb"], loc["rho"])

    # velocity profile at standard engineering heights
    profile = []
    for z in [3, 5, 10, 20, 30, 50, 75, 100, 150, 200]:
        profile.append({
            "height_m":    z,
            "velocity_ms": round(log_law_velocity(loc["Vb"], z, z0=loc["z0"]), 2),
        })

    return {
        "city":             city,
        "Vb":               loc["Vb"],
        "rho":              loc["rho"],
        "z0":               loc["z0"],
        "terrain_cat":      loc["terrain_cat"],
        "wind_code":        loc["wind_code"],
        "wind_dirs":        loc["wind_dirs"],
        "lat":              loc["lat"],
        "lon":              loc["lon"],
        "notes":            loc.get("notes", ""),
        "dynamic_pressure_Pa":   round(q, 2),
        "windward_pressure_Pa":  round(q * Cp["Cp_windward"], 2),
        "leeward_suction_Pa":    round(q * Cp["Cp_leeward"], 2),
        "roof_suction_Pa":       round(q * Cp["Cp_roof_flat"], 2),
        "side_suction_Pa":       round(q * Cp["Cp_side_wall"], 2),
        "velocity_profile":      profile,
    }


@app.get("/locations/{city}/wind-rose", tags=["locations"])
def get_wind_rose(city: str):
    """
    Wind rose data for a city: direction probabilities and speeds.

    React usage: feed to D3.js / Chart.js polar chart.
    """
    from utils.location_params import LOCATIONS, dynamic_pressure

    loc = LOCATIONS.get(city)
    if not loc:
        raise HTTPException(404, f"City '{city}' not found")

    dirs8 = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
    angles = [0, 45, 90, 135, 180, 225, 270, 315]
    dom = loc["wind_dirs"]
    q   = dynamic_pressure(loc["Vb"], loc["rho"])

    rose = []
    for label, angle in zip(dirs8, angles):
        is_dom = any(abs(angle - d) < 30 or abs(angle - d - 360) < 30 for d in dom)
        intensity = 0.85 if is_dom else 0.30
        rose.append({
            "direction":   label,
            "angle_deg":   angle,
            "dominant":    is_dom,
            "intensity":   intensity,
            "speed_ms":    round(loc["Vb"] * intensity, 1),
            "pressure_Pa": round(q * intensity**2, 1),
        })

    return {
        "city":        city,
        "Vb":          loc["Vb"],
        "wind_dirs":   dom,
        "rose":        rose,
    }


# ─────────────────────────────────────────────────────────────────────────────
#  3. OBJ PARSER — extract geometry features
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/parse/obj", tags=["parser"])
async def parse_obj(
    file:       UploadFile = File(..., description="Wavefront .obj file"),
    wind_angle: float      = Form(0.0, description="Wind angle in degrees"),
):
    """
    Parse a building .obj file and extract 25 geometric features.

    React usage:
        const form = new FormData();
        form.append('file', objFile);
        form.append('wind_angle', '45');
        fetch('/parse/obj', { method:'POST', body: form })

    Returns:
        geometry features dict (25 values) used for FAISS search and ML prediction.
    """
    if not file.filename.endswith(".obj"):
        raise HTTPException(400, "File must be a .obj file")

    content = (await file.read()).decode("utf-8")

    try:
        from utils.obj_parser import extract_features
        feats = extract_features(content=content, wind_angle_deg=wind_angle)
        return {
            "filename":    file.filename,
            "wind_angle":  wind_angle,
            "features":    {k: round(float(v), 4) for k, v in feats.items()},
            "n_features":  len(feats),
        }
    except Exception as e:
        raise HTTPException(422, f"OBJ parse error: {e}")


@app.post("/parse/image", tags=["parser"])
async def parse_image_geometry(
    file: UploadFile = File(..., description="Building photo (JPG/PNG)"),
):
    """
    Use Groq Vision LLM to estimate building geometry from a photo.

    React usage:
        const form = new FormData();
        form.append('file', imageFile);
        fetch('/parse/image', { method:'POST', body: form })

    Returns:
        Estimated geometry {width_m, depth_m, height_m, n_floors, shape_class, confidence}
        Plus derived 25-dim feature vector for downstream use.
    """
    allowed = {"image/jpeg", "image/jpg", "image/png", "image/webp"}
    if file.content_type not in allowed:
        raise HTTPException(400, "File must be JPG or PNG image")

    image_bytes = await file.read()
    mime        = file.content_type or "image/jpeg"

    engine = get_engine()
    if engine is None:
        raise HTTPException(503, "RAG engine not available. Run auto_indexer first.")

    geom = engine.estimate_geometry_from_image(image_bytes, mime)

    # Also derive feature vector
    try:
        vec, feats = engine._geom_dict_to_features(geom)
        feats_out  = {k: round(float(v), 4) for k, v in feats.items()}
    except Exception:
        feats_out = {}

    return {
        "filename":         file.filename,
        "vision_estimate":  geom,
        "features":         feats_out,
        "confidence":       geom.get("confidence", "Low"),
    }


# ─────────────────────────────────────────────────────────────────────────────
#  4. SIMILARITY SEARCH (FAISS)
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/search/similarity", tags=["search"])
async def similarity_search(
    file:        UploadFile = File(..., description="Wavefront .obj file"),
    location:    str        = Form("Bengaluru", description="City name"),
    wind_angle:  float      = Form(0.0,         description="Wind angle degrees"),
    top_k:       int        = Form(5,            description="Number of results (1-20)"),
):
    """
    Find the most similar buildings from the database for a given .obj file.

    Uses Hybrid FAISS (geometry 60% + wind direction 30% + terrain 10%)
    followed by cross-encoder re-ranking.

    React usage:
        const form = new FormData();
        form.append('file', objFile);
        form.append('location', 'Mumbai');
        form.append('wind_angle', '90');
        form.append('top_k', '5');
        fetch('/search/similarity', { method:'POST', body: form })

    Returns: ranked list of similar buildings with similarity scores.
    """
    content = (await file.read()).decode("utf-8")
    top_k   = min(max(top_k, 1), 20)

    engine = get_engine()
    if engine is None:
        raise HTTPException(503, "RAG engine not ready")

    try:
        from utils.obj_parser import extract_features, features_to_vector, ALL_25_FEATURES
        from utils.location_params import get_location
        from rag.advanced_engine import rerank_matches

        feats = extract_features(content=content, wind_angle_deg=wind_angle)
        vec   = features_to_vector(feats, keys=ALL_25_FEATURES)
        loc   = get_location(location)

        raw      = engine.faiss_index.search(
            vec, wind_angle=wind_angle,
            terrain_cat=loc["terrain_cat"],
            top_k=min(top_k * 4, 20),
        )
        reranked = rerank_matches(feats, raw, top_k=top_k)

        return {
            "query_geometry":  {k: round(float(v), 3) for k, v in feats.items()},
            "location":        location,
            "wind_angle":      wind_angle,
            "total_searched":  len(raw),
            "results": [
                {
                    "id":           m["id"],
                    "similarity":   m["similarity"],
                    "rerank_score": m.get("rerank_score", m["similarity"]),
                    "geometry":     m["metadata"].get("geometry", {}),
                    "cfd":          m["metadata"].get("cfd", {}),
                }
                for m in reranked
            ],
        }
    except Exception as e:
        raise HTTPException(500, f"Search error: {e}")


@app.get("/search/similar/{building_id}", tags=["search"])
def find_similar_to_db_building(
    building_id: str,
    top_k:       int = Query(5, description="Number of similar buildings"),
    location:    str = Query("Bengaluru"),
    wind_angle:  float = Query(0.0),
):
    """
    Find buildings similar to an existing database building by ID.

    React usage:
        GET /search/similar/B042?top_k=5&location=Mumbai
    """
    meta   = get_metadata()
    target = next((m for m in meta if m.get("id") == building_id), None)
    if not target:
        raise HTTPException(404, f"Building {building_id} not found")

    import numpy as np
    from utils.obj_parser import ALL_25_FEATURES
    from utils.location_params import get_location
    from rag.advanced_engine import rerank_matches

    engine = get_engine()
    if engine is None:
        raise HTTPException(503, "RAG engine not ready")

    feats_dict = dict(zip(ALL_25_FEATURES, target.get("features_25", [0]*25)))
    vec        = np.array(target.get("features_25", [0]*25), dtype=np.float32)
    loc        = get_location(location)

    raw      = engine.faiss_index.search(
        vec, wind_angle=wind_angle,
        terrain_cat=loc["terrain_cat"],
        top_k=top_k * 4,
    )
    # Exclude self
    raw      = [r for r in raw if r["id"] != building_id]
    reranked = rerank_matches(feats_dict, raw, top_k=top_k)

    return {
        "source_building": building_id,
        "results": [
            {
                "id":           m["id"],
                "similarity":   m["similarity"],
                "rerank_score": m.get("rerank_score", m["similarity"]),
                "geometry":     m["metadata"].get("geometry", {}),
                "cfd":          m["metadata"].get("cfd", {}),
            }
            for m in reranked
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
#  5. RAG Q&A  (main AI endpoint)
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/rag/query", tags=["rag"])
async def rag_query(
    question:   str        = Form(..., description="Wind engineering question"),
    location:   str        = Form("Bengaluru", description="City name"),
    wind_angle: float      = Form(0.0,         description="Wind angle degrees"),
    top_k:      int        = Form(3,            description="Similar buildings to use (1-5)"),
    obj_file:   Optional[UploadFile] = File(None, description="Optional building.obj"),
    image_file: Optional[UploadFile] = File(None, description="Optional building photo"),
):
    """
    Main RAG Q&A endpoint.

    Accepts 3 input modes:
    - OBJ file: most accurate (geometry extracted from mesh)
    - Image: photo/render (geometry estimated via Vision LLM)
    - Text only: no file (uses representative buildings)

    Pipeline:
    1. Extract geometry from file (or estimate from image)
    2. Hybrid FAISS search: top-20 similar buildings
    3. Cross-encoder re-rank: top-20 -> top-K
    4. Build zone-level CFD context
    5. Groq LLM (llama-3.3-70b) generates engineering analysis

    React usage (OBJ mode):
        const form = new FormData();
        form.append('question', 'What is the wind pressure?');
        form.append('location', 'Mumbai');
        form.append('wind_angle', '0');
        form.append('top_k', '3');
        form.append('obj_file', objFile);
        fetch('/rag/query', { method:'POST', body: form })

    React usage (text only):
        const form = new FormData();
        form.append('question', 'Explain vortex shedding risk');
        form.append('location', 'Delhi');
        fetch('/rag/query', { method:'POST', body: form })
    """
    engine = get_engine()
    if engine is None:
        raise HTTPException(503, "RAG engine not ready. Run auto_indexer first.")

    obj_content  = None
    image_bytes  = None
    image_mime   = "image/jpeg"

    if obj_file:
        obj_content = (await obj_file.read()).decode("utf-8")
    elif image_file:
        image_bytes = await image_file.read()
        image_mime  = image_file.content_type or "image/jpeg"

    try:
        result = engine.query(
            question=question,
            obj_content=obj_content,
            image_bytes=image_bytes,
            image_mime=image_mime,
            location=location,
            wind_angle=wind_angle,
            top_k=min(max(top_k, 1), 5),
        )
        return result
    except Exception as e:
        raise HTTPException(500, f"RAG query error: {e}")


@app.post("/rag/query/stream", tags=["rag"])
async def rag_query_stream(
    question:   str        = Form(...),
    location:   str        = Form("Bengaluru"),
    wind_angle: float      = Form(0.0),
    top_k:      int        = Form(3),
    obj_file:   Optional[UploadFile] = File(None),
    image_file: Optional[UploadFile] = File(None),
):
    """
    Streaming version of RAG Q&A. Returns Server-Sent Events (SSE).

    React usage (with EventSource or fetch stream):
        const es = new EventSource('/rag/query/stream?...');
        es.onmessage = (e) => { ... };

    Events emitted:
        { type: 'matches',  data: [...] }
        { type: 'chunk',    data: "partial answer text" }
        { type: 'done',     data: { response_time_s } }
    """
    from fastapi.responses import StreamingResponse

    engine = get_engine()
    if engine is None:
        raise HTTPException(503, "RAG engine not ready")

    obj_content = None
    image_bytes = None
    image_mime  = "image/jpeg"

    if obj_file:
        obj_content = (await obj_file.read()).decode("utf-8")
    elif image_file:
        image_bytes = await image_file.read()
        image_mime  = image_file.content_type or "image/jpeg"

    async def event_stream():
        import asyncio
        t0 = time.time()

        try:
            # Step 1: run non-streaming query (LLM streaming with Groq is separate)
            result = engine.query(
                question=question,
                obj_content=obj_content,
                image_bytes=image_bytes,
                image_mime=image_mime,
                location=location,
                wind_angle=wind_angle,
                top_k=top_k,
            )

            # Emit matches first
            matches_payload = json.dumps(result.get("matched_buildings", []))
            yield f"data: {json.dumps({'type':'matches','data': result.get('matched_buildings',[])})}\n\n"
            await asyncio.sleep(0)

            # Stream answer word by word (simulate streaming for UX)
            answer = result.get("answer", "")
            words  = answer.split(" ")
            chunk  = ""
            for i, word in enumerate(words):
                chunk += word + " "
                if (i + 1) % 8 == 0 or i == len(words) - 1:
                    yield f"data: {json.dumps({'type':'chunk','data':chunk})}\n\n"
                    chunk = ""
                    await asyncio.sleep(0.02)

            yield f"data: {json.dumps({'type':'done','data':{'response_time_s': round(time.time()-t0, 2)}})}\n\n"

        except Exception as e:
            yield f"data: {json.dumps({'type':'error','data':str(e)})}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


# ─────────────────────────────────────────────────────────────────────────────
#  6. ML PREDICTOR
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/predict/cfd", tags=["predictor"])
async def predict_cfd(
    file:        UploadFile = File(..., description="Wavefront .obj file"),
    location:    str        = Form("Bengaluru", description="City name"),
    wind_angle:  float      = Form(0.0,         description="Wind angle degrees"),
):
    """
    Predict CFD statistics for a new building from its .obj file.

    Uses XGBoost + MLP ResidualNet ensemble model.
    Scales results to the given city's wind conditions.

    React usage:
        const form = new FormData();
        form.append('file', objFile);
        form.append('location', 'Mumbai');
        form.append('wind_angle', '45');
        const res = await fetch('/predict/cfd', { method:'POST', body: form });
        const data = await res.json();
        // data.json_card → building metadata card (your required format)
        // data.scaled_stats → all CFD values

    Returns:
        json_card      : full building metadata (your required JSON format)
        scaled_stats   : p, U, k, epsilon, nut, phi — scaled to city
        predicted_stats: raw model output (before location scaling)
        geometry       : 25 extracted features
    """
    predictor = get_predictor()
    if predictor is None:
        raise HTTPException(503, "ML model not trained. Run training notebook first.")

    content = (await file.read()).decode("utf-8")

    try:
        from utils.obj_parser import extract_features
        feats = extract_features(content=content, wind_angle_deg=wind_angle)

        # Find matched building dir for real-data interpolation
        matched_dir = None
        engine = get_engine()
        if engine and engine._ready:
            from utils.obj_parser import features_to_vector, ALL_25_FEATURES
            from utils.location_params import get_location
            from rag.advanced_engine import rerank_matches
            import numpy as np
            vec = features_to_vector(feats, keys=ALL_25_FEATURES)
            loc = get_location(location)
            try:
                candidates = engine.faiss_index.search(
                    vec, wind_angle=wind_angle,
                    terrain_cat=loc["terrain_cat"], top_k=1
                )
                if candidates:
                    bid = candidates[0]["metadata"].get("id", "")
                    matched_dir = candidates[0]["metadata"].get(
                        "data_path", os.path.join(BUILDINGS_DIR, bid)
                    )
            except Exception:
                pass

        with tempfile.TemporaryDirectory() as td:
            result = predictor.predict_and_generate(
                geometry_feats=feats,
                location_name=location,
                wind_angle=wind_angle,
                out_dir=td,
                matched_building_dir=matched_dir,
            )
            # Don't return file paths — use /predict/files for downloads
            return {
                "json_card":        result["json_card"],
                "scaled_stats":     {k: round(float(v), 4) for k, v in result["scaled_stats"].items()
                                     if isinstance(v, (int, float))},
                "predicted_stats":  {k: round(float(v), 4) for k, v in result["predicted_stats"].items()},
                "geometry":         {k: round(float(v), 4) for k, v in feats.items()},
                "location":         result["location"],
                "generation_source": result["file_paths"].get("summary", ""),
            }
    except Exception as e:
        raise HTTPException(500, f"Prediction error: {e}")


@app.post("/predict/files", tags=["predictor"])
async def predict_and_download_files(
    file:       UploadFile = File(..., description="Wavefront .obj file"),
    location:   str        = Form("Bengaluru", description="City name"),
    wind_angle: float      = Form(0.0,         description="Wind angle degrees"),
):
    """
    Predict CFD fields and return ALL OpenFOAM files as a ZIP download.

    Files in ZIP: p, U, k, epsilon, nut, phi, summary.json

    Each field file: exact OpenFOAM format with FoamFile header,
    66,623 cell values, boundary conditions.

    React usage (download ZIP):
        const form = new FormData();
        form.append('file', objFile);
        form.append('location', 'Mumbai');
        form.append('wind_angle', '0');

        const res = await fetch('/predict/files', { method:'POST', body: form });
        const blob = await res.blob();
        const url  = URL.createObjectURL(blob);
        const a    = document.createElement('a');
        a.href = url; a.download = 'cfd_predicted.zip'; a.click();
    """
    predictor = get_predictor()
    if predictor is None:
        raise HTTPException(503, "ML model not trained.")

    content = (await file.read()).decode("utf-8")

    try:
        from utils.obj_parser import extract_features
        feats = extract_features(content=content, wind_angle_deg=wind_angle)

        matched_dir = _find_matched_dir(feats, location, wind_angle)

        with tempfile.TemporaryDirectory() as td:
            result = predictor.predict_and_generate(
                geometry_feats=feats,
                location_name=location,
                wind_angle=wind_angle,
                out_dir=td,
                matched_building_dir=matched_dir,
            )

            # Build ZIP in memory
            buf = BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for fname, fpath in result["file_paths"].items():
                    if os.path.exists(fpath):
                        zf.write(fpath, os.path.basename(fpath))
                # Also add JSON card
                zf.writestr(
                    "building_metadata.json",
                    json.dumps(result["json_card"], indent=2)
                )
            buf.seek(0)

        bid = result["json_card"].get("id", "building")
        return StreamingResponse(
            buf,
            media_type="application/zip",
            headers={
                "Content-Disposition": f'attachment; filename="cfd_{bid}_{location}.zip"'
            },
        )
    except Exception as e:
        raise HTTPException(500, f"File generation error: {e}")


@app.post("/predict/field/{field_name}", tags=["predictor"])
async def predict_single_field(
    field_name: str,
    file:       UploadFile = File(...),
    location:   str        = Form("Bengaluru"),
    wind_angle: float      = Form(0.0),
):
    """
    Predict and download a SINGLE OpenFOAM field file.

    field_name: p | U | k | epsilon | nut | phi

    React usage:
        GET /predict/field/p  (with form data)

    Returns the raw OpenFOAM field file as plain text download.
    """
    valid = {"p", "U", "k", "epsilon", "nut", "phi"}
    if field_name not in valid:
        raise HTTPException(400, f"field_name must be one of: {valid}")

    predictor = get_predictor()
    if predictor is None:
        raise HTTPException(503, "ML model not trained.")

    content = (await file.read()).decode("utf-8")

    try:
        from utils.obj_parser import extract_features
        feats       = extract_features(content=content, wind_angle_deg=wind_angle)
        matched_dir = _find_matched_dir(feats, location, wind_angle)

        with tempfile.TemporaryDirectory() as td:
            result = predictor.predict_and_generate(
                geometry_feats=feats,
                location_name=location,
                wind_angle=wind_angle,
                out_dir=td,
                matched_building_dir=matched_dir,
            )
            fpath = result["file_paths"].get(field_name)
            if not fpath or not os.path.exists(fpath):
                raise HTTPException(404, f"Field {field_name} not generated")

            with open(fpath) as f:
                field_content = f.read()

        return StreamingResponse(
            iter([field_content]),
            media_type="text/plain",
            headers={
                "Content-Disposition": f'attachment; filename="{field_name}"'
            },
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Field generation error: {e}")


def _find_matched_dir(feats: dict, location: str, wind_angle: float) -> Optional[str]:
    """Internal helper: find best matched building directory for interpolation."""
    try:
        from utils.obj_parser import features_to_vector, ALL_25_FEATURES
        from utils.location_params import get_location
        import numpy as np

        engine = get_engine()
        if not engine or not engine._ready:
            return None

        vec = features_to_vector(feats, keys=ALL_25_FEATURES)
        loc = get_location(location)
        candidates = engine.faiss_index.search(
            vec, wind_angle=wind_angle,
            terrain_cat=loc["terrain_cat"], top_k=1
        )
        if candidates:
            bid = candidates[0]["metadata"].get("id", "")
            return candidates[0]["metadata"].get(
                "data_path", os.path.join(BUILDINGS_DIR, bid)
            )
    except Exception:
        pass
    return None


# ─────────────────────────────────────────────────────────────────────────────
#  7. VELOCITY PROFILE  (standalone — for charts)
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/physics/velocity-profile", tags=["physics"])
def velocity_profile(
    location:      str   = Query("Bengaluru", description="City name"),
    building_h:    float = Query(30.0,        description="Building height (m)"),
    wind_angle:    float = Query(0.0,         description="Wind angle degrees"),
    n_points:      int   = Query(20,          description="Number of profile points"),
):
    """
    Compute log-law wind velocity profile for a location and building.

    Returns height vs velocity data ready for a line chart.

    React usage:
        GET /physics/velocity-profile?location=Mumbai&building_h=60&n_points=30
    """
    from utils.location_params import get_location, log_law_velocity
    import numpy as np

    loc = get_location(location)
    V   = loc["Vb"]
    z0  = loc["z0"]

    max_z  = max(building_h * 1.5, 50)
    heights = np.linspace(0.5, max_z, n_points).tolist()

    profile = []
    for z in heights:
        Vz = log_law_velocity(V, z, z0=z0)
        profile.append({
            "height_m":    round(z, 1),
            "velocity_ms": round(max(Vz, 0), 3),
        })

    return {
        "location":      location,
        "Vb":            V,
        "z0":            z0,
        "building_h":    building_h,
        "wind_angle":    wind_angle,
        "profile":       profile,
        "roof_velocity": round(log_law_velocity(V, building_h, z0=z0), 3),
    }


@app.get("/physics/pressure-coefficients", tags=["physics"])
def pressure_coefficients(
    location: str = Query("Bengaluru"),
):
    """
    Standard external pressure coefficients (Cp) for the given location.

    React usage:
        GET /physics/pressure-coefficients?location=Mumbai
    """
    from utils.location_params import get_location, dynamic_pressure, wind_pressure_coefficients

    loc = get_location(location)
    q   = dynamic_pressure(loc["Vb"], loc["rho"])
    Cp  = wind_pressure_coefficients()

    return {
        "location": location,
        "Vb":       loc["Vb"],
        "q_Pa":     round(q, 2),
        "Cp": Cp,
        "pressures_Pa": {
            "windward":  round(q * Cp["Cp_windward"], 2),
            "leeward":   round(q * Cp["Cp_leeward"],  2),
            "roof_flat": round(q * Cp["Cp_roof_flat"], 2),
            "side_wall": round(q * Cp["Cp_side_wall"], 2),
            "overhang":  round(q * Cp["Cp_overhang"],  2),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
#  8. INDEXING & TRAINING  (admin endpoints)
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/admin/index", tags=["admin"])
def run_indexer(
    data_dir:      str = Form("buildings", description="Buildings folder path"),
    out_dir:       str = Form("data",      description="Output data folder"),
):
    """
    Run auto-indexer on the buildings directory.

    Scans all building folders, extracts geometry + CFD features,
    writes metadata.json and feature matrices.

    React usage (admin page):
        const form = new FormData();
        form.append('data_dir', 'buildings');
        form.append('out_dir', 'data');
        fetch('/admin/index', { method:'POST', body: form })

    Returns: count of indexed buildings, skipped count, time taken.
    """
    try:
        from utils.auto_indexer import run_indexer as _run_indexer
        t0      = time.time()
        results = _run_indexer(data_dir, out_dir)
        elapsed = round(time.time() - t0, 1)

        # Reload metadata cache
        global _metadata, _rag_engine
        _metadata   = None
        _rag_engine = None

        return {
            "status":        "success",
            "indexed":       len(results),
            "skipped":       0,
            "time_s":        elapsed,
            "metadata_path": os.path.join(out_dir, "metadata.json"),
        }
    except Exception as e:
        raise HTTPException(500, f"Indexing error: {e}")


@app.post("/admin/train", tags=["admin"])
def train_model(
    n_estimators:  int   = Form(300,  description="XGBoost n_estimators"),
    mlp_epochs:    int   = Form(300,  description="MLP training epochs"),
    feature_dim:   int   = Form(25,   description="Feature dimensions (9 or 25)"),
):
    """
    Train the ensemble ML model (XGBoost + MLP + Stacking).

    Requires metadata.json to exist (run /admin/index first).

    React usage:
        const form = new FormData();
        form.append('n_estimators', '300');
        form.append('mlp_epochs', '300');
        fetch('/admin/train', { method:'POST', body: form })

    Returns: training metrics (R2, MAE, MAPE per field).
    Note: This call blocks until training completes (30s-3min).
    """
    meta_path = os.path.join(DATA_DIR, "metadata.json")
    if not os.path.exists(meta_path):
        raise HTTPException(400, "metadata.json not found. Run /admin/index first.")

    with open(meta_path) as f:
        metadata = json.load(f)

    if len(metadata) < 5:
        raise HTTPException(400, f"Need >= 5 buildings to train. Got {len(metadata)}.")

    try:
        from ml.advanced_predictor import MasterPredictor
        t0        = time.time()
        predictor = MasterPredictor()
        metrics   = predictor.train(metadata, feature_dim=feature_dim)
        predictor.save(MODEL_DIR)
        elapsed   = round(time.time() - t0, 1)

        # Reset predictor cache
        global _predictor
        _predictor = None

        return {
            "status":          "success",
            "n_buildings":     len(metadata),
            "training_time_s": elapsed,
            "model_path":      os.path.join(MODEL_DIR, "ensemble.pkl"),
            "metrics":         metrics,
        }
    except Exception as e:
        raise HTTPException(500, f"Training error: {e}")


@app.get("/admin/model/info", tags=["admin"])
def model_info():
    """
    Get information about the currently loaded ML model.

    React usage:
        GET /admin/model/info
    """
    pkl_path     = os.path.join(MODEL_DIR, "ensemble.pkl")
    metrics_path = os.path.join(MODEL_DIR, "training_metrics.json")

    if not os.path.exists(pkl_path):
        return {"status": "not_trained", "message": "Run POST /admin/train first"}

    size_mb = round(os.path.getsize(pkl_path) / 1024 / 1024, 2)
    info    = {
        "status":   "trained",
        "path":     pkl_path,
        "size_mb":  size_mb,
        "modified": os.path.getmtime(pkl_path),
    }

    if os.path.exists(metrics_path):
        with open(metrics_path) as f:
            info["metrics"] = json.load(f)

    return info


# ─────────────────────────────────────────────────────────────────────────────
#  STARTUP EVENT
# ─────────────────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup_event():
    """Pre-load metadata and models on server start for fast first response."""
    logger.info("=== Building CFD AI API starting ===")
    logger.info(f"DATA_DIR      : {DATA_DIR}")
    logger.info(f"MODEL_DIR     : {MODEL_DIR}")
    logger.info(f"BUILDINGS_DIR : {BUILDINGS_DIR}")

    try:
        meta = get_metadata()
        logger.info(f"Metadata loaded: {len(meta)} buildings")
    except Exception as e:
        logger.warning(f"Metadata not loaded: {e}")

    try:
        get_engine()
        logger.info("RAG engine loaded")
    except Exception as e:
        logger.warning(f"RAG engine not loaded: {e}")

    try:
        get_predictor()
        logger.info("Predictor loaded")
    except Exception as e:
        logger.warning(f"Predictor not loaded: {e}")

    logger.info("API ready at http://localhost:8000")
    logger.info("Swagger docs: http://localhost:8000/docs")
