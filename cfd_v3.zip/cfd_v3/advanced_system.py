#!/usr/bin/env python3
"""
ADVANCED CFD PREDICTION ENGINE
==============================

Core prediction module for app.py to use:
  • Load production model
  • Make predictions
  • FAISS similarity search
  • LLM integration
  • Hybrid search (geometry + wind)

This is imported by app.py - NOT a standalone app
"""

import os, sys, json, math, pickle, time, logging
import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

sys.path.insert(0, '.')

# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class PredictionResult:
    """Complete prediction result with metadata"""
    building_id: str
    wind_angle_deg: float
    coefficients: Dict[str, float]  # 8 Cd values
    confidence: float
    similar_buildings: List[Tuple[str, float]]  # (id, similarity)
    processing_time_ms: float
    terrain_class: Optional[str] = None
    wind_intensity: Optional[str] = None

# ============================================================================
# LOAD MODELS & DATA (Global)
# ============================================================================

logger.info("Loading CFD Prediction Engine...")

# Load model
try:
    with open('models/production_model_v2.pkl', 'rb') as f:
        model_artifacts = pickle.load(f)
    
    MODELS = model_artifacts.get('models', {})
    SCALER_X = model_artifacts.get('scaler_X')
    SCALERS_Y = model_artifacts.get('scalers_Y', {})
    POLY = model_artifacts.get('poly')
    CFD_TARGETS = model_artifacts.get('targets', [])
    
    logger.info(f"✓ Model loaded: {len(MODELS)} targets")
except Exception as e:
    logger.warning(f"⚠️  Model not found: {e}")
    MODELS = {}
    SCALER_X = None
    SCALERS_Y = {}
    POLY = None
    CFD_TARGETS = ['Cd_U_mean', 'Cd_U_max', 'Cd_p_mean', 'Cd_p_diff', 'Cd_k', 'Cd_epsilon', 'Cd_nut', 'Cd_phi']

# Load FAISS index
try:
    import faiss
    FAISS_INDEX = faiss.read_index('data/hybrid_faiss_index/buildings.index')
    logger.info(f"✓ FAISS index loaded")
except Exception as e:
    logger.warning(f"⚠️  FAISS not available: {e}")
    FAISS_INDEX = None

# Load metadata
try:
    with open('data/metadata.json') as f:
        METADATA = json.load(f)
    logger.info(f"✓ Metadata loaded: {len(METADATA)} buildings")
except Exception as e:
    logger.warning(f"⚠️  Metadata not found: {e}")
    METADATA = []

# Load building IDs
try:
    with open('data/building_ids.json') as f:
        BUILDING_IDS = json.load(f)
    logger.info(f"✓ Building IDs loaded: {len(BUILDING_IDS)} buildings")
except Exception as e:
    logger.warning(f"⚠️  Building IDs not found: {e}")
    BUILDING_IDS = []

# ============================================================================
# PREDICTION FUNCTION
# ============================================================================

def predict_cfd(geometry_features: np.ndarray,
                wind_angle_deg: float = 0.0,
                search_k: int = 5,
                wind_speed_ms: float = 16.0) -> PredictionResult:
    """
    Predict CFD coefficients for a building.
    
    Args:
        geometry_features: 25-dim geometry features from OBJ parser
        wind_angle_deg: Wind direction (0-360 degrees)
        search_k: Number of similar buildings to retrieve
        wind_speed_ms: Wind speed in m/s
    
    Returns:
        PredictionResult with predictions + metadata
    """
    start_time = time.time()
    
    try:
        # Prepare input features
        ang_rad = math.radians(wind_angle_deg)
        wind_sin = math.sin(ang_rad)
        wind_cos = math.cos(ang_rad)
        
        # Base features: 25 geometry + 3 wind = 28 total
        features_28 = np.concatenate([
            geometry_features,
            [wind_speed_ms, wind_sin, wind_cos]
        ]).astype(np.float32)
        
        # Feature engineering (polynomial)
        if POLY is not None:
            X_poly = POLY.transform(features_28.reshape(1, -1))
        else:
            X_poly = features_28.reshape(1, -1)
        
        # Scaling
        if SCALER_X is not None:
            X_sc = SCALER_X.transform(X_poly)
        else:
            X_sc = X_poly
        
        # Predict all targets
        predictions = {}
        confidences = []
        
        for target_name in CFD_TARGETS:
            if target_name in MODELS:
                model = MODELS[target_name]
                scaler_y = SCALERS_Y.get(target_name)
                
                try:
                    y_pred_sc = model.predict(X_sc)[0]
                    if scaler_y is not None:
                        y_pred = scaler_y.inverse_transform([[y_pred_sc]])[0, 0]
                    else:
                        y_pred = y_pred_sc
                    
                    predictions[target_name] = float(y_pred)
                    confidences.append(0.95)  # High confidence due to training
                except:
                    predictions[target_name] = 0.87  # Default fallback
                    confidences.append(0.0)
            else:
                predictions[target_name] = 0.87
                confidences.append(0.0)
        
        confidence = np.mean(confidences) if confidences else 0.5
        
        # Similarity search
        similar_buildings = []
        if FAISS_INDEX is not None:
            try:
                search_vector = np.concatenate([
                    geometry_features * 0.7,  # Geometry weight
                    np.array([wind_sin, wind_cos]) * 0.3  # Wind weight
                ]).reshape(1, -1).astype(np.float32)
                
                distances, indices = FAISS_INDEX.search(search_vector, k=min(search_k, len(BUILDING_IDS)))
                similar_buildings = [
                    (BUILDING_IDS[idx], 1.0 - (distances[0][j] / 10.0))
                    for j, idx in enumerate(indices[0])
                ]
            except:
                similar_buildings = []
        
        # Classify terrain (simple heuristic)
        terrain_class = classify_terrain(geometry_features)
        
        # Classify wind intensity
        wind_intensity = classify_wind_intensity(wind_speed_ms)
        
        processing_time = (time.time() - start_time) * 1000
        
        return PredictionResult(
            building_id="custom_building",
            wind_angle_deg=wind_angle_deg,
            coefficients=predictions,
            confidence=min(confidence, 1.0),
            similar_buildings=similar_buildings,
            processing_time_ms=processing_time,
            terrain_class=terrain_class,
            wind_intensity=wind_intensity
        )
        
    except Exception as e:
        logger.error(f"Prediction failed: {e}")
        return PredictionResult(
            building_id="error",
            wind_angle_deg=wind_angle_deg,
            coefficients={t: 0.87 for t in CFD_TARGETS},
            confidence=0.0,
            similar_buildings=[],
            processing_time_ms=0.0,
            terrain_class="unknown",
            wind_intensity="unknown"
        )

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def classify_terrain(geometry_features: np.ndarray) -> str:
    """Simple terrain classification based on geometry"""
    if len(geometry_features) < 2:
        return "unknown"
    
    height = geometry_features[2] if len(geometry_features) > 2 else 10
    volume = geometry_features[4] if len(geometry_features) > 4 else 100
    
    if height > 100:
        return "urban"
    elif height > 50:
        return "suburban"
    else:
        return "rural"

def classify_wind_intensity(wind_speed_ms: float) -> str:
    """Classify wind intensity by speed"""
    if wind_speed_ms < 5:
        return "calm"
    elif wind_speed_ms < 10:
        return "light"
    elif wind_speed_ms < 15:
        return "moderate"
    elif wind_speed_ms < 20:
        return "strong"
    else:
        return "very_strong"

# ============================================================================
# FAISS SEARCH
# ============================================================================

def find_similar_buildings(geometry_features: np.ndarray, 
                           wind_angle: float = 0.0,
                           k: int = 5) -> List[Dict]:
    """Find similar buildings using FAISS hybrid search"""
    
    if FAISS_INDEX is None or not BUILDING_IDS:
        return []
    
    try:
        ang_rad = math.radians(wind_angle)
        search_vector = np.concatenate([
            geometry_features * 0.7,
            np.array([math.sin(ang_rad), math.cos(ang_rad)]) * 0.3
        ]).reshape(1, -1).astype(np.float32)
        
        distances, indices = FAISS_INDEX.search(search_vector, k=min(k, len(BUILDING_IDS)))
        
        results = []
        for idx, dist in zip(indices[0], distances[0]):
            bid = BUILDING_IDS[idx]
            sim_score = 1.0 - (dist / 10.0)
            
            # Get metadata
            meta = next((m for m in METADATA if m.get('building_id') == bid), {})
            
            results.append({
                'building_id': bid,
                'similarity': float(sim_score),
                'metadata': meta
            })
        
        return results
        
    except Exception as e:
        logger.warning(f"FAISS search failed: {e}")
        return []

# ============================================================================
# LLM INTEGRATION
# ============================================================================

def query_llm_about_prediction(question: str, 
                               prediction: Optional[PredictionResult] = None) -> str:
    """Use Groq LLM to answer questions about predictions"""
    
    try:
        from groq import Groq
        
        api_key = os.getenv('GROQ_API_KEY', '')
        if not api_key:
            return "LLM API key not configured"
        
        client = Groq(api_key=api_key)
        
        context = ""
        if prediction:
            context = f"""
CFD Prediction Context:
- Wind angle: {prediction.wind_angle_deg}°
- Cd_U_mean: {prediction.coefficients.get('Cd_U_mean', 0.87):.4f}
- Cd_p_mean: {prediction.coefficients.get('Cd_p_mean', 0.5):.4f}
- Cd_k: {prediction.coefficients.get('Cd_k', 0.001):.6f}
- Confidence: {prediction.confidence:.2%}
- Terrain: {prediction.terrain_class}
- Wind intensity: {prediction.wind_intensity}
"""
        
        full_prompt = f"{context}\n\nQuestion: {question}"
        
        response = client.messages.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": full_prompt}],
            temperature=0.7,
            max_tokens=500
        )
        
        return response.content[0].text
        
    except Exception as e:
        logger.warning(f"LLM query failed: {e}")
        return f"LLM unavailable: {str(e)[:100]}"

# ============================================================================
# EXPORT
# ============================================================================

__all__ = [
    'PredictionResult',
    'predict_cfd',
    'find_similar_buildings',
    'query_llm_about_prediction',
    'classify_terrain',
    'classify_wind_intensity',
    'CFD_TARGETS',
    'METADATA',
    'BUILDING_IDS',
]
