"""
ml/xgb_model.py — XGBoost Wind CFD Surrogate — MCD BERL Pvt Ltd
=================================================================
Replaces GNN with XGBoost for fast, accurate wind stats prediction.
Training: 2-5 minutes on CPU.
Inference: <1ms per prediction.

Predicts: U_mean, U_max, p_mean, p_max, p_min,
          Cp_windward, Cp_leeward, stagnation_p,
          k_mean, epsilon_mean, dynamic_q, design_speed
"""
import json, logging, pickle
import numpy as np
from pathlib import Path
from typing import Dict, Optional, Tuple

log = logging.getLogger(__name__)

MODEL_PATH = Path(__file__).parent / "xgb_model.pkl"
META_PATH  = Path(__file__).parent / "xgb_meta.json"

TARGET_NAMES = [
    "U_mean", "U_max", "p_mean", "p_max", "p_min",
    "Cp_windward", "Cp_leeward", "stagnation_p",
    "k_mean", "epsilon_mean", "dynamic_q", "design_speed",
]

RHO = 1.225

# ─────────────────────────────────────────────────────────────────────────────
# OpenFOAM PARSERS (same as before)
# ─────────────────────────────────────────────────────────────────────────────
import re

def _clean(t):
    return re.sub(r"//[^\n]*", "", re.sub(r"/\*.*?\*/", "", t, flags=re.DOTALL))

def parse_openfoam_bytes(data: bytes) -> Optional[np.ndarray]:
    try:
        text = _clean(data.decode("utf-8", errors="ignore"))
    except:
        return None
    m = re.search(
        r"internalField\s+nonuniform\s+List<scalar>\s*\n\s*\d+\s*\n\s*\(\s*\n(.*?)\n?\s*\)",
        text, re.DOTALL)
    if m:
        vals = [float(v) for v in m.group(1).strip().split("\n") if v.strip()]
        if vals: return np.array(vals, np.float32)
    m2 = re.search(
        r"internalField\s+nonuniform\s+List<vector>\s*\n\s*\d+\s*\n\s*\((.*?)\)",
        text, re.DOTALL)
    if m2:
        tuples = re.findall(r'\(\s*([\d.\-eE+]+)\s+([\d.\-eE+]+)\s+([\d.\-eE+]+)\s*\)', m2.group(1))
        rows = [[float(x) for x in t] for t in tuples]
        if rows: return np.array(rows, np.float32)
    m = re.search(r"internalField\s+uniform\s+([\d.\-eE+]+)", text)
    if m: return np.array([float(m.group(1))], np.float32)
    m = re.search(r"internalField\s+uniform\s+\(([\d.\-eE+\s]+)\)", text)
    if m:
        p = m.group(1).split()
        if len(p) == 3: return np.array([[float(x) for x in p]], np.float32)
    return None

def parse_obj_geometry(data: bytes) -> Dict:
    default = dict(width=40., depth=30., height=60., aspect_hw=1.5, slenderness=1.73)
    try:
        text = data.decode("utf-8", errors="ignore")
    except:
        return default
    verts = []
    for line in text.splitlines():
        if line.startswith("v "):
            p = line.strip().split()
            if len(p) == 4:
                try: verts.append([float(p[1]), float(p[2]), float(p[3])])
                except: pass
    if len(verts) < 4: return default
    v = np.array(verts)
    lo, hi = v.min(0), v.max(0)
    W = max(float(hi[0]-lo[0]), 1.)
    H = max(float(hi[1]-lo[1]), 1.)
    D = max(float(hi[2]-lo[2]), 1.)
    return dict(width=round(W,2), depth=round(D,2), height=round(H,2),
                aspect_hw=round(H/W,3),
                slenderness=round(H/max(float(np.sqrt(W*D)),0.1),3))

# ─────────────────────────────────────────────────────────────────────────────
# FEATURE EXTRACTION — 22 physics-informed features
# ─────────────────────────────────────────────────────────────────────────────
def extract_features(files: Dict[str, bytes],
                     wind_speed: float,
                     wind_dir_deg: float) -> np.ndarray:
    """
    Extract 22 features from building geometry + wind conditions.
    All features are physically meaningful — no random values.
    """
    geo = parse_obj_geometry(files.get("obj", b""))
    W, D, H = geo["width"], geo["depth"], geo["height"]
    wr  = np.radians(wind_dir_deg)
    dq  = 0.5 * RHO * wind_speed**2

    sin_d = float(np.sin(wr))
    cos_d = float(np.cos(wr))

    hw_ratio    = H / max(W, 1.)
    wd_ratio    = W / max(D, 1.)
    slenderness = H / max(float(np.sqrt(W*D)), 1.)
    plan_area   = W * D
    facade_w    = W * H
    facade_d    = D * H
    vol         = W * D * H

    design_spd  = wind_speed * 1.35
    dq_design   = 0.5 * RHO * design_spd**2

    # Projected windward area (depends on wind direction)
    aoa_w = abs(sin_d)
    aoa_d = abs(cos_d)
    eff_windward_area = W * H * aoa_w + D * H * aoa_d
    eff_plan          = W * aoa_w + D * aoa_d

    return np.array([
        wind_speed, wind_dir_deg, sin_d, cos_d,
        W, D, H, hw_ratio, wd_ratio, slenderness,
        plan_area, facade_w, facade_d, vol,
        dq, dq_design, design_spd,
        aoa_w, aoa_d,
        eff_windward_area, eff_plan,
        wind_speed * eff_windward_area,   # momentum proxy
    ], dtype=np.float32)


# ─────────────────────────────────────────────────────────────────────────────
# TARGET EXTRACTION — real CFD values
# ─────────────────────────────────────────────────────────────────────────────
def extract_targets(files: Dict[str, bytes],
                    wind_speed: float,
                    wind_dir_deg: float) -> np.ndarray:
    """
    Extract real CFD-derived target values.
    These are what XGBoost learns to predict.
    """
    U_data   = parse_openfoam_bytes(files.get("U",       b""))
    p_data   = parse_openfoam_bytes(files.get("p",       b""))
    k_data   = parse_openfoam_bytes(files.get("k",       b""))
    eps_data = parse_openfoam_bytes(files.get("epsilon", b""))

    dq = 0.5 * RHO * wind_speed**2

    def safe_stats(arr):
        if arr is None: return 0., 0., 0.
        a = arr if arr.ndim == 1 else np.linalg.norm(arr, axis=1)
        a = np.nan_to_num(a.astype(np.float32))
        return float(a.mean()), float(a.max()), float(a.min())

    U_mean, U_max, _    = safe_stats(U_data)
    p_mean, p_max, p_min = safe_stats(p_data)
    k_mean, _, _        = safe_stats(k_data)
    e_mean, _, _        = safe_stats(eps_data)

    # Kinematic → absolute pressure
    if abs(p_mean) < 1000:
        p_mean = p_mean * RHO + 101325.
        p_max  = p_max  * RHO + 101325.
        p_min  = p_min  * RHO + 101325.

    stag_p = p_mean + dq
    Cp_w   = 0.8 * dq
    Cp_l   = -0.5 * dq

    return np.array([
        U_mean, U_max,
        p_mean, p_max, p_min,
        Cp_w, Cp_l, stag_p,
        k_mean, e_mean,
        dq, wind_speed * 1.35,
    ], dtype=np.float32)


# ─────────────────────────────────────────────────────────────────────────────
# PREDICTOR — used by backend server
# ─────────────────────────────────────────────────────────────────────────────
class XGBPredictor:
    """
    Drop-in replacement for MGNPredictor.
    Backend calls same methods — no changes needed in main.py.
    """
    def __init__(self):
        self.models    = {}   # one XGBRegressor per target
        self._ready    = False
        self.base_meta: Dict = {}

    def load(self):
        try:
            with open(str(MODEL_PATH), "rb") as f:
                self.models = pickle.load(f)
            with open(str(META_PATH)) as f:
                self.base_meta = json.load(f)
            self._ready = True
            log.info(f"XGBoost predictor loaded ✓  ({len(self.models)} models)")
        except Exception as e:
            log.warning(f"XGBoost not ready: {e}  → run: python train_xgboost.py --buildings ./buildings")
            self._ready = False

    @property
    def ready(self) -> bool:
        return self._ready

    def _predict_stats_raw(self,
                            wind_speed: float,
                            wind_dir_deg: float,
                            files: Optional[Dict[str, bytes]] = None) -> Dict:
        """
        Run XGBoost inference. Returns all predicted stats.
        If files provided, uses real geometry. Otherwise uses base_meta geometry.
        """
        if not self._ready:
            return {}

        # Build feature vector
        if files:
            feat = extract_features(files, wind_speed, wind_dir_deg)
        else:
            # Use stored geometry from last upload
            meta = self.base_meta
            dummy_obj = (
                f"v 0 0 0\nv {meta.get('width',40)} 0 0\n"
                f"v {meta.get('width',40)} {meta.get('height',60)} 0\n"
                f"v 0 {meta.get('height',60)} 0\n"
                f"v 0 0 {meta.get('depth',30)}\n"
            ).encode()
            feat = extract_features({"obj": dummy_obj}, wind_speed, wind_dir_deg)

        feat_2d = feat.reshape(1, -1)
        result  = {}
        for name in TARGET_NAMES:
            if name in self.models:
                val = float(self.models[name].predict(feat_2d)[0])
                result[name] = round(val, 4)
        return result

    def predict_stats(self, wind_speed: float, wind_dir_deg: float) -> Dict:
        """Called by backend every 30s for live weather update."""
        raw = self._predict_stats_raw(wind_speed, wind_dir_deg)
        if not raw:
            return self._physics_fallback_stats(wind_speed, wind_dir_deg)

        meta = self.base_meta
        return {
            "U_mean":        raw.get("U_mean", 0),
            "U_max":         raw.get("U_max",  0),
            "p_mean":        raw.get("p_mean", 101325),
            "p_max":         raw.get("p_max",  101325),
            "p_min":         raw.get("p_min",  101325),
            "k_mean":        raw.get("k_mean", 0),
            "epsilon_mean":  raw.get("epsilon_mean", 0),
            "nut_mean":      meta.get("nut_mean", 0),
            "dynamic_q":     raw.get("dynamic_q", 0),
            "stagnation_p":  raw.get("stagnation_p", 101325),
            "Cp_windward":   raw.get("Cp_windward", 0),
            "Cp_leeward":    raw.get("Cp_leeward",  0),
            "design_speed":  raw.get("design_speed", 0),
            "wind_speed":    wind_speed,
            "wind_direction": wind_dir_deg,
            **{k: meta[k] for k in
               ("width","depth","height","aspect_hw","slenderness","N_cells")
               if k in meta},
        }

    def predict_field_from_files(
            self,
            files: Dict[str, bytes],
            wind_speed: float,
            wind_dir_deg: float) -> Tuple[np.ndarray, np.ndarray, Dict]:
        """
        Called after file upload.
        XGBoost predicts stats; physics model generates 3D field for visualization.
        Returns (pos, pred[N,4], meta) — same interface as GNN predictor.
        """
        geo  = parse_obj_geometry(files.get("obj", b""))
        W, D, H = geo["width"], geo["depth"], geo["height"]

        # Get XGBoost predicted stats
        raw = self._predict_stats_raw(wind_speed, wind_dir_deg, files)

        # Update meta with real geometry
        self.base_meta.update(geo)
        self.base_meta["N_cells"] = 2000
        self.base_meta["nut_mean"] = 0.

        # Generate 3D visualization field using physics model
        # calibrated to XGBoost predicted values
        N     = 2000
        rng   = np.random.default_rng(42)

        # Real surface nodes from .obj
        from gnn_model import parse_obj_full
        obj_verts, _ = parse_obj_full(files.get("obj", b""))
        if len(obj_verts) >= 4:
            lo = obj_verts.min(0)
            sv = obj_verts - lo
            stride = max(1, len(sv) // 800)
            surface_pos = sv[::stride][:800].astype(np.float32)
        else:
            surface_pos = np.zeros((0, 3), np.float32)

        N_surf = len(surface_pos)
        N_int  = N - N_surf

        # Interior nodes: structured grid
        cbrt = int(np.ceil(N_int ** (1/3)))
        gx = np.linspace(-W*.5, W*1.5, cbrt)
        gy = np.linspace(0,     H*1.8,  cbrt)
        gz = np.linspace(-D*.5, D*1.5,  cbrt)
        gxx, gyy, gzz = np.meshgrid(gx, gy, gz, indexing='ij')
        int_pos = np.column_stack([gxx.ravel(), gyy.ravel(), gzz.ravel()])[:N_int].astype(np.float32)

        pos = np.vstack([surface_pos, int_pos])
        N   = len(pos)

        # Physics field calibrated to XGBoost predictions
        pred = self._calibrated_field(pos, W, D, H,
                                       wind_speed, wind_dir_deg, raw)

        meta = self.predict_stats(wind_speed, wind_dir_deg)
        meta.update(geo)
        return pos, pred, meta

    def _calibrated_field(self, pos, W, D, H,
                          ws, wd, xgb_stats) -> np.ndarray:
        x, y, z = pos[:,0], pos[:,1], pos[:,2]
        wr_ = float(np.radians(wd))

        # Use XGBoost stats; fall back to physics if zero/missing
        U_max_raw = xgb_stats.get("U_max", 0)
        U_max     = U_max_raw if U_max_raw > 0.1 else ws * 1.6
        p_mean    = xgb_stats.get("p_mean", 101325.)
        if abs(p_mean) < 1000:
            p_mean = 101325.
        dq = max(xgb_stats.get("dynamic_q", 0.5*RHO*ws**2), 0.5*RHO*ws**2*0.1)

        # Normalized building-centered coords
        nx = (x - W/2) / max(W/2, 1.)
        ny = y / max(H, 1.)
        nz = (z - D/2) / max(D/2, 1.)
        wind_dot = nx * np.sin(wr_) + nz * np.cos(wr_)
        inside   = (np.abs(nx) < 1.) & (ny >= 0.) & (ny <= 1.) & (np.abs(nz) < 1.)

        # Height power-law profile
        prof = np.power(np.clip(ny, 0.02, None), 0.25)

        # Cp distribution
        Cp = np.where(inside, 0.,
             np.where(wind_dot >  0.4,  0.8 * wind_dot * prof,
             np.where(wind_dot < -0.3, -0.5 * np.abs(wind_dot) * prof,
             -0.3 * (1 - wind_dot**2) * prof)))

        # Velocity with height profile and bypass factor
        U_ref  = ws * prof
        bypass = np.where(wind_dot > 0.4,
                    np.clip(1.0 - 0.6*wind_dot, 0.1, 0.8),
                    np.where(wind_dot < -0.3,
                        np.clip(1.0 + 0.4*np.abs(wind_dot), 0.8, 1.5),
                        np.clip(1.1 - 0.2*wind_dot**2, 0.8, 1.4)))
        U_mag = np.where(inside, 0., U_ref * bypass)

        # Scale to XGBoost U_max
        cur_max = float(U_mag.max())
        if cur_max > 0.01:
            U_mag = U_mag * min(U_max / cur_max, 2.5)

        u = (U_mag * np.sin(wr_)).astype(np.float32)
        v = np.zeros(len(pos), np.float32)
        w = (U_mag * np.cos(wr_)).astype(np.float32)
        p = (p_mean + Cp * dq).astype(np.float32)
        return np.column_stack([u, v, w, p]).astype(np.float32)

    def _physics_fallback_stats(self, ws, wd) -> Dict:
        dq = 0.5 * RHO * ws**2
        return {
            "U_mean": round(ws*0.82, 4), "U_max": round(ws*1.4, 4),
            "p_mean": round(101325+dq*.05, 2),
            "p_max":  round(101325+dq, 2),
            "p_min":  round(101325-dq*.5, 2),
            "k_mean": 0., "epsilon_mean": 0., "nut_mean": 0.,
            "dynamic_q":    round(dq, 3),
            "stagnation_p": round(101325+dq, 2),
            "Cp_windward":  round(0.8*dq, 3),
            "Cp_leeward":   round(-0.5*dq, 3),
            "design_speed": round(ws*1.35, 2),
            "wind_speed": ws, "wind_direction": wd,
        }


# Singleton used by backend
predictor = XGBPredictor()