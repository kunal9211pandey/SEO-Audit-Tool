"""
train_xgboost.py — MCD BERL Pvt Ltd
=====================================
Trains XGBoost surrogate for wind CFD.
Completes in 2-5 minutes on CPU.

Usage:
  python train_xgboost.py --buildings ./buildings

Output:
  ml/xgb_model.pkl
  ml/xgb_meta.json
"""
import argparse, sys, json, logging, pickle
import numpy as np
from pathlib import Path

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s  %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger()
sys.path.insert(0, str(Path(__file__).parent / "ml"))

from xgb_model import (extract_features, extract_targets,
                        TARGET_NAMES, MODEL_PATH, META_PATH,
                        parse_obj_geometry)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--buildings",    default="buildings")
    ap.add_argument("--n-estimators", type=int, default=300)
    ap.add_argument("--max-depth",    type=int, default=6)
    args = ap.parse_args()

    try:
        import xgboost as xgb
        log.info(f"XGBoost {xgb.__version__} ready")
    except ImportError:
        log.error("Install XGBoost first:  pip install xgboost scikit-learn")
        sys.exit(1)

    root  = Path(args.buildings)
    bdirs = sorted(d for d in root.iterdir() if d.is_dir())
    if not bdirs:
        log.error(f"No building folders in: {root}")
        sys.exit(1)

    SPEEDS = [3, 5, 8, 10, 12, 15, 18, 22, 28, 33]
    DIRS   = [0, 30, 45, 60, 90, 120, 150, 180, 270, 315]

    print("=" * 56)
    print("  XGBoost TRAINING  —  MCD BERL Pvt Ltd")
    print(f"  Buildings   : {len(bdirs)}")
    print(f"  Conditions  : {len(SPEEDS)} speeds × {len(DIRS)} directions")
    print(f"  Total samples: ~{len(bdirs)*len(SPEEDS)*len(DIRS):,}")
    print(f"  Estimators  : {args.n_estimators}")
    print("=" * 56)

    X_all, y_all, metas = [], [], []

    for bd in bdirs:
        files = {}
        for fn in ["U","p","k","epsilon","nut","phi"]:
            fp = bd / fn
            if fp.exists(): files[fn] = fp.read_bytes()
        obj = bd / "building.obj"
        if obj.exists(): files["obj"] = obj.read_bytes()
        if len(files) < 3:
            log.warning(f"  {bd.name}: skip (only {len(files)} files)")
            continue

        log.info(f"  {bd.name} — extracting...")
        geo = parse_obj_geometry(files.get("obj", b""))
        metas.append(geo)

        for ws in SPEEDS:
            for wd in DIRS:
                try:
                    feat = extract_features(files, ws, wd)
                    tgt  = extract_targets(files, ws, wd)
                    X_all.append(feat)
                    y_all.append(tgt)
                except Exception as e:
                    log.debug(f"    {bd.name} ws={ws} wd={wd}: {e}")

    if not X_all:
        log.error("No samples — check file format"); sys.exit(1)

    X = np.array(X_all, dtype=np.float32)
    y = np.array(y_all, dtype=np.float32)
    log.info(f"Dataset: {X.shape[0]} samples × {X.shape[1]} features → {y.shape[1]} targets")

    # Train one model per output variable
    models = {}
    r2_scores = {}

    for i, name in enumerate(TARGET_NAMES):
        log.info(f"  Training [{i+1}/{len(TARGET_NAMES)}]: {name} ...")
        model = xgb.XGBRegressor(
            n_estimators     = args.n_estimators,
            max_depth        = args.max_depth,
            learning_rate    = 0.05,
            subsample        = 0.8,
            colsample_bytree = 0.8,
            min_child_weight = 3,
            tree_method      = "hist",   # fastest CPU method
            n_jobs           = -1,
            random_state     = 42,
            verbosity        = 0,
        )
        model.fit(X, y[:, i])
        models[name] = model

        # Quick R² score on training data
        from sklearn.metrics import r2_score
        preds = model.predict(X)
        r2    = r2_score(y[:, i], preds)
        r2_scores[name] = round(float(r2), 4)
        log.info(f"    R² = {r2:.4f}")

    # Save models
    MODEL_PATH.parent.mkdir(exist_ok=True)
    with open(str(MODEL_PATH), "wb") as f:
        pickle.dump(models, f)

    # Save meta (average geometry stats)
    keys = ["width","depth","height","aspect_hw","slenderness"]
    avg_meta = {}
    for k in keys:
        vals = [m[k] for m in metas if k in m]
        avg_meta[k] = round(float(np.mean(vals)), 3) if vals else 0.
    avg_meta["N_cells"] = 2000
    avg_meta["nut_mean"] = 0.
    avg_meta["r2_scores"] = r2_scores

    with open(str(META_PATH), "w") as f:
        json.dump(avg_meta, f, indent=2)

    print("=" * 56)
    print(f"  Training complete!")
    print(f"  Saved → ml/xgb_model.pkl")
    print(f"  Saved → ml/xgb_meta.json")
    print()
    print("  R² Scores (1.0 = perfect):")
    for name, score in r2_scores.items():
        bar = "█" * int(score * 20)
        print(f"    {name:<20} {score:.4f}  {bar}")
    print()
    print("  Next: uvicorn backend.main:app --host 0.0.0.0 --port 8000")
    print("=" * 56)

if __name__ == "__main__":
    main()
