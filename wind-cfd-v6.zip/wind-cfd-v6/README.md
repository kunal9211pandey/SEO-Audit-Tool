# Wind CFD Dashboard — MCD BERL Pvt Ltd
## XGBoost Surrogate Model (Fast + Accurate)

---

## Quick Start

### 1. API Key set karo
Edit `.env`:
```
OPENWEATHER_API_KEY=your_key_here
```
Free key: https://openweathermap.org/api

### 2. Dependencies install karo
```bash
pip install -r backend/requirements.txt
```

### 3. XGBoost model train karo (2-5 minutes)
```bash
python train_xgboost.py --buildings ./buildings
```
Output: `ml/xgb_model.pkl` + `ml/xgb_meta.json`

### 4. Server start karo
```bash
uvicorn backend.main:app --host 0.0.0.0 --port 8000
```

Open: http://localhost:8000

---

## Dataset Format
```
buildings/
  B001/
    building.obj    ← 3D geometry
    U               ← velocity field
    p               ← pressure field
    k               ← turbulent kinetic energy
    epsilon         ← dissipation rate
    nut             ← turbulent viscosity
    phi             ← flux
  B002/ ...
```

---

## Model: XGBoost Surrogate
- Training time: **2-5 minutes** on CPU
- Predicts: U_mean, U_max, Cp_windward, Cp_leeward,
            stagnation_p, k_mean, epsilon_mean, dynamic_q, design_speed
- One XGBoost model per output variable (12 models total)
- R² score printed after training

---

## File Structure
```
wind-cfd/
├── backend/main.py          ← FastAPI server
├── frontend/index.html      ← Dashboard (Three.js)
├── ml/xgb_model.py          ← XGBoost predictor
├── ml/gnn_model.py          ← GNN (optional, for future)
├── train_xgboost.py         ← Training script (run this)
├── .env                     ← API keys
└── buildings/               ← Your CFD dataset
```
