"""
train_once.py — DEVELOPER ONLY — MCD BERL Pvt Ltd
Trains MeshGraphNet on your OpenFOAM dataset.
Run ONCE before starting the server.

Usage:
  python train_once.py --buildings ./buildings

Output (ml/):
  mgn_model.pt     ← GNN weights
  mgn_scaler.npz   ← normalizer
  mgn_meta.json    ← building stats
"""
import argparse, sys, json, logging
import numpy as np
from pathlib import Path

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s  %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger()
sys.path.insert(0, str(Path(__file__).parent / "ml"))
from gnn_model import MGNTrainer, build_graph, META_PATH

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--buildings", default="buildings",
                    help="Path to folder containing building sub-folders")
    ap.add_argument("--epochs",    type=int, default=200,
                    help="Training epochs (200 optimal for 100 buildings)")
    ap.add_argument("--hidden",    type=int, default=128,
                    help="Hidden dimension (128 = DeepMind standard)")
    ap.add_argument("--layers",    type=int, default=15,
                    help="Message-passing layers (15 = DeepMind standard)")
    args = ap.parse_args()

    root = Path(args.buildings)
    if not root.exists():
        log.error(f"Buildings folder not found: {root}")
        sys.exit(1)

    bdirs = sorted(d for d in root.iterdir() if d.is_dir())
    if not bdirs:
        log.error("No building sub-folders found in " + str(root))
        sys.exit(1)

    # Wind augmentation matrix — train on diverse conditions
    SPEEDS = [3, 5, 8, 10, 12, 15, 18, 22, 28, 33]        # m/s
    DIRS   = [0, 30, 45, 60, 90, 120, 150, 180, 270, 315]  # degrees

    print("=" * 60)
    print("  MeshGraphNet TRAINING  —  MCD BERL Pvt Ltd")
    print(f"  Buildings       : {len(bdirs)}")
    print(f"  Epochs          : {args.epochs}")
    print(f"  Hidden dim      : {args.hidden}")
    print(f"  Processor layers: {args.layers}")
    print(f"  Graphs expected : {len(bdirs)} × {len(SPEEDS)} × {len(DIRS)} = {len(bdirs)*len(SPEEDS)*len(DIRS):,}")
    print("=" * 60)

    all_graphs, all_metas = [], []

    for bd in bdirs:
        files = {}
        for fn in ["U","p","k","epsilon","nut","phi"]:
            fp = bd / fn
            if fp.exists():
                files[fn] = fp.read_bytes()
        obj = bd / "building.obj"
        if obj.exists():
            files["obj"] = obj.read_bytes()
        if len(files) < 3:
            log.warning(f"  {bd.name}: skipping — only {len(files)} files found")
            continue

        log.info(f"  {bd.name} — building graphs...")
        for ws in SPEEDS:
            for wd in DIRS:
                try:
                    g, meta = build_graph(files, ws, wd, max_nodes=2000)
                    all_graphs.append(g)
                    all_metas.append(meta)
                except Exception as e:
                    log.debug(f"    ws={ws} wd={wd}: {e}")

    if not all_graphs:
        log.error("No graphs built. Check your file format.")
        sys.exit(1)

    log.info(f"Total graphs: {len(all_graphs):,}")

    trainer = MGNTrainer(hidden=args.hidden, processor_layers=args.layers)
    history = trainer.fit(all_graphs, epochs=args.epochs, verbose=True)
    trainer.save()

    # Average meta across all buildings & conditions
    keys = ["width","depth","height","aspect_hw","slenderness",
            "U_mean","U_max","p_mean","p_max","p_min",
            "k_mean","epsilon_mean","nut_mean","dynamic_q","stagnation_p"]
    avg = {}
    for k in keys:
        vals = [m[k] for m in all_metas if k in m]
        avg[k] = round(float(np.mean(vals)), 5) if vals else 0.
    avg["N_cells"] = int(np.mean([m.get("N_cells",0) for m in all_metas]))

    with open(str(META_PATH), "w") as f:
        json.dump(avg, f, indent=2)

    print("=" * 60)
    print(f"  Final loss   : {history[-1]:.6f}")
    print(f"  Saved        : ml/mgn_model.pt")
    print(f"  Saved        : ml/mgn_scaler.npz")
    print(f"  Saved        : ml/mgn_meta.json")
    print()
    print("  Next step:")
    print("  uvicorn backend.main:app --host 0.0.0.0 --port 8000")
    print("=" * 60)

if __name__ == "__main__":
    main()
