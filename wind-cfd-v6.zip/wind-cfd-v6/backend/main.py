"""
backend/main.py — Wind CFD Dashboard — MCD BERL Pvt Ltd
XGBoost surrogate (fast, accurate). GNN replaced.
"""
import os, sys, asyncio, time, logging, json
from pathlib import Path
from typing import Dict, Optional

import numpy as np, httpx
from fastapi import (FastAPI, WebSocket, WebSocketDisconnect,
                     UploadFile, File, Form, HTTPException, Query)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

def _load_env():
    env = Path(__file__).parent.parent / ".env"
    if not env.exists(): return
    with open(env, encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"): continue
            if "=" in line:
                k, _, v = line.partition("=")
                k, v = k.strip(), v.strip()
                if k and v and k not in os.environ:
                    os.environ[k] = v
_load_env()

sys.path.insert(0, str(Path(__file__).parent.parent / "ml"))
from xgb_model import predictor, parse_obj_geometry   # ← XGBoost now

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s: %(message)s")
log = logging.getLogger("wind-cfd")

app = FastAPI(title="Wind CFD XGBoost — MCD BERL", version="5.0")
app.add_middleware(CORSMiddleware,
                   allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

FRONTEND = Path(__file__).parent.parent / "frontend"
if FRONTEND.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND)), name="static")

# State
cur_lat: float = 12.9716
cur_lon: float = 77.5946
last_stats: Dict = {}
ws_clients: set  = set()
last_files: Optional[Dict[str, bytes]] = None

@app.on_event("startup")
async def startup():
    predictor.load()
    log.info(f"XGBoost ready={predictor.ready}")

# OpenWeatherMap
OWM_KEY = os.getenv("OPENWEATHER_API_KEY", "")
OWM_URL = "https://api.openweathermap.org/data/2.5/weather"

async def fetch_weather(lat, lon) -> Dict:
    if not OWM_KEY:
        raise HTTPException(503,
            "OPENWEATHER_API_KEY not set in .env — get free key at openweathermap.org/api")
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(OWM_URL,
                params={"lat":lat,"lon":lon,"appid":OWM_KEY,"units":"metric"})
            r.raise_for_status()
            d = r.json()
    except httpx.HTTPStatusError as e:
        raise HTTPException(e.response.status_code, f"OWM error: {e}")
    except Exception as e:
        raise HTTPException(503, f"Weather fetch failed: {e}")
    wi, ma = d.get("wind",{}), d.get("main",{})
    return dict(
        city=d.get("name",""), lat=lat, lon=lon,
        wind_speed=float(wi.get("speed",0)),
        wind_direction=float(wi.get("deg",0)),
        wind_gust=float(wi.get("gust", wi.get("speed",0))),
        temperature=float(ma.get("temp",25)),
        humidity=float(ma.get("humidity",60)),
        pressure_hpa=float(ma.get("pressure",1013)),
        description=d.get("weather",[{}])[0].get("description",""),
        timestamp=int(time.time()))

def _serialize_nodes(pos: np.ndarray, pred: np.ndarray,
                     max_vis: int = 1500) -> Dict:
    N = len(pos)
    vi = np.random.choice(N, min(N, max_vis), replace=False)
    return {
        "x": pos[vi,0].tolist(), "y": pos[vi,1].tolist(), "z": pos[vi,2].tolist(),
        "u": pred[vi,0].tolist(), "v": pred[vi,1].tolist(),
        "w": pred[vi,2].tolist(), "p": pred[vi,3].tolist(),
    }

@app.post("/api/upload")
async def upload(
    U_file:       UploadFile = File(...),
    p_file:       UploadFile = File(...),
    k_file:       UploadFile = File(...),
    epsilon_file: UploadFile = File(...),
    nut_file:     UploadFile = File(...),
    phi_file:     UploadFile = File(...),
    obj_file:     UploadFile = File(...),
    lat: float = Form(12.9716),
    lon: float = Form(77.5946),
):
    global cur_lat, cur_lon, last_files
    if not predictor.ready:
        raise HTTPException(503,
            "XGBoost model not trained. Run: python train_xgboost.py --buildings ./buildings")

    files = {
        "U":       await U_file.read(),
        "p":       await p_file.read(),
        "k":       await k_file.read(),
        "epsilon": await epsilon_file.read(),
        "nut":     await nut_file.read(),
        "phi":     await phi_file.read(),
        "obj":     await obj_file.read(),
    }
    last_files  = files
    cur_lat, cur_lon = lat, lon

    weather = await fetch_weather(lat, lon)
    geo     = parse_obj_geometry(files["obj"])

    loop = asyncio.get_event_loop()
    pos, pred, meta = await loop.run_in_executor(
        None,
        lambda: predictor.predict_field_from_files(
            files, weather["wind_speed"], weather["wind_direction"]))

    predictor.base_meta.update(meta)
    stats = predictor.predict_stats(weather["wind_speed"], weather["wind_direction"])
    last_stats.update(stats)

    return JSONResponse({
        "status":    "ok",
        "weather":   weather,
        "stats":     stats,
        "geo":       geo,
        "nodes":     _serialize_nodes(pos, pred),
        "model":     "XGBoost",
        "gnn_ready": True,
    })

@app.get("/api/weather")
async def get_weather(lat:float=Query(None), lon:float=Query(None)):
    return await fetch_weather(lat or cur_lat, lon or cur_lon)

@app.get("/api/predict/stats")
async def get_stats(lat:float=Query(None), lon:float=Query(None)):
    if not predictor.ready:
        raise HTTPException(503, "Model not loaded.")
    w = await fetch_weather(lat or cur_lat, lon or cur_lon)
    s = predictor.predict_stats(w["wind_speed"], w["wind_direction"])
    return {"stats": s, "weather": w}

@app.get("/api/status")
async def status():
    return {
        "gnn_ready": predictor.ready,
        "model":     "XGBoost (fast surrogate)",
        "meta":      predictor.base_meta,
    }

async def _broadcast(data):
    dead = set()
    for ws in ws_clients.copy():
        try: await ws.send_json(data)
        except: dead.add(ws)
    ws_clients -= dead

@app.websocket("/ws/live")
async def ws_live(ws: WebSocket):
    await ws.accept()
    ws_clients.add(ws)
    try:
        while True:
            if not predictor.ready:
                await ws.send_json({"type":"model_not_ready",
                                    "message":"Run train_xgboost.py first."})
            else:
                try:
                    w = await fetch_weather(cur_lat, cur_lon)
                    s = predictor.predict_stats(w["wind_speed"], w["wind_direction"])
                    nodes = None
                    if last_files:
                        loop = asyncio.get_event_loop()
                        pos, pred, _ = await loop.run_in_executor(
                            None,
                            lambda: predictor.predict_field_from_files(
                                last_files, w["wind_speed"], w["wind_direction"]))
                        nodes = _serialize_nodes(pos, pred)
                    await ws.send_json({
                        "type":      "live_update",
                        "weather":   w,
                        "stats":     s,
                        "nodes":     nodes,
                        "gnn_ready": True,
                        "model":     "XGBoost",
                        "timestamp": int(time.time()),
                    })
                except HTTPException as e:
                    await ws.send_json({"type":"error","detail":e.detail})
            await asyncio.sleep(30)
    except WebSocketDisconnect:
        ws_clients.discard(ws)

@app.get("/")
async def root():
    idx = FRONTEND / "index.html"
    return FileResponse(str(idx)) if idx.exists() else {"status":"running"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)