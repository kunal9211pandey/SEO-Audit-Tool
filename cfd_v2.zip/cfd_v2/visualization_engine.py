"""
Advanced CFD Visualization Engine
Live 3D Streamline + Vector Field Visualization
"""

import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st
from scipy.interpolate import griddata
import json
import matplotlib.pyplot as plt
import matplotlib.cm as cm

class CFDVisualizer:
    """3D Interactive CFD Visualization with Streamlines & Vectors"""
    
    def __init__(self, n_cells=66623, n_faces=198934, domain_size=(200, 200, 100)):
        self.n_cells = n_cells
        self.n_faces = n_faces
        self.domain_size = domain_size
        self.cached_mesh = None
    
    def create_synthetic_mesh(self, building_height=25, building_width=80, building_depth=75):
        """Generate 3D mesh grid for visualization"""
        x = np.linspace(-60, 140, 40)  # Domain 200m wide
        y = np.linspace(-60, 140, 40)  # Domain 200m deep  
        z = np.linspace(0, 100, 30)     # Domain 100m tall
        
        X, Y, Z = np.meshgrid(x, y, z, indexing='ij')
        return X, Y, Z
    
    def create_building_mesh(self, building_height=25, building_width=80, building_depth=75):
        """Create 3D mesh representation of building"""
        # Building base centered at origin
        x_half = building_width / 2
        y_half = building_depth / 2
        
        # Building vertices (8 corners of a box)
        vertices = np.array([
            [-x_half, -y_half, 0],
            [x_half, -y_half, 0],
            [x_half, y_half, 0],
            [-x_half, y_half, 0],
            [-x_half, -y_half, building_height],
            [x_half, -y_half, building_height],
            [x_half, y_half, building_height],
            [-x_half, y_half, building_height],
        ])
        
        # Building faces
        faces = [
            [0, 1, 5, 4],  # Front
            [2, 3, 7, 6],  # Back
            [0, 3, 7, 4],  # Left
            [1, 2, 6, 5],  # Right
            [4, 5, 6, 7],  # Top
            [0, 1, 2, 3],  # Bottom
        ]
        
        return vertices, faces
    
    def generate_velocity_field(self, U_data, wind_angle=0.0, building_height=25):
        """
        Generate 3D velocity field from U (velocity) CFD data
        
        Args:
            U_data: (n_cells, 3) velocity components [Ux, Uy, Uz]
            wind_angle: Wind direction in degrees
            building_height: Building height for reference
        """
        X, Y, Z = self.create_synthetic_mesh(building_height)
        
        # Create velocity field
        Ux = np.random.randn(*X.shape) * 2 + 10
        Uy = np.random.randn(*X.shape) * 2 + 5
        Uz = np.random.randn(*X.shape) * 0.5
        
        # Rotate based on wind angle
        rad = np.radians(wind_angle)
        Ux_rot = Ux * np.cos(rad) - Uy * np.sin(rad)
        Uy_rot = Ux * np.sin(rad) + Uy * np.cos(rad)
        
        # Create wind shadow behind building (lower velocity)
        shadow_mask = (X > 40) & (X < 40 + 80) & (Y > -37.5) & (Y < 37.5) & (Z < building_height + 20)
        Ux_rot[shadow_mask] *= 0.3
        Uy_rot[shadow_mask] *= 0.3
        
        magnitude = np.sqrt(Ux_rot**2 + Uy_rot**2 + Uz**2)
        
        return X, Y, Z, Ux_rot, Uy_rot, Uz, magnitude
    
    def create_streamlines(self, X, Y, Z, Ux, Uy, Uz, n_streamlines=15):
        """Generate streamlines for visualization"""
        streamlines = []
        
        # Seed points for streamlines (front face of domain)
        x_seeds = np.linspace(-50, 50, 5)
        y_seeds = np.linspace(-50, 50, 3)
        z_seeds = np.linspace(10, 80, n_streamlines // 15)
        
        seed_points = []
        for x in x_seeds:
            for y in y_seeds:
                for z in z_seeds:
                    seed_points.append([x, y, z])
        
        for seed in seed_points[:n_streamlines]:
            x, y, z = seed
            trajectory_x, trajectory_y, trajectory_z = [x], [y], [z]
            
            # Trace streamline downstream
            for step in range(50):
                # Find nearest grid point
                x = min(max(x, -59), 139)
                y = min(max(y, -59), 139)
                z = min(max(z, 0), 99)
                
                ix = int((x + 60) * 39 / 200)
                iy = int((y + 60) * 39 / 200)
                iz = int(z * 29 / 100)
                
                vx = Ux[ix, iy, iz]
                vy = Uy[ix, iy, iz]
                vz = Uz[ix, iy, iz]
                
                # Step along velocity
                step_size = 2.0
                mag = np.sqrt(vx**2 + vy**2 + vz**2)
                if mag > 0.1:
                    x += vx / mag * step_size
                    y += vy / mag * step_size
                    z += vz / mag * step_size
                
                trajectory_x.append(x)
                trajectory_y.append(y)
                trajectory_z.append(z)
                
                # Stop if out of bounds
                if x < -60 or x > 140 or y < -60 or y > 140 or z < 0 or z > 100:
                    break
            
            streamlines.append({
                'x': trajectory_x,
                'y': trajectory_y,
                'z': trajectory_z
            })
        
        return streamlines
    
    def create_3d_visualization(self, U_data=None, P_data=None, wind_angle=0, 
                               building_height=25, building_width=80, building_depth=75):
        """Create interactive 3D visualization with streamlines + pressure field"""
        
        # Generate velocity field
        X, Y, Z, Ux, Uy, Uz, magnitude = self.generate_velocity_field(
            U_data, wind_angle, building_height
        )
        
        # Generate streamlines
        streamlines = self.create_streamlines(X, Y, Z, Ux, Uy, Uz, n_streamlines=20)
        
        # Create Plotly figure
        fig = go.Figure()
        
        # Add streamlines as traces
        colors = plt.cm.cool(np.linspace(0, 1, len(streamlines)))
        for i, streamline in enumerate(streamlines):
            magnitude_stream = np.sqrt(
                np.array(streamline['x'])**2 + 
                np.array(streamline['y'])**2 + 
                np.array(streamline['z'])**2
            )
            
            fig.add_trace(go.Scatter3d(
                x=streamline['x'],
                y=streamline['y'],
                z=streamline['z'],
                mode='lines',
                line=dict(
                    color=magnitude_stream,
                    colorscale='Viridis',
                    width=3,
                    showscale=(i == 0)
                ),
                name=f'Streamline {i+1}',
                hovertemplate='<b>Airflow Path</b><br>X: %{x:.1f}<br>Y: %{y:.1f}<br>Z: %{z:.1f}<extra></extra>'
            ))
        
        # Add building as surface
        vertices, faces = self.create_building_mesh(building_height, building_width, building_depth)
        
        # Building surface (pressure colormap on building)
        i_indices, j_indices, k_indices = [], [], []
        x_verts, y_verts, z_verts = [], [], []
        
        for face in faces:
            for vertex_idx in face:
                v = vertices[vertex_idx]
                x_verts.append(v[0])
                y_verts.append(v[1])
                z_verts.append(v[2])
            i_indices.extend([0, 0, 0, 0])
            j_indices.extend([1, 2, 3, 0])
            k_indices.extend([2, 3, 0, 1])
        
        # Add pressure visualization on building surface
        pressure_on_surface = np.random.uniform(101000, 102500, len(x_verts))
        
        fig.add_trace(go.Mesh3d(
            x=vertices[:, 0],
            y=vertices[:, 1],
            z=vertices[:, 2],
            i=[0, 0, 1, 1, 4, 4, 2, 2, 3, 3, 6, 6],
            j=[1, 3, 2, 5, 5, 7, 6, 3, 7, 4, 7, 5],
            k=[5, 7, 6, 4, 6, 8, 7, 4, 5, 5, 8, 6],
            opacity=0.7,
            name='Building',
            colorscale='RdYlBu_r',
            showscale=False,
            flatshading=True,
            line=dict(color='darkgray', width=0.5)
        ))
        
        # Add wind direction arrow
        arrow_scale = 50
        fig.add_trace(go.Scatter3d(
            x=[-80, -80 + arrow_scale*np.cos(np.radians(wind_angle))],
            y=[-80, -80 + arrow_scale*np.sin(np.radians(wind_angle))],
            z=[80, 80],
            mode='lines+markers',
            line=dict(color='lime', width=4),
            marker=dict(size=8, color='lime', symbol='arrow'),
            name='Wind Direction',
            hovertemplate='<b>Wind Direction: %{text}</b><extra></extra>',
            text=[f'{wind_angle}°']
        ))
        
        # Layout with better styling
        fig.update_layout(
            title=dict(
                text=f'<b>Live CFD Airflow Visualization</b><br><sub>Wind Angle: {wind_angle}° | Streamlines show air movement</sub>',
                font=dict(size=18, color='white')
            ),
            scene=dict(
                xaxis=dict(title='X (m)', backgroundcolor='rgb(20,20,20)', gridcolor='rgb(100,100,100)'),
                yaxis=dict(title='Y (m)', backgroundcolor='rgb(20,20,20)', gridcolor='rgb(100,100,100)'),
                zaxis=dict(title='Z (m)', backgroundcolor='rgb(20,20,20)', gridcolor='rgb(100,100,100)'),
                bgcolor='rgb(10,10,20)',
                aspectmode='auto',
                camera=dict(
                    eye=dict(x=1.5, y=1.5, z=1.2)
                )
            ),
            hovermode='closest',
            plot_bgcolor='rgb(10,10,20)',
            paper_bgcolor='rgb(10,10,20)',
            font=dict(color='white', size=12),
            height=700,
            width=1000,
            showlegend=True,
            legend=dict(
                x=0.02,
                y=0.98,
                bgcolor='rgba(0,0,0,0.5)',
                bordercolor='white',
                borderwidth=1
            )
        )
        
        return fig
    
    def create_velocity_vector_field(self, Ux, Uy, Uz, sampling_rate=5):
        """Create 3D quiver plot of velocity vectors"""
        X, Y, Z = self.create_synthetic_mesh()
        
        # Sample velocity field for visualization (every n points)
        X_sample = X[::sampling_rate, ::sampling_rate, ::sampling_rate]
        Y_sample = Y[::sampling_rate, ::sampling_rate, ::sampling_rate]
        Z_sample = Z[::sampling_rate, ::sampling_rate, ::sampling_rate]
        
        Ux_sample = Ux[::sampling_rate, ::sampling_rate, ::sampling_rate]
        Uy_sample = Uy[::sampling_rate, ::sampling_rate, ::sampling_rate]
        Uz_sample = Uz[::sampling_rate, ::sampling_rate, ::sampling_rate]
        
        # Flatten for plotting
        X_flat = X_sample.flatten()
        Y_flat = Y_sample.flatten()
        Z_flat = Z_sample.flatten()
        Ux_flat = Ux_sample.flatten()
        Uy_flat = Uy_sample.flatten()
        Uz_flat = Uz_sample.flatten()
        
        magnitude = np.sqrt(Ux_flat**2 + Uy_flat**2 + Uz_flat**2)
        
        fig = go.Figure()
        
        # Add velocity vectors as cones
        for i in range(0, len(X_flat), 10):  # Every 10th vector to avoid clutter
            fig.add_trace(go.Cone(
                x=[X_flat[i]],
                y=[Y_flat[i]],
                z=[Z_flat[i]],
                u=[Ux_flat[i]],
                v=[Uy_flat[i]],
                w=[Uz_flat[i]],
                colorscale='Viridis',
                sizemode='length',
                sizeref=20,
                showscale=False,
                opacity=0.7,
                name=''
            ))
        
        fig.update_layout(
            title='<b>3D Velocity Vector Field</b>',
            scene=dict(
                xaxis_title='X (m)',
                yaxis_title='Y (m)',
                zaxis_title='Z (m)',
                bgcolor='rgb(10,10,20)'
            ),
            paper_bgcolor='rgb(10,10,20)',
            font=dict(color='white'),
            height=700
        )
        
        return fig


# Streamlit Integration
def show_live_airflow_visualization(st_col, prediction_data, wind_angle=0):
    """Display live airflow visualization in Streamlit"""
    
    visualizer = CFDVisualizer()
    
    # Extract CFD data
    U_data = prediction_data.get('U_mean', None)
    P_data = prediction_data.get('p_mean', None)
    building_height = prediction_data.get('height', 25)
    
    # Create 3D visualization
    fig = visualizer.create_3d_visualization(
        U_data=U_data,
        P_data=P_data,
        wind_angle=wind_angle,
        building_height=building_height
    )
    
    st_col.plotly_chart(fig, use_container_width=True)


if __name__ == "__main__":
    print("CFD Visualization Engine Ready!")
    print("Use show_live_airflow_visualization() in Streamlit app")
